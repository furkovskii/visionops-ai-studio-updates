"""Windows-only DPAPI protection for opt-in cloud refresh token. No passwords saved."""
import ctypes, os
from ctypes import wintypes
from pathlib import Path

class DATA_BLOB(ctypes.Structure):
    _fields_=[('cbData',wintypes.DWORD),('pbData',ctypes.POINTER(ctypes.c_byte))]

def _blob(data):
    buffer=ctypes.create_string_buffer(data)
    return DATA_BLOB(len(data),ctypes.cast(buffer,ctypes.POINTER(ctypes.c_byte))),buffer

def _crypt(data,encrypt):
    if os.name!='nt': raise OSError('Windows DPAPI required for persistent cloud sessions')
    inp,buf=_blob(data)
    out=DATA_BLOB()
    crypt=ctypes.windll.crypt32
    crypt.CryptProtectData.argtypes=[ctypes.POINTER(DATA_BLOB),ctypes.c_wchar_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(DATA_BLOB)]
    crypt.CryptUnprotectData.argtypes=[ctypes.POINTER(DATA_BLOB),ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(DATA_BLOB)]
    action=crypt.CryptProtectData if encrypt else crypt.CryptUnprotectData
    ok=action(ctypes.byref(inp),None,None,None,None,0x01,ctypes.byref(out))
    if not ok: raise ctypes.WinError()
    try: return ctypes.string_at(out.pbData,out.cbData)
    finally:
        free=ctypes.windll.kernel32.LocalFree
        free.argtypes=[ctypes.c_void_p]
        free.restype=ctypes.c_void_p
        free(ctypes.cast(out.pbData,ctypes.c_void_p))

def save(path,data):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.tmp');tmp.write_bytes(_crypt(data,True));tmp.replace(path)

def read(path):
    return _crypt(Path(path).read_bytes(),False)

def delete(path):
    Path(path).unlink(missing_ok=True)
