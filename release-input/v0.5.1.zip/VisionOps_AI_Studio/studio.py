"""VisionOps AI Studio: local backend in a native desktop window.

The icon is applied at both the pywebview GUI level (6.2+) and, as a
best-effort fallback, to the actual Windows HWND for older pywebview installs.
"""
import ctypes
import inspect
import logging
import os
from pathlib import Path
import threading
from werkzeug.serving import make_server

ROOT = Path(__file__).resolve().parent
ICON = ROOT / 'VisionOps.ico'
DATA = Path(os.environ.get('VISIONOPS_DATA_DIR', Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'VisionOpsAIStudio'))
DATA.mkdir(parents=True, exist_ok=True)
LOG = DATA / 'visionops_studio.log'
logging.basicConfig(filename=str(LOG), level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')


def _set_windows_app_id():
    """Group the taskbar window as VisionOps rather than generic Python."""
    if os.name != 'nt':
        return
    try:
        shell32 = ctypes.windll.shell32
        shell32.SetCurrentProcessExplicitAppUserModelID.argtypes = [ctypes.c_wchar_p]
        shell32.SetCurrentProcessExplicitAppUserModelID.restype = ctypes.c_long
        shell32.SetCurrentProcessExplicitAppUserModelID('VisionOps.AIStudio.Desktop')
    except Exception:
        logging.exception('Windows application ID could not be set')


def _apply_windows_window_icon():
    """Best-effort Win32 window icon, including Windows taskbar/titlebar."""
    if os.name != 'nt' or not ICON.exists():
        return
    try:
        user32 = ctypes.windll.user32
        user32.FindWindowW.argtypes = [ctypes.c_wchar_p, ctypes.c_wchar_p]
        user32.FindWindowW.restype = ctypes.c_void_p
        user32.LoadImageW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_uint,
                                     ctypes.c_int, ctypes.c_int, ctypes.c_uint]
        user32.LoadImageW.restype = ctypes.c_void_p
        user32.SendMessageW.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_size_t, ctypes.c_void_p]
        user32.SendMessageW.restype = ctypes.c_ssize_t
        hwnd = user32.FindWindowW(None, 'VisionOps AI Studio')
        if not hwnd:
            logging.info('Native window not yet visible; pywebview icon setting used instead')
            return
        IMAGE_ICON = 1
        LR_LOADFROMFILE = 0x10
        WM_SETICON = 0x80
        for size in (0, 1):  # ICON_SMALL and ICON_BIG
            hicon = user32.LoadImageW(None, str(ICON), IMAGE_ICON,
                                      16 if size == 0 else 32,
                                      16 if size == 0 else 32, LR_LOADFROMFILE)
            if hicon:
                user32.SendMessageW(hwnd, WM_SETICON, size, hicon)
        logging.info('VisionOps native window icon applied')
    except Exception:
        logging.exception('Windows taskbar icon could not be set')




def _windows_work_area(hwnd=None):
    """Usable monitor rectangle. Prefer the monitor holding the window."""
    if os.name != 'nt':
        return None
    try:
        from ctypes import wintypes
        class RECT(ctypes.Structure):
            _fields_ = [('left', ctypes.c_long), ('top', ctypes.c_long),
                        ('right', ctypes.c_long), ('bottom', ctypes.c_long)]
        class MONITORINFO(ctypes.Structure):
            _fields_ = [('cbSize', wintypes.DWORD), ('rcMonitor', RECT),
                        ('rcWork', RECT), ('dwFlags', wintypes.DWORD)]
        user32 = ctypes.windll.user32
        if hwnd:
            user32.MonitorFromWindow.argtypes = [ctypes.c_void_p, wintypes.DWORD]
            user32.MonitorFromWindow.restype = ctypes.c_void_p
            mon = user32.MonitorFromWindow(hwnd, 2)  # MONITOR_DEFAULTTONEAREST
            if mon:
                mi = MONITORINFO()
                mi.cbSize = ctypes.sizeof(MONITORINFO)
                user32.GetMonitorInfoW.argtypes = [ctypes.c_void_p, ctypes.POINTER(MONITORINFO)]
                if user32.GetMonitorInfoW(mon, ctypes.byref(mi)):
                    return mi.rcWork.left, mi.rcWork.top, mi.rcWork.right, mi.rcWork.bottom
        work=RECT()
        if user32.SystemParametersInfoW(48, 0, ctypes.byref(work), 0):
            return work.left,work.top,work.right,work.bottom
    except Exception:
        logging.exception('Screen work area detection failed')
    return None


def _initial_window_size():
    area = _windows_work_area()
    if area is None:
        return (1100, 720)
    l,t,r,b=area
    return (max(640,min(1420,int((r-l)*.91))),
            max(480,min(900,int((b-t)*.90))))


def _center_native_window():
    """Move and if necessary shrink the real desktop window to the active monitor."""
    if os.name != 'nt':
        return
    try:
        class RECT(ctypes.Structure):
            _fields_=[('left',ctypes.c_long),('top',ctypes.c_long),
                      ('right',ctypes.c_long),('bottom',ctypes.c_long)]
        user32=ctypes.windll.user32
        user32.FindWindowW.argtypes=[ctypes.c_wchar_p,ctypes.c_wchar_p]
        user32.FindWindowW.restype=ctypes.c_void_p
        hwnd=user32.FindWindowW(None,'VisionOps AI Studio')
        if not hwnd:
            logging.warning('Window not yet found to center')
            return
        area=_windows_work_area(hwnd)
        if area is None:
            return
        left,top,right,bottom=area
        rect=RECT()
        user32.GetWindowRect.argtypes=[ctypes.c_void_p,ctypes.POINTER(RECT)]
        if not user32.GetWindowRect(hwnd,ctypes.byref(rect)):
            return
        width=min(rect.right-rect.left,max(480,right-left-24))
        height=min(rect.bottom-rect.top,max(350,bottom-top-24))
        x=left+(right-left-width)//2
        y=top+(bottom-top-height)//2
        user32.SetWindowPos.argtypes=[ctypes.c_void_p,ctypes.c_void_p,
            ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_uint]
        # SWP_NOZORDER | SWP_NOACTIVATE: avoid stealing focus from another app
        user32.SetWindowPos(hwnd,None,x,y,width,height,0x0004|0x0010)
        logging.info('Centered window (%s,%s) size %sx%s',x,y,width,height)
    except Exception:
        logging.exception('Centering native window failed')


def _on_window_shown():
    _apply_windows_window_icon()
    _center_native_window()

try:
    import webview
    import app as core

    _set_windows_app_id()
    core.init_db()
    server = make_server('127.0.0.1', 0, core.app, threaded=True)
    port = server.server_port
    threading.Thread(target=server.serve_forever, daemon=True).start()
    logging.info('Local endpoint started (port %s)', port)
    initial_w,initial_h=_initial_window_size()
    window = webview.create_window(
        'VisionOps AI Studio', f'http://127.0.0.1:{port}',
        width=initial_w, height=initial_h, min_size=(640, 480), background_color='#07111f'
    )
    # Newer pywebview supports native Windows .ico; old versions fall back
    # to Win32 WM_SETICON without requiring package reinstall.
    window.events.shown += _on_window_shown
    try:
        start_args = {'debug': False}
        if ICON.is_file() and 'icon' in inspect.signature(webview.start).parameters:
            start_args['icon'] = str(ICON)
        webview.start(**start_args)
    finally:
        core.state['running'] = False
        server.shutdown()
except Exception:
    logging.exception('VisionOps Studio could not start')
    try:
        ctypes.windll.user32.MessageBoxW(
            0, f'VisionOps başlatılamadı. Hata kaydı: {LOG}',
            'VisionOps AI Studio', 0x10
        )
    except Exception:
        pass
    raise
