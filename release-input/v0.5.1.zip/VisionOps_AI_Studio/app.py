import os, time, json, sqlite3, threading, shutil
from datetime import datetime
from pathlib import Path

import cv2
from flask import Flask, Response, jsonify, request, render_template

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("VISIONOPS_DATA_DIR", Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "VisionOpsAIStudio"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "visionops.db"
LEGACY_DB = APP_DIR / "visionops.db"
if not DB_PATH.exists() and LEGACY_DB.exists():
    shutil.copy2(LEGACY_DB, DB_PATH)
app = Flask(__name__)
from security import init_security
from update_manager import init_updates
init_security(app, DATA_DIR)
init_updates(app, DATA_DIR, APP_DIR)

# ---- VisionOps optional cloud bridge (bundled for v0.4.1 updater compatibility) ----
"""VisionOps cloud bridge: optional, explicit Supabase sync, in-memory user tokens.

No access/refresh tokens or passwords are written to disk or browser storage.
Cloud data is scoped by Supabase RLS (auth.uid()).
"""
import json
import time
import uuid
import threading
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path
import secrets
from flask import jsonify, request, g, session

CLOUD_URL = 'https://uozderqllvhuiaquulhg.supabase.co'
CLOUD_PUBLISHABLE_KEY = 'sb_publishable_UynYBjWSFYyR4Samj6PeXA_gBD8OmCu'
_SESSIONS = {}  # local user id -> token data; wiped on app exit
_LOCK = threading.RLock()
_NS = uuid.UUID('f3a64975-4073-4cdd-9045-c2e329b7a453')

def _local_key():
    return (g.current_user['id'], session.get('csrf', ''))

class CloudError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def _http(path, method='GET', data=None, jwt=None, prefer=None):
    headers = {'apikey': CLOUD_PUBLISHABLE_KEY, 'Accept': 'application/json'}
    if jwt: headers['Authorization'] = 'Bearer ' + jwt
    if data is not None: headers['Content-Type'] = 'application/json'
    if prefer: headers['Prefer'] = prefer
    body = json.dumps(data).encode('utf-8') if data is not None else None
    req = urllib.request.Request(CLOUD_URL + path, data=body, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            raw = response.read(1024 * 1024)
            return json.loads(raw) if raw else None
    except urllib.error.HTTPError as e:
        try:
            error = json.loads(e.read(4096).decode('utf-8'))
            message = error.get('msg') or error.get('message') or error.get('error_description') or 'Bulut sunucusu isteği reddetti.'
        except Exception: message = 'Bulut sunucusu isteği reddetti.'
        raise CloudError(message, e.code)
    except (TimeoutError, OSError, urllib.error.URLError):
        raise CloudError('Bulut bağlantısı kurulamadı. İnternet bağlantısını kontrol et.', 503)


def _set_session(local_id, response):
    session = {
        'token': response['access_token'],
        'refresh': response.get('refresh_token'),
        'expiry': time.time() + int(response.get('expires_in', 3600)),
        'cloud_id': str(response['user']['id']),
        'email': response['user'].get('email', ''),
    }
    with _LOCK: _SESSIONS[local_id] = session
    return session


def _active_session(local_id):
    with _LOCK: s = _SESSIONS.get(local_id)
    if not s: raise CloudError('Önce bulut hesabına giriş yap.',401)
    if time.time() > s['expiry'] - 90:
        if not s.get('refresh'):
            with _LOCK: _SESSIONS.pop(local_id, None)
            raise CloudError('Bulut oturumu sona erdi. Yeniden giriş yap.',401)
        try:
            new = _http('/auth/v1/token?grant_type=refresh_token', 'POST', {'refresh_token':s['refresh']})
            new['user'] = new.get('user') or {'id':s['cloud_id'],'email':s['email']}
            s = _set_session(local_id, new)
        except CloudError:
            with _LOCK: _SESSIONS.pop(local_id, None)
            raise CloudError('Bulut oturumu sona erdi. Yeniden giriş yap.',401)
    return s


def _ensure_profile(s):
    profile = _http('/rest/v1/visionops_profiles?select=user_id,role,display_name&limit=1', jwt=s['token'])
    if not profile:
        _http('/rest/v1/visionops_profiles', 'POST', {
            'user_id':s['cloud_id'], 'role':'viewer', 'display_name':s['email'].split('@')[0][:80]
        }, jwt=s['token'], prefer='return=minimal')
        profile = _http('/rest/v1/visionops_profiles?select=user_id,role,display_name&limit=1', jwt=s['token'])
    return profile[0] if profile else {'role':'viewer'}


def init_cloud(app, db, data_dir):
    device_path = Path(data_dir) / '.cloud_device_id'
    if not device_path.exists():
        try:
            with device_path.open('x',encoding='ascii') as f: f.write(str(uuid.uuid4()))
        except FileExistsError: pass
    device_id = device_path.read_text(encoding='ascii').strip()
    @app.errorhandler(CloudError)
    def cloud_error(exc): return jsonify({'error':str(exc)}), exc.status if 400 <= exc.status < 600 else 400

    @app.get('/api/cloud/status')
    def cloud_status():
        local_id = _local_key()
        try:
            s = _active_session(local_id)
            profile = _ensure_profile(s)
            return jsonify({'connected':True, 'email':s['email'], 'role':profile.get('role','viewer'), 'project':'VisionOps AI Studio', 'store':'Supabase · Frankfurt', 'video_uploaded':False})
        except CloudError as e:
            return jsonify({'connected':False, 'message':str(e), 'project':'VisionOps AI Studio', 'store':'Supabase · Frankfurt'})

    @app.post('/api/cloud/signup')
    def cloud_signup():
        data = request.get_json(silent=True) or {}
        email = str(data.get('email','')).strip().lower()
        password = str(data.get('password',''))
        if len(email)>254 or '@' not in email or len(password)<10 or len(password)>128:
            raise CloudError('Geçerli e-posta ve en az 10 karakterli parola gir.',400)
        result = _http('/auth/v1/signup','POST',{'email':email,'password':password})
        # On hosted projects email confirmation is commonly enabled.
        if result.get('access_token') and result.get('user'):
            s = _set_session(_local_key(), result)
            _ensure_profile(s)
            return jsonify({'ok':True,'connected':True, 'message':'Bulut hesabı oluşturuldu ve bağlandı.'})
        return jsonify({'ok':True, 'connected':False, 'message':'Kayıt isteği alındı. E-postana gelen onay bağlantısını doğrulayıp bu panelden giriş yap.'})

    @app.post('/api/cloud/login')
    def cloud_login():
        data = request.get_json(silent=True) or {}
        email = str(data.get('email','')).strip().lower()
        password = str(data.get('password',''))
        if not email or not password: raise CloudError('E-posta ve parola gerekli.',400)
        token = _http('/auth/v1/token?grant_type=password','POST',{'email':email,'password':password})
        s = _set_session(_local_key(), token)
        try: profile = _ensure_profile(s)
        except CloudError:
            with _LOCK: _SESSIONS.pop(_local_key(), None)
            raise
        return jsonify({'ok':True,'connected':True,'email':s['email'],'role':profile['role']})

    @app.post('/api/cloud/logout')
    def cloud_logout():
        with _LOCK: s = _SESSIONS.pop(_local_key(), None)
        if s:
            try: _http('/auth/v1/logout','POST',{},jwt=s['token'])
            except CloudError: pass
        return jsonify({'ok':True})

    @app.get('/api/cloud/events')
    def cloud_events():
        s = _active_session(_local_key())
        rows = _http('/rest/v1/visionops_events?select=id,event_type,observed_at,details,confidence&order=observed_at.desc&limit=100',jwt=s['token'])
        return jsonify({'events':rows or [],'user':s['email']})

    @app.post('/api/cloud/sync')
    def cloud_sync():
        """User-triggered upload; deterministic IDs avoid duplicates across restarts.
        For prototype only 200 recent events per request; never transmits frames.
        """
        s = _active_session(_local_key())
        _ensure_profile(s)
        with db() as conn:
            rows = conn.execute('SELECT id,ts,event_type,zone_name,track_id,detail FROM events ORDER BY id DESC LIMIT 200').fetchall()
        payload = []
        for r in reversed(rows):
            rd = dict(r)
            try:
                dt = datetime.fromisoformat(rd['ts'])
                if dt.tzinfo is None: dt = dt.replace(tzinfo=timezone.utc)
                observed_at = dt.astimezone(timezone.utc).isoformat()
            except (ValueError,TypeError): continue
            cloud_event_id = str(uuid.uuid5(_NS, s['cloud_id']+':'+device_id+':'+str(rd['id'])))
            payload.append({'id':cloud_event_id,'user_id':s['cloud_id'],'event_type':rd['event_type'][:80],
                            'observed_at':observed_at,'details':{'zone':rd['zone_name'], 'track_id':rd['track_id'], 'description':(rd['detail'] or '')[:180], 'source':'VisionOps Desktop'}})
        if payload:
            _http('/rest/v1/visionops_events?on_conflict=id','POST',payload,jwt=s['token'],prefer='resolution=ignore-duplicates,return=minimal')
        return jsonify({'ok':True,'processed':len(payload), 'message':'Son 200 yerel olay buluta aktarıldı; aynı olaylar tekrar eklenmez. Kamera görüntüsü aktarılmadı.'})


init_cloud(app, lambda: db(), DATA_DIR)


state = {
    "camera": None, "running": False, "camera_ready": False, "frame": None, "lock": threading.Lock(),
    "thread": None, "source": 0, "error": None, "model_status": "Henüz yüklenmedi",
    "detector": None, "last_detections": [], "tracks": {}, "next_track": 1,
    "zone_states": {}, "last_event": 0, "fps": 0.0, "frame_count": 0
}

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT NOT NULL, event_type TEXT NOT NULL, zone_name TEXT,
            track_id INTEGER, detail TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS zones(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
            zone_type TEXT NOT NULL, x REAL NOT NULL, y REAL NOT NULL,
            w REAL NOT NULL, h REAL NOT NULL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT)""")
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('camera_source','0')")
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('confidence','0.35')")

def log_event(event_type, zone=None, track_id=None, detail=""):
    now = datetime.now().astimezone().isoformat(timespec="seconds")
    with db() as c:
        c.execute("INSERT INTO events(ts,event_type,zone_name,track_id,detail) VALUES(?,?,?,?,?)",
                  (now, event_type, zone, track_id, detail))

def load_zones():
    with db() as c:
        return [dict(r) for r in c.execute("SELECT * FROM zones ORDER BY id").fetchall()]

def load_detector():
    try:
        from ultralytics import YOLO
        model_path = APP_DIR / "yolov8n.pt"
        state["detector"] = YOLO(str(model_path) if model_path.exists() else "yolov8n.pt")
        state["model_status"] = "YOLOv8n hazır"
        return True
    except Exception as e:
        state["model_status"] = "Model yüklenemedi: " + str(e)[:160]
        state["error"] = state["model_status"]
        return False

def detect_cats(frame):
    model = state["detector"]
    if model is None:
        return []
    try:
        results = model.predict(frame, conf=float(get_setting("confidence", "0.35")), classes=[15], verbose=False, imgsz=640)
        detections = []
        for r in results:
            if r.boxes is None: continue
            for b in r.boxes:
                x1,y1,x2,y2 = [int(v) for v in b.xyxy[0].tolist()]
                conf = float(b.conf[0])
                detections.append({"x":x1,"y":y1,"w":x2-x1,"h":y2-y1,"cx":(x1+x2)//2,"cy":(y1+y2)//2,"conf":conf})
        return detections
    except Exception as e:
        state["error"] = "Algılama hatası: " + str(e)[:120]
        return []

def get_setting(key, default=None):
    with db() as c:
        row = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default

def assign_tracks(detections):
    # Lightweight centroid association; adequate for one cat / one fixed camera prototype.
    tracks = state["tracks"]
    now = time.time()
    used = set()
    for d in detections:
        best_id, best_dist = None, 10**9
        for tid, tr in tracks.items():
            if tid in used: continue
            dx,dy=d["cx"]-tr["cx"],d["cy"]-tr["cy"]
            dist=(dx*dx+dy*dy)**0.5
            if dist < best_dist: best_id,best_dist=tid,dist
        if best_id is not None and best_dist < 130:
            tid=best_id
        else:
            tid=state["next_track"]; state["next_track"] += 1
            tracks[tid]={"zones":set(),"cx":d["cx"],"cy":d["cy"],"seen":now}
            log_event("cat_detected", None, tid, "Kedi algılandı")
        d["track_id"]=tid
        tr=tracks[tid]; tr.update(cx=d["cx"],cy=d["cy"],seen=now)
        used.add(tid)
    for tid in list(tracks):
        if now-tracks[tid]["seen"] > 3:
            del tracks[tid]
            # Track lost event can be interpreted as left camera view, not necessarily room.
            log_event("cat_lost_view", None, tid, "Kedi kamera görüşünden çıktı")
    return detections

def process_zones(detections, zones):
    # Compare the current set of occupied zones with the previous frame's set.
    # Enter/exit events are emitted once per transition, not once per zone loop.
    for d in detections:
        tid = d["track_id"]
        tr = state["tracks"].get(tid)
        if tr is None:
            continue
        current = set()
        fw, fh = state.get("frame_size", (640, 480))
        for z in zones:
            x, y = z["x"] * fw, z["y"] * fh
            w, h = z["w"] * fw, z["h"] * fh
            if x <= d["cx"] <= x + w and y <= d["cy"] <= y + h:
                current.add(z["id"])
        previous = set(tr.get("zones", set()))
        zone_by_id = {z["id"]: z for z in zones}
        for zid in current - previous:
            z = zone_by_id.get(zid)
            if z:
                log_event("zone_enter", z["name"], tid, z["zone_type"])
        for zid in previous - current:
            z = zone_by_id.get(zid)
            if z:
                log_event("zone_exit", z["name"], tid, z["zone_type"])
        tr["zones"] = current

def list_cameras():
    """Enumerate DirectShow friendly names without opening camera streams."""
    try:
        from pygrabber.dshow_graph import FilterGraph
        names = FilterGraph().get_input_devices()
        return [{"id": i, "name": name, "preferred": "obs" in name.lower()} for i, name in enumerate(names)]
    except Exception as exc:
        state["device_error"] = str(exc)[:180]
        return []


def open_camera(source):
    """Open ONLY the selected camera. Prefer OBS, never silently select Fujifilm's warning slate."""
    devices = list_cameras()
    if str(source).lower() in ("obs", "auto"):
        obs = [d for d in devices if "obs" in d["name"].lower()]
        if not obs:
            return None, None, None, ("OBS Virtual Camera aygiti bulunamadi. OBS icinde "
                "Sanal Kamerayi Baslat'a basin. Aygitlar: " + ", ".join(d["name"] for d in devices))
        indices = [d["id"] for d in obs]
    else:
        try: indices = [int(source)]
        except (ValueError, TypeError): return None, None, None, "Gecersiz kamera secimi"
    errors = []
    for index in indices:
        # DirectShow index corresponds to pygrabber device order.
        for backend_name, backend in (("DirectShow", cv2.CAP_DSHOW), ("MediaFoundation", cv2.CAP_MSMF)):
            cap = None
            success = False
            try:
                cap = cv2.VideoCapture(index, backend)
                if not cap.isOpened():
                    errors.append(f"{index}/{backend_name}: acilamadi")
                    continue
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
                for attempt in range(18):
                    ok, frame = cap.read()
                    if ok and frame is not None and frame.size and float(frame.mean()) > 2:
                        success = True
                        return cap, frame, index, backend_name
                    time.sleep(.10)
                errors.append(f"{index}/{backend_name}: goruntu yok")
            except Exception as exc:
                errors.append(f"{index}/{backend_name}: {str(exc)[:80]}")
            finally:
                if cap is not None:
                    if not success:
                        cap.release()
    return None, None, None, "; ".join(errors[-6:])

def camera_loop():
    cap = None
    try:
        cap, first_frame, index, backend = open_camera(state["source"])
        if cap is None:
            state["error"] = ("Kamera goruntusu alinamadi. OBS'de Fujifilm goruntusunu ac, "
                "Sanal Kamerayi Baslat'a bas, VisionOps'ta Otomatik veya kamera indeksini sec. "
                "Ayrinti: " + str(backend))[:500]
            return
        state["active_camera"] = f"{index} / {backend}"
        state["camera_ready"] = True
        state["source"] = index
        state["error"] = None
        # Publish image immediately; model download/loading can take minutes.
        with state["lock"]:
            state["frame"] = first_frame.copy()
        load_detector()
        last = time.time()
        failed = 0
        while state["running"]:
            ok, frame = cap.read()
            if not ok or frame is None:
                failed += 1
                if failed >= 30:
                    state["error"] = "Kamera goruntusu kesildi. OBS Sanal Kamera'yi kontrol et."
                    break
                time.sleep(.1)
                continue
            failed = 0
            h,w=frame.shape[:2]
            state["frame_size"]=(w,h)
            state["frame_count"] += 1
            if state["frame_count"] % 3 == 0 and state["detector"] is not None:
                dets=assign_tracks(detect_cats(frame))
                process_zones(dets, load_zones())
                state["last_detections"]=dets
            for d in state["last_detections"]:
                x,y,ww,hh=d["x"],d["y"],d["w"],d["h"]
                cv2.rectangle(frame,(x,y),(x+ww,y+hh),(80,230,150),2)
                cv2.putText(frame,f"Kedi #{d['track_id']} {d['conf']:.0%}",(x,max(20,y-8)),cv2.FONT_HERSHEY_SIMPLEX,.55,(80,230,150),2)
            state["fps"]=1/max(.001,time.time()-last); last=time.time()
            with state["lock"]:
                state["frame"]=frame.copy()
            time.sleep(.01)
    except Exception as e:
        state["error"] = "Kamera isleme hatasi: " + str(e)[:300]
    finally:
        if cap is not None: cap.release()
        state["running"] = False
        state["camera_ready"] = False

def mjpeg():
    while True:
        with state["lock"]:
            frame = None if state["frame"] is None else state["frame"].copy()
        if frame is None:
            # Placeholder frame
            img = __import__("numpy").zeros((360,640,3),dtype="uint8")
            cv2.putText(img,"VisionOps AI - Kamera bekleniyor",(30,180),cv2.FONT_HERSHEY_SIMPLEX,.8,(180,210,220),2)
        else: img=frame
        ok,buf=cv2.imencode(".jpg",img,[int(cv2.IMWRITE_JPEG_QUALITY),80])
        if ok:
            yield (b"--frame\r\nContent-Type: image/jpeg\r\n\r\n"+buf.tobytes()+b"\r\n")
        time.sleep(.08)

@app.route("/")
def index(): return render_template("index.html")

@app.route("/video")
def video(): return Response(mjpeg(),mimetype="multipart/x-mixed-replace; boundary=frame")

@app.route("/api/cameras")
def cameras():
    devices = list_cameras()
    return jsonify({"devices": devices, "error": state.get("device_error"), "obs_found": any(d["preferred"] for d in devices)})

@app.route("/api/status")
def status():
    with db() as c:
        total=c.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        today=datetime.now().astimezone().date().isoformat()
        today_events=c.execute("SELECT COUNT(*) FROM events WHERE ts LIKE ?",(today+"%",)).fetchone()[0]
        cats=c.execute("SELECT COUNT(*) FROM events WHERE event_type='cat_detected' AND ts LIKE ?",(today+"%",)).fetchone()[0]
    return jsonify({"running":state["running"],"streaming":state["camera_ready"],"error":state["error"],"model":state["model_status"],
        "fps":round(state["fps"],1),"active_camera":state.get("active_camera"),"events":total,"today_events":today_events,"cat_detections_today":cats,
        "zones":len(load_zones()),"source":state["source"]})

@app.route("/api/start",methods=["POST"])
def start_camera():
    if state["running"]: return jsonify({"ok":True,"message":"Kamera zaten çalışıyor."})
    if state.get("thread") and state["thread"].is_alive():
        return jsonify({"ok":False,"error":"Önceki kamera kapatılıyor; birkaç saniye sonra tekrar deneyin."}),409
    data=request.get_json(silent=True) or {}
    source=data.get("source",get_setting("camera_source","0"))
    try:
        source = str(source).lower() if str(source).lower() in ("auto", "obs") else int(source)
        if isinstance(source, int) and not 0 <= source <= 30: raise ValueError()
    except (ValueError, TypeError): return jsonify({"ok":False,"error":"Geçersiz kamera kaynağı."}),400
    state["source"]=source; state["error"]=None; state["running"]=True; state["camera_ready"]=False
    with state["lock"]: state["frame"] = None
    state["thread"]=threading.Thread(target=camera_loop,daemon=True); state["thread"].start()
    return jsonify({"ok":True,"message":"Kamera başlatılıyor."})

@app.route("/api/stop",methods=["POST"])
def stop_camera():
    state["running"]=False
    state["camera_ready"]=False
    thread = state.get("thread")
    if thread and thread.is_alive(): thread.join(timeout=2)
    return jsonify({"ok":True})

@app.route("/api/zones")
def zones(): return jsonify(load_zones())

@app.route("/api/zones",methods=["POST"])
def save_zone():
    d=request.get_json()
    name=str(d.get("name","Yeni alan")).strip()[:50]
    ztype=str(d.get("zone_type","custom"))
    allowed={"entry","food","water","litter","custom"}
    if ztype not in allowed: ztype="custom"
    x=max(0,min(1,float(d.get("x",0)))); y=max(0,min(1,float(d.get("y",0))))
    w=max(.01,min(1-x,float(d.get("w",.2)))); h=max(.01,min(1-y,float(d.get("h",.2))))
    with db() as c:
        cur=c.execute("INSERT INTO zones(name,zone_type,x,y,w,h) VALUES(?,?,?,?,?,?)",(name,ztype,x,y,w,h))
        zid=cur.lastrowid
    return jsonify({"ok":True,"id":zid})

@app.route("/api/zones/<int:zid>",methods=["DELETE"])
def delete_zone(zid):
    with db() as c: c.execute("DELETE FROM zones WHERE id=?",(zid,))
    return jsonify({"ok":True})

@app.route("/api/events")
def events():
    limit=min(200,max(1,int(request.args.get("limit",100))))
    with db() as c:
        rows=[dict(r) for r in c.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?",(limit,)).fetchall()]
    return jsonify(rows)

@app.route("/api/summary")
def summary():
    today=datetime.now().astimezone().date().isoformat()
    with db() as c:
        rows=c.execute("SELECT event_type,zone_name,COUNT(*) n FROM events WHERE ts LIKE ? GROUP BY event_type,zone_name",(today+"%",)).fetchall()
    counts={"cat_detected":0,"cat_lost_view":0,"zone_enter":0,"zone_exit":0}
    zone_counts={}
    for r in rows:
        counts[r["event_type"]]=counts.get(r["event_type"],0)+r["n"]
        if r["event_type"]=="zone_enter" and r["zone_name"]:
            zone_counts[r["zone_name"]]=zone_counts.get(r["zone_name"],0)+r["n"]
    return jsonify({"counts":counts,"zones":zone_counts})

@app.route("/api/reports/ten-minute")
def ten_minute_report():
    """Aggregated event observations in ten-minute time buckets, local time."""
    today = datetime.now().astimezone().date().isoformat()
    with db() as c:
        rows = c.execute("SELECT ts,event_type,zone_name FROM events WHERE ts LIKE ? ORDER BY ts", (today+"%",)).fetchall()
    buckets = {}
    for r in rows:
        try:
            stamp = datetime.fromisoformat(r["ts"])
            minute = (stamp.minute // 10) * 10
            key = stamp.strftime("%H:") + f"{minute:02d}"
        except (ValueError, TypeError):
            continue
        bucket = buckets.setdefault(key, {"time":key,"detections":0,"visits":0,"lost":0})
        if r["event_type"] == "cat_detected": bucket["detections"] += 1
        elif r["event_type"] == "zone_enter": bucket["visits"] += 1
        elif r["event_type"] == "cat_lost_view": bucket["lost"] += 1
    return jsonify({"date":today,"interval_minutes":10,"buckets":list(buckets.values()),
        "note":"Bu sayılar gözlem olaylarıdır; yemek/su tüketimi veya gerçek oda çıkışı kanıtı değildir."})

@app.route("/api/events/clear",methods=["POST"])
def clear_events():
    with db() as c: c.execute("DELETE FROM events")
    state["tracks"]={}; state["next_track"]=1
    return jsonify({"ok":True})

@app.route("/api/info")
def info():
    from flask import session
    version = json.loads((APP_DIR / "version.json").read_text(encoding="utf-8"))["version"]
    return jsonify({"version": version, "user": session.get("username"), "role": session.get("role"), "local": True})

if __name__ == "__main__":
    init_db()
    print("VisionOps AI yerel sunucu: http://127.0.0.1:5000", flush=True)
    app.run(host="127.0.0.1",port=5000,debug=False,threaded=True)
