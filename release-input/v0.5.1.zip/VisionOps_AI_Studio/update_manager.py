"""Conservative GitHub Releases update checker/stager. Applies only after app exits."""
import hashlib
import json
import os
import re
import shutil
import sys
import time
import urllib.request
import urllib.error
import zipfile
from pathlib import Path
from flask import jsonify, request, session

MAX_ZIP = 50*1024*1024
MAX_UNPACK = 160*1024*1024
ASSET = 'VisionOps_AI_Studio_update.zip'
ALLOWED = {
 'app.py','security.py','update_manager.py','studio.py','launcher.pyw',
 'version.json','requirements.txt','VisionOps.ico',
 'templates/index.html','templates/login.html',
 'static/dashboard.css','static/dashboard.js'
}
REPO = re.compile(r'^[A-Za-z0-9_.-]{1,100}$')


def current_version(root):
    try: return json.loads((root/'version.json').read_text(encoding='utf-8'))['version']
    except Exception: return '0.4.0'

def semver(v):
    match=re.match(r'^v?(\d+)\.(\d+)\.(\d+)(?:$|[-+])',str(v))
    return tuple(map(int,match.groups())) if match else None

def read_config(data):
    path=data/'updates.json'
    if not path.exists(): return {'owner':'furkovskii','repo':'visionops-ai-studio-updates'}
    try:
        cfg=json.loads(path.read_text(encoding='utf-8'))
        if not cfg.get('owner') or not cfg.get('repo'):
            return {'owner':'furkovskii','repo':'visionops-ai-studio-updates'}
        return cfg
    except Exception: return {'owner':'furkovskii','repo':'visionops-ai-studio-updates'}

def safe_write(path, val):
    tmp=path.with_name(path.name+'.tmp')
    tmp.write_text(json.dumps(val,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(path)

def github_release(config):
    owner,repo=config.get('owner',''),config.get('repo','')
    if not REPO.fullmatch(owner) or not REPO.fullmatch(repo):
        raise ValueError('Ücretsiz GitHub deposu henüz bağlanmadı. Önce kullanıcı/depo adını girin.')
    url=f'https://api.github.com/repos/{owner}/{repo}/releases/latest'
    req=urllib.request.Request(url, headers={'Accept':'application/vnd.github+json','User-Agent':'VisionOpsAIStudio-Updater/0.4'})
    try:
        with urllib.request.urlopen(req,timeout=12) as r:
            raw=r.read(512*1024+1)
            if len(raw)>512*1024: raise ValueError('Sürüm yanıtı çok büyük.')
            return json.loads(raw)
    except urllib.error.HTTPError as e:
        if e.code==404: raise ValueError('Bu depoda herkese açık bir sürüm bulunamadı (404).') from e
        raise ValueError(f'GitHub yanıtı: HTTP {e.code}') from e
    except urllib.error.URLError as e:
        raise ValueError('İnternet bağlantısı veya GitHub erişimi başarısız.') from e

def parse_release(release, root):
    version=str(release.get('tag_name','')).lstrip('v')
    if not semver(version): raise ValueError('GitHub sürüm etiketi geçersiz (örn. v0.5.0).')
    found=next((a for a in release.get('assets',[]) if a.get('name')==ASSET),None)
    return {
       'current':current_version(root),'latest':version,
       'available':bool(semver(current_version(root)) and semver(version)>semver(current_version(root))),
       'asset': bool(found), 'digest': (found or {}).get('digest'),
       'url': (found or {}).get('browser_download_url'),
       'notes':str(release.get('body') or '')[:2000],
    }

def download_release(info, data):
    url=info.get('url') or ''
    if not url.startswith('https://github.com/') or not info.get('digest','').startswith('sha256:'):
        raise ValueError('Güncelleme dosyasının güvenilir indirme adresi veya SHA-256 özeti yok.')
    target=data/'download.tmp'
    req=urllib.request.Request(url,headers={'User-Agent':'VisionOpsAIStudio-Updater/0.4'})
    h=hashlib.sha256(); size=0
    try:
        with urllib.request.urlopen(req,timeout=30) as response, target.open('wb') as dst:
            while True:
                chunk=response.read(1024*1024)
                if not chunk:break
                size+=len(chunk)
                if size>MAX_ZIP:raise ValueError('Güncelleme dosyası boyut sınırını aşıyor.')
                h.update(chunk);dst.write(chunk)
        if 'sha256:'+h.hexdigest()!=info['digest']:
            raise ValueError('Güncelleme dosyasının SHA-256 doğrulaması başarısız!')
        return target
    except Exception:
        target.unlink(missing_ok=True)
        raise

def stage_package(package, data, root, target_version=None):
    path=Path(package)
    if path.stat().st_size>MAX_ZIP:raise ValueError('Güncelleme çok büyük.')
    stage=data/'update_staged'
    if stage.exists():shutil.rmtree(stage)
    stage.mkdir(parents=True)
    size=0
    try:
        with zipfile.ZipFile(path) as archive:
            candidates=[]
            for info in archive.infolist():
                if info.is_dir():continue
                raw=info.filename.replace('\\','/')
                parts=raw.split('/')
                if 'VisionOps_AI_Studio' in parts:
                    raw='/'.join(parts[parts.index('VisionOps_AI_Studio')+1:])
                if raw not in ALLOWED:raise ValueError('Paket beklenmeyen dosya içeriyor: '+raw[:80])
                if info.external_attr >> 16 & 0o170000 == 0o120000:
                    raise ValueError('Paket bağlantı dosyası içeriyor.')
                size+=info.file_size
                if size>MAX_UNPACK:raise ValueError('Paket açılım boyutu güvenlik sınırını aşıyor.')
                candidates.append((info,raw))
            if not {'app.py','version.json','templates/index.html','security.py','update_manager.py'} <= set(p for _,p in candidates):
                raise ValueError('Eksik uygulama dosyaları.')
            version=json.loads(archive.read(next(i for i,p in candidates if p=='version.json')))['version']
            if semver(version) is None or (target_version and version!=target_version):
                raise ValueError('Güncelleme sürümü uyuşmuyor.')
            if semver(version)<=semver(current_version(root)):
                raise ValueError('Kurulu sürümden daha yeni bir paket gerekli.')
            for info, rel in candidates:
                dest=stage/rel;dest.parent.mkdir(parents=True,exist_ok=True)
                with archive.open(info) as src, dest.open('wb') as out:
                    shutil.copyfileobj(src,out)
        safe_write(data/'update_pending.json',{'version':version,'staged':str(stage)})
        return version
    except Exception:
        shutil.rmtree(stage,ignore_errors=True)
        raise

def apply_pending(data, root):
    """Called by hidden launcher *before* starting the desktop process."""
    pending=data/'update_pending.json'
    if not pending.exists():return False
    info=json.loads(pending.read_text(encoding='utf-8'))
    staged=data/'update_staged'
    if Path(info.get('staged','')).resolve()!=staged.resolve():
        raise ValueError('Güncelleme hazırlığı bozuk.')
    backup=data/'update_previous'
    if backup.exists():shutil.rmtree(backup)
    backup.mkdir(parents=True)
    changed=[]
    try:
        for relative in sorted(ALLOWED):
            source=staged/relative
            if not source.is_file():continue
            original=root/relative
            if original.is_file():
                dest=backup/relative;dest.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(original,dest)
            original.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(source,original)
            changed.append(relative)
        pending.unlink()
        shutil.rmtree(staged,ignore_errors=True)
        return True
    except Exception:
        for relative in changed:
            saved=backup/relative
            if saved.is_file():shutil.copy2(saved,root/relative)
            else:(root/relative).unlink(missing_ok=True)
        raise

def init_updates(app, data, root):
    def admin():return session.get('role')=='admin'
    @app.route('/api/updates/config',methods=['GET','POST'])
    def updates_config():
        if request.method=='GET':
            cfg=read_config(data)
            return jsonify({'owner':cfg.get('owner',''),'repo':cfg.get('repo',''),
                            'version':current_version(root),'pending':(data/'update_pending.json').exists()})
        if not admin():return jsonify({'error':'Yönetici yetkisi gerekiyor.'}),403
        cfg=request.get_json(silent=True) or {}
        owner=str(cfg.get('owner','')).strip();repo=str(cfg.get('repo','')).strip()
        if (owner or repo) and (not REPO.fullmatch(owner) or not REPO.fullmatch(repo)):
            return jsonify({'error':'Geçerli GitHub kullanıcı ve depo adı girin.'}),400
        safe_write(data/'updates.json',{'owner':owner,'repo':repo})
        return jsonify({'ok':True})

    @app.route('/api/updates/check',methods=['POST'])
    def updates_check():
        if not admin():return jsonify({'error':'Yönetici yetkisi gerekiyor.'}),403
        try:return jsonify(parse_release(github_release(read_config(data)),root))
        except Exception as e:return jsonify({'error':str(e)}),400

    @app.route('/api/updates/download',methods=['POST'])
    def updates_download():
        if not admin():return jsonify({'error':'Yönetici yetkisi gerekiyor.'}),403
        try:
            info=parse_release(github_release(read_config(data)),root)
            if not info['available'] or not info['asset']:raise ValueError('İndirilebilir yeni sürüm bulunamadı.')
            tmp=download_release(info,data)
            try: version=stage_package(tmp,data,root,info['latest'])
            finally:tmp.unlink(missing_ok=True)
            return jsonify({'ok':True,'version':version,'message':'Güncelleme hazır. Uygulamayı kapatıp masaüstü simgesinden yeniden açın.'})
        except Exception as e:return jsonify({'error':str(e)}),400

    @app.route('/api/updates/upload',methods=['POST'])
    def updates_upload():
        if not admin():return jsonify({'error':'Yönetici yetkisi gerekiyor.'}),403
        upload=request.files.get('file')
        if not upload or not upload.filename.lower().endswith('.zip'):
            return jsonify({'error':'ZIP güncelleme paketi seçin.'}),400
        tmp=data/'manual_update.tmp'
        try:
            upload.save(tmp)
            version=stage_package(tmp,data,root)
            return jsonify({'ok':True,'version':version,'message':'Güncelleme hazır. Uygulamayı kapatıp tekrar açın.'})
        except Exception as e:return jsonify({'error':str(e)}),400
        finally:tmp.unlink(missing_ok=True)

if __name__ == '__main__' and '--apply' in sys.argv:
    source=Path(__file__).resolve().parent
    data=Path(os.environ.get('VISIONOPS_DATA_DIR',Path(os.environ.get('LOCALAPPDATA',str(Path.home())))/'VisionOpsAIStudio'))
    apply_pending(data,source)
