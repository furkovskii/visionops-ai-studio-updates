import os, time, json, sqlite3, threading, shutil
from datetime import datetime
from pathlib import Path

import cv2
from flask import Flask, Response, jsonify, request, render_template

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("VISIONOPS_DATA_DIR", Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "VisionOpsAIStudio"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "visionops.db"
LEGACY_DB = APP_DIR / "visionops.db"
if not DB_PATH.exists() and LEGACY_DB.exists():
    shutil.copy2(LEGACY_DB, DB_PATH)
app = Flask(__name__)
from security import init_security
from update_manager import init_updates
init_security(app, DATA_DIR)
init_updates(app, DATA_DIR, APP_DIR)
# v0.9.4: opt-in encrypted backups; no passwords persisted.
from flask import send_file, session
from io import BytesIO
@app.post('/api/security/backup/export')
def export_secured_backup():
    if session.get('role')!='admin':
        return jsonify({'error':'Yönetici yetkisi gerekiyor.'}),403
    body=request.get_json(silent=True) or {}
    password=str(body.get('passphrase',''))
    if len(password)<12 or len(password)>256:
        return jsonify({'error':'12-256 karakterli, benzersiz bir yedek parolası girin.'}),400
    try:
        from secure_backup import create_encrypted_backup
        from datetime import datetime
        blob=create_encrypted_backup(DATA_DIR,password)
        return send_file(BytesIO(blob),as_attachment=True,mimetype='application/octet-stream',
             download_name='VisionOps_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.vopsbak')
    except ImportError:
        return jsonify({'error':'Şifreleme kitaplığı eksik. Bir defa kurulumu yenileyin.'}),503
    except Exception as exc:
        return jsonify({'error':'Yedek oluşturulamadı: '+str(exc)}),400


# ---- VisionOps optional cloud bridge (bundled for v0.4.1 updater compatibility) ----
"""VisionOps cloud bridge: optional, explicit Supabase sync, in-memory user tokens.

No access/refresh tokens or passwords are written to disk or browser storage.
Cloud data is scoped by Supabase RLS (auth.uid()).
"""
import json
import time
import uuid
import threading
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path
import secrets
from secure_store import save as dpapi_save, read as dpapi_read, delete as dpapi_delete
from flask import jsonify, request, g, session, redirect, render_template

CLOUD_URL = 'https://uozderqllvhuiaquulhg.supabase.co'
CLOUD_PUBLISHABLE_KEY = 'sb_publishable_UynYBjWSFYyR4Samj6PeXA_gBD8OmCu'
_SESSIONS = {}  # local user id -> token data; wiped on app exit
for _old_token in DATA_DIR.glob('cloud_refresh_*.bin'):
    try: _old_token.unlink()
    except OSError: pass
_LOCK = threading.RLock()
_NS = uuid.UUID('f3a64975-4073-4cdd-9045-c2e329b7a453')

def _local_key():
    return g.current_user['id']

class CloudError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def _http(path, method='GET', data=None, jwt=None, prefer=None):
    headers = {'apikey': CLOUD_PUBLISHABLE_KEY, 'Accept': 'application/json'}
    if jwt: headers['Authorization'] = 'Bearer ' + jwt
    if data is not None: headers['Content-Type'] = 'application/json'
    if prefer: headers['Prefer'] = prefer
    body = json.dumps(data).encode('utf-8') if data is not None else None
    req = urllib.request.Request(CLOUD_URL + path, data=body, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            raw = response.read(1024 * 1024)
            return json.loads(raw) if raw else None
    except urllib.error.HTTPError as e:
        try:
            error = json.loads(e.read(4096).decode('utf-8'))
            message = error.get('msg') or error.get('message') or error.get('error_description') or 'Bulut sunucusu isteği reddetti.'
        except Exception: message = 'Bulut sunucusu isteği reddetti.'
        raise CloudError(message, e.code)
    except (TimeoutError, OSError, urllib.error.URLError):
        raise CloudError('Bulut bağlantısı kurulamadı. İnternet bağlantısını kontrol et.', 503)


def _set_session(local_id, response, remember=None):
    session = {
        'token': response['access_token'],
        'refresh': response.get('refresh_token'),
        'expiry': time.time() + int(response.get('expires_in', 3600)),
        'cloud_id': str(response['user']['id']),
        'email': response['user'].get('email', ''),
    }
    with _LOCK: _SESSIONS[local_id] = session
    if remember is True:
        (DATA_DIR / ('cloud_email_'+str(local_id)+'.txt')).write_text(session.get('email',''),encoding='utf-8')
    elif remember is False:
        (DATA_DIR / ('cloud_email_'+str(local_id)+'.txt')).unlink(missing_ok=True)
    dpapi_delete(DATA_DIR / ('cloud_refresh_'+str(local_id)+'.bin'))
    return session


def _active_session(local_id):
    with _LOCK: s = _SESSIONS.get(local_id)
    if not s:
        raise CloudError('Bulut bağlantısı için panel içinden giriş yap.',401)
    if time.time() > s['expiry'] - 90:
        if not s.get('refresh'):
            with _LOCK: _SESSIONS.pop(local_id, None)
            raise CloudError('Bulut oturumu sona erdi. Yeniden giriş yap.',401)
        try:
            new = _http('/auth/v1/token?grant_type=refresh_token', 'POST', {'refresh_token':s['refresh']})
            new['user'] = new.get('user') or {'id':s['cloud_id'],'email':s['email']}
            s = _set_session(local_id, new)
        except CloudError:
            with _LOCK: _SESSIONS.pop(local_id, None)
            raise CloudError('Bulut oturumu sona erdi. Yeniden giriş yap.',401)
    return s


def _ensure_profile(s):
    profile = _http('/rest/v1/visionops_profiles?select=user_id,role,display_name&limit=1', jwt=s['token'])
    if not profile:
        _http('/rest/v1/visionops_profiles', 'POST', {
            'user_id':s['cloud_id'], 'role':'viewer', 'display_name':s['email'].split('@')[0][:80]
        }, jwt=s['token'], prefer='return=minimal')
        profile = _http('/rest/v1/visionops_profiles?select=user_id,role,display_name&limit=1', jwt=s['token'])
    return profile[0] if profile else {'role':'viewer'}


def _sync_batch(local_id, db_factory, device_id, data_dir, batch_size=80):
    """Idempotent, cursor-based upload; tokens never persisted and frames never uploaded."""
    s=_active_session(local_id)
    user=s['cloud_id']
    cursor_path=Path(data_dir)/('sync_cursor_'+user+'.json')
    try: cursor=int(json.loads(cursor_path.read_text(encoding='utf-8')).get(device_id,0)) if cursor_path.exists() else 0
    except (ValueError,TypeError,json.JSONDecodeError,OSError):cursor=0
    with db_factory() as conn:
        rows=conn.execute('SELECT id,ts,event_type,zone_name,track_id,detail FROM events WHERE id>? ORDER BY id ASC LIMIT ?', (cursor,batch_size)).fetchall()
    payload=[]
    for r in rows:
        rd=dict(r)
        try:
            dt=datetime.fromisoformat(rd['ts'])
            if dt.tzinfo is None:dt=dt.replace(tzinfo=timezone.utc)
            t=dt.astimezone(timezone.utc).isoformat()
        except (ValueError,TypeError):continue
        ident=str(uuid.uuid5(_NS,user+':'+device_id+':'+str(rd['id'])))
        payload.append({'id':ident,'user_id':user,'event_type':rd['event_type'][:80],
                        'observed_at':t,'details':{'zone':rd['zone_name'],'track_id':rd['track_id'],
                        'description':(rd['detail'] or '')[:180],'source':'VisionOps Desktop'}})
    if payload:
        _http('/rest/v1/visionops_events?on_conflict=id','POST',payload,jwt=s['token'],prefer='resolution=ignore-duplicates,return=minimal')
    if rows:
        last_id=rows[-1]['id']
        # Preserve cursors for all accounts if same PC is used by several people.
        try: all_cursors=json.loads(cursor_path.read_text(encoding='utf-8')) if cursor_path.exists() else {}
        except (ValueError,OSError):all_cursors={}
        all_cursors[device_id]=last_id
        tmp=cursor_path.with_suffix('.tmp');tmp.write_text(json.dumps(all_cursors),encoding='utf-8');tmp.replace(cursor_path)
    return {'uploaded':len(payload),'processed':len(rows),'more':len(rows)==batch_size}

def init_cloud(app, db, data_dir):
    device_path = Path(data_dir) / '.cloud_device_id'
    if not device_path.exists():
        try:
            with device_path.open('x',encoding='ascii') as f: f.write(str(uuid.uuid4()))
        except FileExistsError: pass
    device_id = device_path.read_text(encoding='ascii').strip()
    @app.errorhandler(CloudError)
    def cloud_error(exc): return jsonify({'error':str(exc)}), exc.status if 400 <= exc.status < 600 else 400

    @app.get('/api/cloud/status')
    def cloud_status():
        local_id = _local_key()
        try:
            s = _active_session(local_id)
            profile = _ensure_profile(s)
            return jsonify({'connected':True, 'email':s['email'], 'role':profile.get('role','viewer'), 'display_name':profile.get('display_name') or '', 'project':'VisionOps AI Studio', 'store':'Supabase · Frankfurt', 'video_uploaded':False})
        except CloudError as e:
            return jsonify({'connected':False, 'message':str(e), 'saved_email':(DATA_DIR / ('cloud_email_'+str(local_id)+'.txt')).read_text(encoding='utf-8') if (DATA_DIR / ('cloud_email_'+str(local_id)+'.txt')).exists() else '', 'project':'VisionOps AI Studio', 'store':'Supabase · Frankfurt'})

    @app.post('/api/cloud/signup')
    def cloud_signup():
        data = request.get_json(silent=True) or {}
        email = str(data.get('email','')).strip().lower()
        password = str(data.get('password',''))
        if len(email)>254 or '@' not in email or len(password)<10 or len(password)>128:
            raise CloudError('Geçerli e-posta ve en az 10 karakterli parola gir.',400)
        result = _http('/auth/v1/signup','POST',{'email':email,'password':password})
        # On hosted projects email confirmation is commonly enabled.
        if result.get('access_token') and result.get('user'):
            s = _set_session(_local_key(), result, bool(data.get('remember')))
            _ensure_profile(s)
            return jsonify({'ok':True,'connected':True, 'message':'Bulut hesabı oluşturuldu ve bağlandı.'})
        return jsonify({'ok':True, 'connected':False, 'message':'Kayıt isteği alındı. E-postana gelen onay bağlantısını doğrulayıp bu panelden giriş yap.'})

    @app.post('/api/cloud/login')
    def cloud_login():
        data = request.get_json(silent=True) or {}
        email = str(data.get('email','')).strip().lower()
        password = str(data.get('password',''))
        if not email or not password: raise CloudError('E-posta ve parola gerekli.',400)
        token = _http('/auth/v1/token?grant_type=password','POST',{'email':email,'password':password})
        s = _set_session(_local_key(), token, bool(data.get('remember')))
        try: profile = _ensure_profile(s)
        except CloudError:
            with _LOCK: _SESSIONS.pop(_local_key(), None)
            raise
        return jsonify({'ok':True,'connected':True,'email':s['email'],'role':profile['role']})

    @app.post('/api/cloud/profile')
    def cloud_profile_change():
        """Self-service Supabase profile/password update after re-authentication."""
        user=_active_session(_local_key())
        data=request.get_json(silent=True) or {}
        old_pw=str(data.get('current_password',''))
        display_name=data.get('display_name',None)
        new_pw=str(data.get('new_password',''))
        if not old_pw:
            raise CloudError('Mevcut bulut parolanız gerekli.',400)
        if display_name is not None and (not isinstance(display_name,str) or len(display_name.strip())>80):
            raise CloudError('Görünen ad en fazla 80 karakter olmalı.',400)
        if new_pw and not 12 <= len(new_pw) <= 128:
            raise CloudError('Yeni bulut parolası en az 12 karakter olmalı.',400)
        # Reauthenticate before accepting sensitive changes. Never store the supplied password.
        proof=_http('/auth/v1/token?grant_type=password','POST',{'email':user['email'],'password':old_pw})
        jwt=proof['access_token']
        if display_name is not None:
            _http('/rest/v1/visionops_profiles?user_id=eq.'+user['cloud_id'],'PATCH',
                 {'display_name':display_name.strip()},jwt=jwt,prefer='return=minimal')
        if new_pw:
            _http('/auth/v1/user','PUT',{'password':new_pw},jwt=jwt)
        with _LOCK: _SESSIONS.pop(_local_key(),None)
        dpapi_delete(DATA_DIR / ('cloud_refresh_'+str(_local_key())+'.bin'))
        return jsonify({'ok':True,'relogin_required':True,
                        'message':'Hesap güncellendi. Güvenliğiniz için bulut oturumu kapatıldı.'})

    @app.get('/api/cloud/modules')
    def cloud_modules():
        """Read-only, server-verified plan catalogue and current user's entitlements.

        The client never sends or controls licensing state. A publishable Supabase key
        is used; PostgreSQL RLS limits entitlement rows to auth.uid().
        """
        s = _active_session(_local_key())
        catalogue = _http('/rest/v1/visionops_modules?select=code,display_name,description,availability&order=code.asc', jwt=s['token']) or []
        grants = _http('/rest/v1/visionops_entitlements?select=module_code,status,access_type,expires_at', jwt=s['token']) or []
        now = datetime.now(timezone.utc)
        active = set()
        for gnt in grants:
            if gnt.get('status') != 'active':
                continue
            expiry = gnt.get('expires_at')
            try:
                if expiry and datetime.fromisoformat(expiry.replace('Z','+00:00')) <= now:
                    continue
            except (ValueError,TypeError):
                continue
            active.add(gnt.get('module_code'))
        return jsonify({'modules':[{**m, 'unlocked':m['code'] in active and m['availability']=='available'} for m in catalogue], 'account':s['email']})

    @app.post('/api/cloud/logout')
    def cloud_logout():
        with _LOCK: s = _SESSIONS.pop(_local_key(), None)
        dpapi_delete(DATA_DIR / ('cloud_refresh_'+str(_local_key())+'.bin'))
        session.pop('active_module',None)
        session.pop('cloud_owner',None)
        session.pop('license_verified_at',None)
        if s:
            try: _http('/auth/v1/logout','POST',{},jwt=s['token'])
            except CloudError: pass
        return jsonify({'ok':True})

    @app.get('/api/cloud/events')
    def cloud_events():
        s = _active_session(_local_key())
        rows = _http('/rest/v1/visionops_events?select=id,event_type,observed_at,details,confidence&order=observed_at.desc&limit=100',jwt=s['token'])
        return jsonify({'events':rows or [],'user':s['email']})

    @app.post('/api/cloud/sync')
    def cloud_sync():
        result=_sync_batch(_local_key(),db,device_id,data_dir)
        return jsonify({'ok':True,**result,'message':f"{result['uploaded']} olay aktarıldı." + (' Kalan kayıtlar sonraki aktarımda gönderilir.' if result['more'] else ' Tüm kayıtlar güncel.')})

    @app.get('/api/cloud/auto-sync')
    def cloud_auto_status():
        return jsonify({'enabled':_cloud_auto_on(),'last_result':_auto_status['message']})

    @app.post('/api/cloud/auto-sync')
    def cloud_auto_set():
        enabled=bool((request.get_json(silent=True) or {}).get('enabled'))
        with db() as conn:
            conn.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('cloud_auto_sync',?)",('on' if enabled else 'off',))
        return jsonify({'ok':True,'enabled':enabled})

    _auto_status={'message':'Henüz çalışmadı'}
    def _cloud_auto_on():
        try:
            with db() as conn:
                row=conn.execute("SELECT value FROM settings WHERE key='cloud_auto_sync'").fetchone()
            return bool(row and row['value']=='on')
        except sqlite3.Error:return False

    def _auto_loop():
        while True:
            time.sleep(60)
            if not _cloud_auto_on():continue
            with _LOCK: active=list(_SESSIONS.keys())
            for local_id in active:
                try:
                    result=_sync_batch(local_id,db,device_id,data_dir)
                    _auto_status['message']=f"Son aktarım: {result['uploaded']} kayıt"
                except Exception as exc:
                    _auto_status['message']='Bağlantı bekleniyor: '+str(exc)[:110]
    threading.Thread(target=_auto_loop,daemon=True,name='visionops-cloud-sync').start()


init_cloud(app, lambda: db(), DATA_DIR)


state = {
    "camera": None, "running": False, "camera_ready": False, "frame": None, "lock": threading.Lock(),
    "thread": None, "source": 0, "error": None, "model_status": "Henüz yüklenmedi",
    "detector": None, "last_detections": [], "last_people": [], "tracks": {}, "next_track": 1000000,
    "object_model": None, "object_model_status": "Kapalı", "objects": [], "objects_lock": threading.Lock(), "object_busy": False,
    "object_last_scan": 0, "object_seen": {}, "interaction_seen": {}, "last_detect_at": 0,
    "zone_states": {}, "last_event": 0, "fps": 0.0, "frame_count": 0
}

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT NOT NULL, event_type TEXT NOT NULL, zone_name TEXT,
            track_id INTEGER, detail TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS zones(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
            zone_type TEXT NOT NULL, x REAL NOT NULL, y REAL NOT NULL,
            w REAL NOT NULL, h REAL NOT NULL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT)""")
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('camera_source','0')")
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('confidence','0.35')")

def log_event(event_type, zone=None, track_id=None, detail=""):
    now = datetime.now().astimezone().isoformat(timespec="seconds")
    with db() as c:
        c.execute("INSERT INTO events(ts,event_type,zone_name,track_id,detail) VALUES(?,?,?,?,?)",
                  (now, event_type, zone, track_id, detail))

def load_zones():
    with db() as c:
        return [dict(r) for r in c.execute("SELECT * FROM zones ORDER BY id").fetchall()]

def load_detector():
    try:
        from ultralytics import YOLO
        model_path = APP_DIR / "yolov8n.pt"
        state["detector"] = YOLO(str(model_path) if model_path.exists() else "yolov8n.pt")
        state["model_status"] = "YOLOv8n hazır"
        return True
    except Exception as e:
        state["model_status"] = "Model yüklenemedi: " + str(e)[:160]
        state["error"] = state["model_status"]
        return False

def detect_cats(frame):
    model = state["detector"]
    if model is None:
        return []
    try:
        # Persisted ByteTrack IDs handle occlusion and crossing paths better than centroid-only association.
        results = model.track(frame, persist=True, tracker="bytetrack.yaml", conf=float(get_setting("confidence", "0.35")),
                              classes=[0,15], verbose=False, imgsz=640)
        detections, people = [], []
        for r in results:
            if r.boxes is None: continue
            for b in r.boxes:
                x1,y1,x2,y2 = [int(v) for v in b.xyxy[0].tolist()]
                conf = float(b.conf[0]); cls = int(b.cls[0])
                tid = int(b.id[0]) if b.id is not None else None
                item={"x":x1,"y":y1,"w":x2-x1,"h":y2-y1,"cx":(x1+x2)//2,"cy":(y1+y2)//2,"conf":conf,"track_id":tid}
                (people if cls==0 else detections).append(item)
        state["last_people"] = people
        return detections
    except Exception as e:
        state["error"] = "Algılama hatası: " + str(e)[:120]
        return []

def get_setting(key, default=None):
    with db() as c:
        row = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default

def assign_tracks(detections):
    """Use ByteTrack IDs where supplied, retaining a centroid fallback if tracker IDs are unavailable."""
    tracks=state['tracks']; now=time.monotonic(); used=set()
    for d in detections:
        tid=d.get('track_id')
        if tid is None:
            best=None; cost=float('inf')
            for k,t in tracks.items():
                if k in used: continue
                dt=min(1.0,now-t['seen'])
                px=t['cx']+t.get('vx',0)*dt; py=t['cy']+t.get('vy',0)*dt
                delta=((d['cx']-px)**2+(d['cy']-py)**2)**.5
                if delta<cost: best,cost=k,delta
            tid=best if best is not None and cost<max(100,d['w']*.8) else state['next_track']
            if tid==state['next_track']: state['next_track']+=1
        d['track_id']=tid
        if tid not in tracks:
            tracks[tid]={'zones':set(),'cx':d['cx'],'cy':d['cy'],'seen':now,'vx':0,'vy':0}
            log_event('cat_detected',None,tid,'Yeni kedi izi algılandı')
        else:
            tr=tracks[tid];dt=max(.05,now-tr['seen'])
            tr['vx']=.5*tr.get('vx',0)+.5*(d['cx']-tr['cx'])/dt
            tr['vy']=.5*tr.get('vy',0)+.5*(d['cy']-tr['cy'])/dt
        tracks[tid].update(cx=d['cx'],cy=d['cy'],seen=now)
        used.add(tid)
    for tid in list(tracks):
        if now-tracks[tid]['seen']>5:
            del tracks[tid]
            log_event('cat_lost_view',None,tid,'İz kayboldu; odadan çıkış anlamına gelmez')
    return detections


def process_zones(detections, zones):
    # Compare the current set of occupied zones with the previous frame's set.
    # Enter/exit events are emitted once per transition, not once per zone loop.
    for d in detections:
        tid = d["track_id"]
        tr = state["tracks"].get(tid)
        if tr is None:
            continue
        current = set()
        fw, fh = state.get("frame_size", (640, 480))
        for z in zones:
            x, y = z["x"] * fw, z["y"] * fh
            w, h = z["w"] * fw, z["h"] * fh
            if x <= d["cx"] <= x + w and y <= d["cy"] <= y + h:
                current.add(z["id"])
        previous = set(tr.get("zones", set()))
        zone_by_id = {z["id"]: z for z in zones}
        for zid in current - previous:
            z = zone_by_id.get(zid)
            if z:
                log_event("zone_enter", z["name"], tid, z["zone_type"])
        for zid in previous - current:
            z = zone_by_id.get(zid)
            if z:
                log_event("zone_exit", z["name"], tid, z["zone_type"])
        tr["zones"] = current

def list_cameras():
    """Enumerate DirectShow friendly names without opening camera streams."""
    try:
        from pygrabber.dshow_graph import FilterGraph
        names = FilterGraph().get_input_devices()
        return [{"id": i, "name": name, "preferred": "obs" in name.lower()} for i, name in enumerate(names)]
    except Exception as exc:
        state["device_error"] = str(exc)[:180]
        return []


def open_camera(source):
    """Open ONLY the selected camera. Prefer OBS, never silently select Fujifilm's warning slate."""
    devices = list_cameras()
    if str(source).lower() in ("obs", "auto"):
        obs = [d for d in devices if "obs" in d["name"].lower()]
        if not obs:
            return None, None, None, ("OBS Virtual Camera aygiti bulunamadi. OBS icinde "
                "Sanal Kamerayi Baslat'a basin. Aygitlar: " + ", ".join(d["name"] for d in devices))
        indices = [d["id"] for d in obs]
    else:
        try: indices = [int(source)]
        except (ValueError, TypeError): return None, None, None, "Gecersiz kamera secimi"
    errors = []
    for index in indices:
        # DirectShow index corresponds to pygrabber device order.
        for backend_name, backend in (("DirectShow", cv2.CAP_DSHOW), ("MediaFoundation", cv2.CAP_MSMF)):
            cap = None
            success = False
            try:
                cap = cv2.VideoCapture(index, backend)
                if not cap.isOpened():
                    errors.append(f"{index}/{backend_name}: acilamadi")
                    continue
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
                for attempt in range(18):
                    ok, frame = cap.read()
                    if ok and frame is not None and frame.size and float(frame.mean()) > 2:
                        success = True
                        return cap, frame, index, backend_name
                    time.sleep(.10)
                errors.append(f"{index}/{backend_name}: goruntu yok")
            except Exception as exc:
                errors.append(f"{index}/{backend_name}: {str(exc)[:80]}")
            finally:
                if cap is not None:
                    if not success:
                        cap.release()
    return None, None, None, "; ".join(errors[-6:])

# ---- VisionOps v0.6: privacy and experimental movable-object detector ----
_FACE_CASCADE=None
_FACE_LOCK=threading.Lock()
OBJECT_LABELS=['cat food bowl','pet water bowl','cat litter box','doorway entrance']
OBJECT_NAMES=['Mama kabı','Su kabı','Kum kabı','Kapı girişi']

def redact_faces(frame, people):
    """Best-effort anonymization of faces and upper-body fallback; not a privacy guarantee."""
    global _FACE_CASCADE
    try:
        if _FACE_CASCADE is None:
            with _FACE_LOCK:
                if _FACE_CASCADE is None:
                    detector=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
                    _FACE_CASCADE=detector if not detector.empty() else False
        h,w=frame.shape[:2]
        if _FACE_CASCADE is not False:
            small=cv2.resize(frame,(max(1,w//2),max(1,h//2)))
            gray=cv2.cvtColor(small,cv2.COLOR_BGR2GRAY)
            for x,y,ww,hh in _FACE_CASCADE.detectMultiScale(gray,scaleFactor=1.15,minNeighbors=4,minSize=(18,18)):
                x0=max(0,2*x-12);y0=max(0,2*y-12);x1=min(w,2*(x+ww)+12);y1=min(h,2*(y+hh)+12)
                roi=frame[y0:y1,x0:x1]
                if roi.size:frame[y0:y1,x0:x1]=cv2.GaussianBlur(roi,(61,61),25)
        if _FACE_CASCADE is False and not people:
            # Face detector unavailable: avoid emitting raw frames.
            return cv2.GaussianBlur(frame,(91,91),40)
        # Extra precaution: obscure person head region even when frontal face is missed.
        for d in people:
            x=max(0,d['x']);y=max(0,d['y']);xx=min(w,d['x']+d['w']);yy=min(h,d['y']+int(d['h']*.43))
            roi=frame[y:yy,x:xx]
            if roi.size:frame[y:yy,x:xx]=cv2.GaussianBlur(roi,(71,71),31)
    except Exception as exc:
        # Conservative fallback: never publish a potentially unblurred face if processing fails.
        state['privacy_error']=str(exc)[:120] if 'state' in globals() else str(exc)[:120]
        return cv2.GaussianBlur(frame,(91,91),40)
    return frame


def _object_worker(snapshot):
    try:
        if state['object_model'] is None:
            state['object_model_status']='Model yükleniyor (ilk kullanımda internet gerekir)'
            from ultralytics import YOLOWorld
            model=YOLOWorld('yolov8s-worldv2.pt')
            model.set_classes(OBJECT_LABELS)
            state['object_model']=model
        result=state['object_model'].predict(snapshot,conf=.42,verbose=False,imgsz=640)
        found=[]
        for r in result:
            for b in (r.boxes if r.boxes is not None else []):
                label_id=int(b.cls[0]);conf=float(b.conf[0]);
                if not 0<=label_id<len(OBJECT_NAMES):continue
                x1,y1,x2,y2=map(int,b.xyxy[0].tolist())
                if x2<=x1 or y2<=y1:continue
                found.append({'label':OBJECT_NAMES[label_id], 'kind':label_id,'box':(x1,y1,x2-x1,y2-y1),'conf':conf,'seen':time.monotonic()})
        with state['objects_lock']:
            state['objects']=found
        state['object_model_status']='Deneysel nesne algılama aktif'
    except Exception as exc:
        state['object_model_status']='Nesne modeli yüklenemedi: '+str(exc)[:110]
        state['object_model']=None
        # Do not retry downloads endlessly in the camera thread.
        state['object_retry_after']=time.monotonic()+120
    finally:
        state['object_busy']=False


def maybe_scan_objects(frame):
    now=time.monotonic()
    if state['object_busy'] or now-state['object_last_scan']<3 or now<state.get('object_retry_after',0):return
    state['object_last_scan']=now
    state['object_busy']=True
    threading.Thread(target=_object_worker,args=(frame.copy(),),daemon=True).start()


def current_objects():
    if get_setting('object_detection','off')!='on':return []
    with state['objects_lock']:
        return [dict(o) for o in state['objects'] if time.monotonic()-o['seen']<8]


def mark_object_interactions(cats,people):
    if people:return
    now=time.monotonic()
    for obj in current_objects():
        x,y,w,h=obj['box']
        for d in cats:
            cx,cy=d['cx'],d['cy'];margin=max(35,int(max(w,h)*.55))
            if x-margin<=cx<=x+w+margin and y-margin<=cy<=y+h+margin:
                key=f"{d['track_id']}:{obj['kind']}"
                record=state['interaction_seen'].setdefault(key,{'first':now,'logged':0,'last':now})
                if now-record['last']>2:record['first']=now
                record['last']=now
                if now-record['first']>=2 and now-record['logged']>90:
                    log_event('cat_near_object',obj['label'],d['track_id'],'Yakınlık algılandı; gerçek kullanım doğrulanmadı')
                    record['logged']=now
    state['interaction_seen']={k:v for k,v in state['interaction_seen'].items() if now-v['last']<15}

@app.get('/api/ai/status')
def ai_status():
    return jsonify({'faces':'Best effort; guaranteed anonymization değildir',
                   'object_detection':get_setting('object_detection','off'),
                   'object_model':state['object_model_status'],
                   'objects':[{'name':o['label'],'confidence':round(o['conf'],2)} for o in current_objects()],
                   'cat_tracking':'YOLO ByteTrack'})

@app.post('/api/ai/object-detection')
def ai_toggle():
    d=request.get_json(silent=True) or {}
    enabled=bool(d.get('enabled'))
    with db() as conn:
        conn.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('object_detection',?)",('on' if enabled else 'off',))
    if not enabled:
        with state['objects_lock']:state['objects']=[]
        state['object_model_status']='Kapalı'
    return jsonify({'ok':True,'enabled':enabled,'message':'Deneysel nesne modeli '+('etkinleştirildi' if enabled else 'kapatıldı')})

def camera_loop():
    cap = None
    try:
        cap, first_frame, index, backend = open_camera(state["source"])
        if cap is None:
            state["error"] = ("Kamera goruntusu alinamadi. OBS'de Fujifilm goruntusunu ac, "
                "Sanal Kamerayi Baslat'a bas, VisionOps'ta Otomatik veya kamera indeksini sec. "
                "Ayrinti: " + str(backend))[:500]
            return
        state["active_camera"] = f"{index} / {backend}"
        state["camera_ready"] = True
        state["source"] = index
        state["error"] = None
        # Never publish an unredacted initial camera frame.
        with state["lock"]:
            state["frame"] = redact_faces(first_frame.copy(), [])
        load_detector()
        last = time.time()
        failed = 0
        while state["running"]:
            ok, frame = cap.read()
            if not ok or frame is None:
                failed += 1
                if failed >= 30:
                    state["error"] = "Kamera goruntusu kesildi. OBS Sanal Kamera'yi kontrol et."
                    break
                time.sleep(.1)
                continue
            failed = 0
            h,w=frame.shape[:2]
            state["frame_size"]=(w,h)
            state["frame_count"] += 1
            # Keep tracking on every processed frame (hardware-dependent detection cadence).
            if state["detector"] is not None:
                dets=assign_tracks(detect_cats(frame))
                state['last_detections']=dets
                state['last_detect_at']=time.monotonic()
                if not state['last_people'] and get_setting('object_detection','off')!='on':
                    # Manual zones are excluded while automatic object recognition is active.
                    process_zones(dets, load_zones())
            else:
                state['last_detections']=[];state['last_people']=[]
            now_mono=time.monotonic()
            # Privacy mask applied BEFORE any camera output is published.
            frame=redact_faces(frame,state['last_people'])
            if get_setting('object_detection','off')=='on':
                maybe_scan_objects(frame)
                mark_object_interactions(state['last_detections'],state['last_people'])
            for obj in current_objects():
                x,y,ww,hh=obj['box'];col=(220,200,60)
                cv2.rectangle(frame,(x,y),(x+ww,y+hh),col,2)
                cv2.putText(frame,f"{obj['label']} (tahmini {obj['conf']:.0%})",(x,max(20,y-8)),cv2.FONT_HERSHEY_SIMPLEX,.48,col,2)
            for d in state['last_detections']:
                x,y,ww,hh=d['x'],d['y'],d['w'],d['h']
                cv2.rectangle(frame,(x,y),(x+ww,y+hh),(80,230,150),2)
                cv2.putText(frame,f"Kedi #{d['track_id']} {d['conf']:.0%}",(x,max(20,y-8)),cv2.FONT_HERSHEY_SIMPLEX,.55,(80,230,150),2)
            state["fps"]=1/max(.001,time.time()-last); last=time.time()
            with state["lock"]:
                state["frame"]=frame.copy()
            time.sleep(.01)
    except Exception as e:
        state["error"] = "Kamera isleme hatasi: " + str(e)[:300]
    finally:
        if cap is not None: cap.release()
        state["running"] = False
        state["camera_ready"] = False

def mjpeg():
    while True:
        with state["lock"]:
            frame = None if state["frame"] is None else state["frame"].copy()
        if frame is None:
            # Placeholder frame
            img = __import__("numpy").zeros((360,640,3),dtype="uint8")
            cv2.putText(img,"VisionOps AI - Kamera bekleniyor",(30,180),cv2.FONT_HERSHEY_SIMPLEX,.8,(180,210,220),2)
        else: img=frame
        ok,buf=cv2.imencode(".jpg",img,[int(cv2.IMWRITE_JPEG_QUALITY),80])
        if ok:
            yield (b"--frame\r\nContent-Type: image/jpeg\r\n\r\n"+buf.tobytes()+b"\r\n")
        time.sleep(.08)

# v0.9: admin studio is restricted by the local account role.
BRAND_FIELDS={
 'site_hero_title','site_hero_accent','site_hero_subtitle','site_accent','site_bg',
 'pet_accent','cafe_accent','farm_accent'
}
COLOR_FIELDS={'site_accent','site_bg','pet_accent','cafe_accent','farm_accent'}

def _admin_role():
    return bool(getattr(g, 'current_user', None) and g.current_user.get('role')=='admin')

@app.get('/admin')
def admin_page():
    if not _admin_role():return redirect('/choose')
    return render_template('choose.html',admin=True,csrf=session.get('csrf',''),username=g.current_user['username'])

# Editable local visual components; never permit arbitrary HTML or scripts.
PANEL_COMPONENTS = {'heading', 'text', 'metric', 'button'}
PANEL_DEFAULTS = {'accent': '#22d3c5', 'background': '#07111f', 'heading': 'VisionOps Pet'}
PANEL_EDIT_STYLES = {'color','backgroundColor','fontSize','padding','borderRadius','textAlign'}

def _panel_settings():
    source=DATA_DIR/'panel_design.json'
    try: content=json.loads(source.read_text(encoding='utf-8'))
    except (OSError,ValueError): content={}
    settings={k:v for k,v in (content.get('settings') or {}).items() if k in PANEL_DEFAULTS and isinstance(v,str)}
    for k,v in PANEL_DEFAULTS.items(): settings.setdefault(k,v)
    widgets=[]
    for w in (content.get('widgets') or [])[:18]:
        if not isinstance(w,dict):continue
        kind=w.get('kind')
        label=w.get('label')
        if kind in PANEL_COMPONENTS and isinstance(label,str) and len(label)<=150:
            widgets.append({'kind':kind,'label':label})
    edits=[]
    for item in (content.get('edits') or [])[:180]:
        if isinstance(item,dict) and __import__('re').fullmatch(r'app_\d+_\d+',str(item.get('target',''))):
            edits.append({'target':item['target'], 'text':item.get('text'),
               'styles':{k:v for k,v in (item.get('styles') or {}).items()
                       if k in PANEL_EDIT_STYLES and isinstance(v,str) and len(v)<=40}})
    return {'settings':settings,'widgets':widgets,'edits':edits}

@app.get('/api/admin/panel-layout')
def admin_panel_layout_get():
    if not _admin_role():return jsonify({'error':'Yönetici erişimi gerekiyor.'}),403
    return jsonify(_panel_settings())

@app.post('/api/admin/panel-layout')
def admin_panel_layout_set():
    if not _admin_role():return jsonify({'error':'Yönetici erişimi gerekiyor.'}),403
    data=request.get_json(silent=True) or {}
    st=data.get('settings') or {}
    widgets=data.get('widgets') or []
    edits=data.get('edits') or []
    if not isinstance(st,dict) or not isinstance(widgets,list) or len(widgets)>18:
        return jsonify({'error':'Geçersiz düzen.'}),400
    for k,v in st.items():
        if k not in PANEL_DEFAULTS or not isinstance(v,str):return jsonify({'error':'Geçersiz alan.'}),400
        if k!='heading' and not __import__('re').fullmatch(r'#[0-9a-fA-F]{6}',v):return jsonify({'error':'Geçersiz renk.'}),400
        if k=='heading' and not 1<=len(v)<=100:return jsonify({'error':'Başlık çok uzun.'}),400
    for w in widgets:
        if not isinstance(w,dict) or w.get('kind') not in PANEL_COMPONENTS or not isinstance(w.get('label'),str) or len(w['label'])>150:
            return jsonify({'error':'Geçersiz bileşen.'}),400
    if not isinstance(edits,list) or len(edits)>180:
        return jsonify({'error':'Çok fazla öğe düzenlemesi.'}),400
    clean_edits=[]
    for e in edits:
        if not isinstance(e,dict) or not __import__('re').fullmatch(r'app_\d+_\d+',str(e.get('target',''))):
            return jsonify({'error':'Geçersiz öğe kimliği.'}),400
        text=e.get('text')
        if text is not None and (not isinstance(text,str) or len(text)>400):
            return jsonify({'error':'Metin çok uzun.'}),400
        styles=e.get('styles') or {}
        if not isinstance(styles,dict) or len(styles)>len(PANEL_EDIT_STYLES):
            return jsonify({'error':'Geçersiz öğe biçimi.'}),400
        for k,v in styles.items():
            if k not in PANEL_EDIT_STYLES or not isinstance(v,str) or len(v)>40:
                return jsonify({'error':'Geçersiz biçimlendirme.'}),400
            if k in ('color','backgroundColor') and not __import__('re').fullmatch(r'#[0-9a-fA-F]{6}',v):
                return jsonify({'error':'Renk biçimi geçersiz.'}),400
            if k in ('fontSize','padding','borderRadius') and not __import__('re').fullmatch(r'\d{1,2}px',v):
                return jsonify({'error':'Ölçü biçimi geçersiz.'}),400
            if k=='textAlign' and v not in ('left','center','right'):
                return jsonify({'error':'Hizalama geçersiz.'}),400
        clean_edits.append({'target':e['target'],'text':text,'styles':styles})
    clean={'settings':{**PANEL_DEFAULTS,**st},'widgets':[{'kind':w['kind'],'label':w['label']} for w in widgets], 'edits':clean_edits}
    path=DATA_DIR/'panel_design.json';tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(clean,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(path)
    return jsonify({'ok':True})

def _render_pet_preview(preview=False):
    content=render_template('index.html')
    if preview:content=content.replace('<script src="/static/dashboard.js"></script>','')
    data=json.dumps(_panel_settings(),ensure_ascii=False).replace('<','\\u003c')
    script="""<script>(function(){
    const data=DATA_PLACEHOLDER, settings=data.settings;
    const style=document.createElement('style');
    style.textContent=':root{--visionops-custom-accent:'+settings.accent+'} .visionops-custom-title{color:'+settings.accent+'}';
    document.head.appendChild(style);
    const target=document.querySelector('.main-content')||document.querySelector('main')||document.body;
    const holder=document.createElement('section');holder.className='visionops-custom-widgets';
    holder.style.cssText='display:flex;flex-wrap:wrap;gap:12px;margin:15px 0 22px;';
    for(const w of data.widgets){const box=document.createElement('div');box.style.cssText='padding:16px;border-radius:12px;border:1px solid #28616a;background:'+settings.background+';color:#effaf9;min-width:160px;flex:1';
    const el=document.createElement(w.kind==='heading'?'h2':w.kind==='button'?'strong':'p');el.textContent=w.label;el.style.margin='0';box.append(el);holder.append(box);}
    if(holder.childNodes.length)target.prepend(holder);
    const h=document.querySelector('h1');if(h)h.textContent=settings.heading;
    })();</script>""".replace('DATA_PLACEHOLDER',data)
    overlay_script = """<script>(function(){
      const selectors=[
       '.nav button','.page .eyebrow','.page h1','.page .page-title p',
       '.page .panel','.page .panel h2','.page .panel p',
       '.page .kpi','.page .kpi-label','.page .kpi-value',
       '.page .info-strip','.page .btn','.side-bottom .scenario',
       '.side-bottom .userbox','.page .badge',
       '.visionops-custom-widgets article','.visionops-custom-widgets p',
       '.visionops-custom-widgets h2'
      ];
      const targets=new Map();
      selectors.forEach((s,i)=>document.querySelectorAll(s).forEach((node,j)=>{
        const key='app_'+i+'_'+j;node.dataset.voTarget=key;targets.set(key,node);
      }));
      window.__visionopsPanelTargets=targets;
      for(const edit of SETTINGS.edits||[]){
        const node=targets.get(edit.target);if(!node)continue;
        if(typeof edit.text==='string'&&node.children.length===0)node.textContent=edit.text;
        for(const [prop,val] of Object.entries(edit.styles||{})){
          if(['color','backgroundColor','fontSize','padding','borderRadius','textAlign'].includes(prop))node.style[prop]=val;
        }
      }
      if(location.pathname==='/admin/preview'){
         document.querySelectorAll('.nav button[data-page]').forEach(button=>button.addEventListener('click',()=>{
           const page=button.dataset.page;
           document.querySelectorAll('.page').forEach(node=>node.classList.toggle('active',node.id==='page-'+page));
         }));
      }
    })();</script>""".replace('SETTINGS',data)
    if preview: script=script.replace('if(holder.childNodes.length)target.prepend(holder);','target.prepend(holder);')
    return content.replace('</body>',script+overlay_script+'</body>')

@app.get('/admin/preview')
def admin_preview():
    if not _admin_role():return 'Yönetici erişimi gerekiyor',403
    # Preview-only: strip scripts and never initialize camera or stream.
    from markupsafe import Markup
    return _render_pet_preview(preview=True)

@app.get('/api/admin/brand')
def admin_brand_read():
    if not _admin_role():return jsonify({'error':'Yönetici erişimi gerekiyor.'}),403
    try:
        data=_http('/rest/v1/visionops_brand_settings?select=setting_key,setting_value') or []
        return jsonify({'settings':{i['setting_key']:i['setting_value'] for i in data}})
    except CloudError as exc:return jsonify({'error':str(exc)}),exc.status

@app.post('/api/admin/brand')
def admin_brand_write():
    if not _admin_role():return jsonify({'error':'Yönetici erişimi gerekiyor.'}),403
    obj=request.get_json(silent=True) or {}
    values=obj.get('settings')
    if not isinstance(values,dict) or not values or len(values)>len(BRAND_FIELDS):
        return jsonify({'error':'Geçersiz ayar listesi.'}),400
    for key,value in values.items():
        if key not in BRAND_FIELDS or not isinstance(value,str) or not 1<=len(value)<=280:
            return jsonify({'error':'Geçersiz anahtar veya değer.'}),400
        if key in COLOR_FIELDS and not __import__('re').fullmatch(r'#[0-9a-fA-F]{6}',value):
            return jsonify({'error':'Renkler #RRGGBB biçiminde olmalı.'}),400
    try:
        cloud=_active_session(_local_key())
        role=_ensure_profile(cloud).get('role')
        if role!='admin':return jsonify({'error':'Supabase bulut hesabının yönetici yetkisi yok.'}),403
        for key,value in values.items():
            _http('/rest/v1/visionops_brand_settings?setting_key=eq.'+key,'PATCH',
                  {'setting_value':value},jwt=cloud['token'],prefer='return=minimal')
        return jsonify({'ok':True})
    except CloudError as exc:return jsonify({'error':str(exc)}),exc.status

# v0.8: start at workspace choice; never make the dashboard a public module selector.
@app.get('/choose')
def choose_workspace():
    return render_template('choose.html', logged_in=bool(session.get('user_id')),
                           csrf=session.get('csrf',''))

@app.get('/workspace/leave')
def leave_workspace():
    session.pop('active_module',None)
    session.pop('cloud_owner',None)
    session.pop('license_verified_at',None)
    return redirect('/choose')

@app.get('/activate/<module>')
def activate_workspace(module):
    if module not in ('pet','cafe','farm'):
        return redirect('/choose')
    return render_template('activate.html', module=module,
                           csrf=session.get('csrf',''))

@app.post('/api/workspace/select')
def select_workspace():
    payload=request.get_json(silent=True) or {}
    module=str(payload.get('module',''))
    if module not in ('pet','cafe','farm'):
        return jsonify({'error':'Bilinmeyen modül'}),400
    try:
        # Development-only local Pet workspace; cloud is connected later inside the panel.
        # Must be removed in production when paid entitlement enforcement is enabled.
        if module=='pet' and _admin_role():
            session['active_module']='pet'
            session['cloud_owner']='local-development'
            session['license_verified_at']=time.time()
            return jsonify({'ok':True,'url':'/'})
        # For non-admin users, Supabase RLS verifies actual grants.
        s=_active_session(_local_key())
        catalogue=_http('/rest/v1/visionops_modules?select=code,availability&code=eq.'+module,jwt=s['token']) or []
        grants=_http('/rest/v1/visionops_entitlements?select=module_code,status,expires_at&module_code=eq.'+module,jwt=s['token']) or []
        now=datetime.now(timezone.utc)
        allowed=bool(catalogue and catalogue[0].get('availability')=='available' and any(
            gnt.get('status')=='active' and (not gnt.get('expires_at') or datetime.fromisoformat(gnt['expires_at'].replace('Z','+00:00'))>now)
            for gnt in grants))
        if not allowed:return jsonify({'error':'Bu modül için etkin erişim hakkınız yok.'}),403
        session['active_module']=module
        session['cloud_owner']=s['cloud_id']
        return jsonify({'ok':True,'url':'/'})
    except CloudError as exc:
        return jsonify({'error':str(exc)}),exc.status

@app.before_request
def enforce_workspace():
    # Registered after local auth gate. Block access to camera and reports until
    # a Supabase entitlement has been checked for this cloud identity.
    p=request.path
    if p in ('/', '/video') or (p.startswith('/api/') and not
       (p.startswith('/api/auth/') or p.startswith('/api/cloud/') or
        p.startswith('/api/updates/') or p.startswith('/api/admin/') or p=='/api/workspace/select')):
        if session.get('active_module')!='pet' or not session.get('cloud_owner'):
            if p.startswith('/api/') or p=='/video':
                return jsonify({'error':'Çalışma alanına giriş yapılmalı.'}),403
            return redirect('/choose')
        if session.get('cloud_owner')=='local-development' and session.get('role')=='admin':
            return None
        try:
            cloud=_active_session(_local_key())
            if cloud['cloud_id']!=session['cloud_owner']:
                session.pop('active_module',None)
                session.pop('cloud_owner',None)
                raise CloudError('Bulut oturumu değişti, tekrar giriş yap.',403)
        except CloudError:
            if p.startswith('/api/') or p=='/video':
                return jsonify({'error':'Bulut oturumu yok; çalışma alanını seçin.'}),403
            return redirect('/activate/pet')
        # Re-validate license periodically, not with each video frame.
        proof=session.get('license_verified_at',0)
        if time.time()-proof>60:
            try:
                grant=_http('/rest/v1/visionops_entitlements?select=status,expires_at&module_code=eq.pet',jwt=cloud['token']) or []
                ok=any(x.get('status')=='active' and (not x.get('expires_at') or datetime.fromisoformat(x['expires_at'].replace('Z','+00:00'))>datetime.now(timezone.utc)) for x in grant)
                if not ok:
                    session.pop('active_module',None)
                    if p.startswith('/api/') or p=='/video': return jsonify({'error':'Pet erişimi bulunamadı.'}),403
                    return redirect('/choose')
                session['license_verified_at']=time.time()
            except CloudError:
                if p.startswith('/api/') or p=='/video': return jsonify({'error':'Lisans doğrulanamadı; interneti kontrol edin.'}),503
                return redirect('/activate/pet')
    return None

@app.route("/")
def index(): return _render_pet_preview()

@app.route("/video")
def video(): return Response(mjpeg(),mimetype="multipart/x-mixed-replace; boundary=frame")

@app.route("/api/cameras")
def cameras():
    devices = list_cameras()
    return jsonify({"devices": devices, "error": state.get("device_error"), "obs_found": any(d["preferred"] for d in devices)})

@app.route("/api/status")
def status():
    with db() as c:
        total=c.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        today=datetime.now().astimezone().date().isoformat()
        today_events=c.execute("SELECT COUNT(*) FROM events WHERE ts LIKE ?",(today+"%",)).fetchone()[0]
        cats=c.execute("SELECT COUNT(*) FROM events WHERE event_type='cat_detected' AND ts LIKE ?",(today+"%",)).fetchone()[0]
    return jsonify({"running":state["running"],"streaming":state["camera_ready"],"error":state["error"],"model":state["model_status"],
        "fps":round(state["fps"],1),"active_camera":state.get("active_camera"),"events":total,"today_events":today_events,"cat_detections_today":cats,
        "zones":len(load_zones()),"source":state["source"],"object_status":state["object_model_status"],"people":len(state['last_people']),"cat_active":len(state['last_detections'])})

@app.route("/api/start",methods=["POST"])
def start_camera():
    if state["running"]: return jsonify({"ok":True,"message":"Kamera zaten çalışıyor."})
    if state.get("thread") and state["thread"].is_alive():
        return jsonify({"ok":False,"error":"Önceki kamera kapatılıyor; birkaç saniye sonra tekrar deneyin."}),409
    data=request.get_json(silent=True) or {}
    source=data.get("source",get_setting("camera_source","0"))
    try:
        source = str(source).lower() if str(source).lower() in ("auto", "obs") else int(source)
        if isinstance(source, int) and not 0 <= source <= 30: raise ValueError()
    except (ValueError, TypeError): return jsonify({"ok":False,"error":"Geçersiz kamera kaynağı."}),400
    state["source"]=source; state["error"]=None; state["running"]=True; state["camera_ready"]=False
    with state["lock"]: state["frame"] = None
    state["thread"]=threading.Thread(target=camera_loop,daemon=True); state["thread"].start()
    return jsonify({"ok":True,"message":"Kamera başlatılıyor."})

@app.route("/api/stop",methods=["POST"])
def stop_camera():
    state["running"]=False
    state["camera_ready"]=False
    thread = state.get("thread")
    if thread and thread.is_alive(): thread.join(timeout=2)
    return jsonify({"ok":True})

@app.route("/api/zones")
def zones(): return jsonify(load_zones())

@app.route("/api/zones",methods=["POST"])
def save_zone():
    d=request.get_json()
    name=str(d.get("name","Yeni alan")).strip()[:50]
    ztype=str(d.get("zone_type","custom"))
    allowed={"entry","food","water","litter","custom"}
    if ztype not in allowed: ztype="custom"
    x=max(0,min(1,float(d.get("x",0)))); y=max(0,min(1,float(d.get("y",0))))
    w=max(.01,min(1-x,float(d.get("w",.2)))); h=max(.01,min(1-y,float(d.get("h",.2))))
    with db() as c:
        cur=c.execute("INSERT INTO zones(name,zone_type,x,y,w,h) VALUES(?,?,?,?,?,?)",(name,ztype,x,y,w,h))
        zid=cur.lastrowid
    return jsonify({"ok":True,"id":zid})

@app.route("/api/zones/<int:zid>",methods=["DELETE"])
def delete_zone(zid):
    with db() as c: c.execute("DELETE FROM zones WHERE id=?",(zid,))
    return jsonify({"ok":True})

@app.route("/api/events")
def events():
    limit=min(200,max(1,int(request.args.get("limit",100))))
    with db() as c:
        rows=[dict(r) for r in c.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?",(limit,)).fetchall()]
    return jsonify(rows)

@app.route("/api/summary")
def summary():
    today=datetime.now().astimezone().date().isoformat()
    with db() as c:
        rows=c.execute("SELECT event_type,zone_name,COUNT(*) n FROM events WHERE ts LIKE ? GROUP BY event_type,zone_name",(today+"%",)).fetchall()
    counts={"cat_detected":0,"cat_lost_view":0,"zone_enter":0,"zone_exit":0}
    zone_counts={}
    for r in rows:
        counts[r["event_type"]]=counts.get(r["event_type"],0)+r["n"]
        if r["event_type"]=="zone_enter" and r["zone_name"]:
            zone_counts[r["zone_name"]]=zone_counts.get(r["zone_name"],0)+r["n"]
    return jsonify({"counts":counts,"zones":zone_counts})

@app.route("/api/reports/ten-minute")
def ten_minute_report():
    """Aggregated event observations in ten-minute time buckets, local time."""
    today = datetime.now().astimezone().date().isoformat()
    with db() as c:
        rows = c.execute("SELECT ts,event_type,zone_name FROM events WHERE ts LIKE ? ORDER BY ts", (today+"%",)).fetchall()
    buckets = {}
    for r in rows:
        try:
            stamp = datetime.fromisoformat(r["ts"])
            minute = (stamp.minute // 10) * 10
            key = stamp.strftime("%H:") + f"{minute:02d}"
        except (ValueError, TypeError):
            continue
        bucket = buckets.setdefault(key, {"time":key,"detections":0,"visits":0,"lost":0})
        if r["event_type"] == "cat_detected": bucket["detections"] += 1
        elif r["event_type"] == "zone_enter": bucket["visits"] += 1
        elif r["event_type"] == "cat_lost_view": bucket["lost"] += 1
    return jsonify({"date":today,"interval_minutes":10,"buckets":list(buckets.values()),
        "note":"Bu sayılar gözlem olaylarıdır; yemek/su tüketimi veya gerçek oda çıkışı kanıtı değildir."})

@app.route("/api/events/clear",methods=["POST"])
def clear_events():
    with db() as c: c.execute("DELETE FROM events")
    state["tracks"]={}; state["next_track"]=1
    return jsonify({"ok":True})

@app.route("/api/info")
def info():
    from flask import session
    version = json.loads((APP_DIR / "version.json").read_text(encoding="utf-8"))["version"]
    return jsonify({"version": version, "user": session.get("username"), "role": session.get("role"), "local": True})

if __name__ == "__main__":
    init_db()
    print("VisionOps AI yerel sunucu: http://127.0.0.1:5000", flush=True)
    app.run(host="127.0.0.1",port=5000,debug=False,threaded=True)
