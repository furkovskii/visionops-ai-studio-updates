'use strict';
const csrf=document.querySelector('meta[name="csrf-token"]').content;
const pageTitles={home:'Kontrol Merkezi',camera:'Canlı İzleme',multicam:'Çoklu Kamera',alerts:'Akıllı Uyarılar',health:'Sistem Sağlığı',events:'Olay Kayıtları',reports:'Raporlar & Analizler',zones:'Analiz Alanları',devices:'Kamera & Cihazlar',users:'Kullanıcılar',account:'Hesabım',cloud:'Bulut & Senkronizasyon',settings:'Ayarlar & Güncellemeler'};
let admin=false,reportRows=[],updateAvailable=false,lastRelease=null,hasVideo=false;
const el=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const htime=s=>{try{return new Date(s).toLocaleTimeString('tr-TR',{hour:'2-digit',minute:'2-digit'});}catch{return s||'—'}};
async function api(url,opts={}){
 const headers={...(opts.headers||{})};if(opts.method&&opts.method!=='GET')headers['X-CSRF-Token']=csrf;
 if(opts.body&&typeof opts.body==='string')headers['Content-Type']='application/json';
 const response=await fetch(url,{credentials:'same-origin',...opts,headers});
 if(response.status===401&&!url.startsWith('/api/cloud/')){location.href='/login';throw Error('Oturum süresi doldu.');}
 const d=await response.json().catch(()=>({error:'Yanıt okunamadı.'}));if(!response.ok)throw Error(d.error||`HTTP ${response.status}`);return d;
}
let tt;
function toast(msg,error=false){const box=el('toast');box.textContent=msg;box.className=error?'error':'';box.style.display='block';clearTimeout(tt);tt=setTimeout(()=>box.style.display='none',4800)}
function go(page){if(page==='users'&&!admin)return;document.querySelectorAll('.page').forEach(e=>e.classList.toggle('active',e.id==='page-'+page));document.querySelectorAll('#navigation button').forEach(e=>e.classList.toggle('active',e.dataset.page===page));el('breadcrumb').textContent=pageTitles[page];
 if(page==='camera'||page==='devices')loadCameras();if(page==='events')loadEvents();if(page==='zones'){loadZones();setTimeout(resizeZone,100);}if(page==='reports')loadReports();if(page==='users')loadUsers();if(page==='account')loadAccount();if(page==='settings')loadUpdateConfig();if(page==='cloud'){cloudStatus();cloudAutoStatus();}if(page==='devices'||page==='camera')updateAi();
 if(page==='home')refreshAll();window.scrollTo(0,0);
}
document.querySelectorAll('#navigation button').forEach(b=>b.onclick=()=>go(b.dataset.page));document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>go(b.dataset.go));
function startFeed(){for(const img of document.querySelectorAll('.camera-feed,#zoneImage')){if(!img.src){img.src=img.dataset.src;}}hasVideo=true;}
function updateClock(){el('clock').textContent=new Date().toLocaleString('tr-TR',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});}setInterval(updateClock,30000);updateClock();
function statusLabel(s){el('kpiCats').textContent=s.cat_detections_today??'—';el('kpiEvents').textContent=s.today_events??'—';el('kpiCamera').textContent=s.streaming?'Canlı':s.running?'Bağlanıyor':'Kapalı';el('kpiFps').textContent=s.streaming?`${s.fps||0} FPS`:'Görüntü kaynağı bekleniyor';el('kpiModel').textContent=(s.model||'Başlatılmadı').slice(0,65);el('videoStatus').textContent=s.streaming?'CANLI':s.running?'BAĞLANIYOR':'BAĞLI DEĞİL';el('videoStatus').className='badge'+(s.streaming?'':' off');el('cameraBadge').textContent=s.streaming?'CANLI':s.running?'BAĞLANIYOR':'KAPALI';el('cameraBadge').className='badge'+(s.streaming?'':' off');el('activeDevice').textContent=s.active_camera||'OBS sanal kamera bekleniyor';if(s.streaming&&!hasVideo)startFeed();if(s.error)el('camMessage').textContent=s.error;}
async function refreshAll(){try{const [s,summary,events]=await Promise.all([api('/api/status'),api('/api/summary'),api('/api/events?limit=5')]);statusLabel(s);el('dStarts').textContent=summary.counts.cat_detected||0;el('dVisits').textContent=summary.counts.zone_enter||0;el('dLost').textContent=summary.counts.cat_lost_view||0;
 el('recentEvents').innerHTML=events.length?events.map(ev=>`<div class="recent-event"><div><div class="event-type">${esc(eventType(ev.event_type))}</div><div class="event-detail">${esc(ev.zone_name||ev.detail||'Kamera analizi')}</div></div><div class="event-time">${htime(ev.ts)}</div></div>`).join(''):'<div class="empty">Henüz olay kaydedilmedi.</div>';
 }catch(e){if(e.message!=='Oturum süresi doldu.')console.warn(e)}}
function eventType(t){return({cat_detected:'Kedi algılandı',cat_lost_view:'Kedi görüşten çıktı',zone_enter:'Analiz alanına giriş',zone_exit:'Analiz alanından çıkış'})[t]||t}
async function startCam(){try{const d=await api('/api/start',{method:'POST',body:JSON.stringify({source:el('source').value})});toast(d.message||'Kamera başlatılıyor');el('camMessage').textContent=d.message||'';startFeed();setTimeout(refreshAll,1100);}catch(e){toast(e.message,true)}}
async function stopCam(){try{await api('/api/stop',{method:'POST'});toast('Kamera durduruldu');setTimeout(refreshAll,600);}catch(e){toast(e.message,true)}}
['homeStart','camStart'].forEach(id=>el(id).onclick=startCam);['homeStop','camStop'].forEach(id=>el(id).onclick=stopCam);
async function loadCameras(){try{const d=await api('/api/cameras'),s=el('source'),prev=s.value;s.innerHTML='<option value="obs">OBS Virtual Camera (Önerilen)</option>';d.devices.forEach(dev=>{const o=document.createElement('option');o.value=String(dev.id);o.textContent=dev.id+' · '+dev.name;s.appendChild(o)});if([...s.options].some(o=>o.value===prev))s.value=prev;
 el('obsHealth').textContent=d.obs_found?'● Bulundu':'◌ Bulunamadı';el('obsHealth').className=d.obs_found?'ok':'pending';
 el('deviceList').innerHTML=d.devices.length?d.devices.map(dev=>`<div class="device-item"><div><strong>${esc(dev.name)}</strong><small>Windows kamera aygıtı · #${dev.id}${dev.preferred?' · OBS sanal kamera':''}</small></div><span class="badge ${dev.preferred?'':'subtle'}">${dev.preferred?'ÖNERİLEN':'BAĞLANABİLİR'}</span></div>`).join(''):'<div class="empty">Aygıt listesi boş. OBS sanal kameranın açık olduğundan emin olun.</div>';
 }catch(e){el('deviceList').textContent=e.message;}}
el('scanDevices').onclick=loadCameras;el('deviceRefresh').onclick=loadCameras;
async function loadEvents(){try{const rows=await api('/api/events?limit=200');el('eventRows').innerHTML=rows.length?rows.map(e=>`<tr><td>${esc(e.ts.replace('T',' ').slice(0,19))}</td><td>${esc(eventType(e.event_type))}</td><td>${esc(e.zone_name||'—')}</td><td>${e.track_id??'—'}</td><td>${esc(e.detail||'')}</td></tr>`).join(''):'<tr><td colspan="5" class="empty">Henüz olay bulunmuyor.</td></tr>';}catch(e){toast(e.message,true)}}
el('csvExport').onclick=async()=>{try{const rows=await api('/api/events?limit=200');const cells=[['Zaman','Olay','Alan','Takip No','Açıklama'],...rows.map(e=>[e.ts,e.event_type,e.zone_name||'',e.track_id??'',e.detail||''])];const csv='\uFEFF'+cells.map(r=>r.map(v=>'"'+String(v).replaceAll('"','""')+'"').join(';')).join('\n');const u=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=u;a.download='visionops-olaylar.csv';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);}catch(e){toast(e.message,true)}};
el('clearEvents').onclick=async()=>{if(!confirm('Tüm olay geçmişi silinsin mi?'))return;try{await api('/api/events/clear',{method:'POST'});await loadEvents();await refreshAll();toast('Olay geçmişi temizlendi');}catch(e){toast(e.message,true)}};
function drawChart(canvas,rows,showAxes){const rect=canvas.getBoundingClientRect();if(!rect.width||!rect.height)return;const w=rect.width,h=rect.height,dpr=window.devicePixelRatio||1;canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);const ctx=canvas.getContext('2d');ctx.scale(dpr,dpr);ctx.clearRect(0,0,w,h);
 const data=rows.slice(showAxes?-28:-7),margin=showAxes?{l:35,r:14,t:18,b:36}:{l:7,r:6,t:7,b:11},plotW=w-margin.l-margin.r,plotH=h-margin.t-margin.b;
 ctx.lineWidth=1;ctx.strokeStyle='#2c425555';ctx.font='10px Segoe UI';ctx.fillStyle='#7997a9';ctx.textAlign='left';for(let i=0;i<=4;i++){const y=margin.t+plotH*i/4;ctx.beginPath();ctx.moveTo(margin.l,y);ctx.lineTo(w-margin.r,y);ctx.stroke()}
 if(!data.length){ctx.textAlign='center';ctx.fillStyle='#8198a9';ctx.font='12px Segoe UI';ctx.fillText('Henüz raporlanacak olay yok',w/2,h/2);return;}
 const chartColor=document.body.dataset.voCustom==='on'?getComputedStyle(document.body).getPropertyValue('--vo-chart').trim():'#22d3c5';const keys=[['detections',chartColor||'#22d3c5'],['visits','#56aaff'],['lost','#af87ff']],max=Math.max(1,...data.flatMap(d=>keys.map(([k])=>d[k]||0)));const groupW=plotW/data.length;
 data.forEach((item,index)=>{const step=Math.min(groupW*.19,17),x=margin.l+index*groupW+groupW*.15;for(let j=0;j<3;j++){const num=item[keys[j][0]]||0,bh=num/max*(plotH-3);ctx.fillStyle=keys[j][1];ctx.fillRect(x+j*(step+2),margin.t+plotH-bh,step,bh)}if(showAxes&&(index%Math.max(1,Math.ceil(data.length/8))===0)){ctx.fillStyle='#8ba5b5';ctx.textAlign='center';ctx.fillText(item.time,x+groupW*.29,h-12)}});
 if(showAxes){ctx.fillStyle='#89a5b7';ctx.textAlign='right';for(let i=0;i<=4;i++)ctx.fillText(String(Math.round(max*(4-i)/4)),margin.l-8,margin.t+plotH*i/4+3)}
}
async function loadReports(){try{const d=await api('/api/reports/ten-minute');reportRows=d.buckets||[];const visits=el('petAreaVisits');visits.replaceChildren();for(const row of reportRows){for(const [name,count] of Object.entries(row.areas||{})){const li=document.createElement('li');li.textContent=row.time+' · '+name+' · '+count+' ziyaret';visits.append(li)}}if(!visits.childElementCount){const li=document.createElement('li');li.textContent='Bugün kaydedilen bölge ziyareti yok.';visits.append(li)}el('reportLabel').textContent=`${d.date} · ${reportRows.length} dolu zaman dilimi`;drawChart(el('reportChart'),reportRows,true);drawChart(el('miniChart'),reportRows,false)}catch(e){toast(e.message,true)}}
el('refreshReports').onclick=loadReports;window.addEventListener('resize',()=>{drawChart(el('reportChart'),reportRows,true);drawChart(el('miniChart'),reportRows,false);resizeZone()});
let selectedRect=null,drag=null;
const zoneCanvas=el('draw');
function resizeZone(){const r=zoneCanvas.getBoundingClientRect();if(!r.width||!r.height)return;zoneCanvas.width=Math.floor(r.width*devicePixelRatio);zoneCanvas.height=Math.floor(r.height*devicePixelRatio);const ctx=zoneCanvas.getContext('2d');ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0);drawZone();}
function pos(evt){const r=zoneCanvas.getBoundingClientRect();return{x:Math.max(0,Math.min(1,(evt.clientX-r.left)/r.width)),y:Math.max(0,Math.min(1,(evt.clientY-r.top)/r.height))}}
function drawZone(){const c=zoneCanvas.getContext('2d'),w=zoneCanvas.clientWidth,h=zoneCanvas.clientHeight;c.clearRect(0,0,w,h);if(!selectedRect)return;c.fillStyle='#22d3c53a';c.strokeStyle='#22d3c5';c.lineWidth=2;c.fillRect(selectedRect.x*w,selectedRect.y*h,selectedRect.w*w,selectedRect.h*h);c.strokeRect(selectedRect.x*w,selectedRect.y*h,selectedRect.w*w,selectedRect.h*h)}
zoneCanvas.addEventListener('pointerdown',e=>{drag=pos(e);zoneCanvas.setPointerCapture(e.pointerId)});zoneCanvas.addEventListener('pointermove',e=>{if(!drag)return;const p=pos(e);selectedRect={x:Math.min(drag.x,p.x),y:Math.min(drag.y,p.y),w:Math.abs(drag.x-p.x),h:Math.abs(drag.y-p.y)};drawZone()});zoneCanvas.addEventListener('pointerup',()=>drag=null);
async function loadZones(){try{const z=await api('/api/zones');el('zoneList').innerHTML=z.length?z.map(x=>`<div class="zone-item"><div><strong>${esc(x.name)}</strong><small>${esc(x.zone_type)} · ${Math.round(x.w*100)}% × ${Math.round(x.h*100)}%</small></div><button class="btn" onclick="deleteZone(${Number(x.id)})">Sil</button></div>`).join(''):'<div class="empty">Henüz alan tanımlanmadı.</div>';}catch(e){toast(e.message,true)}}
async function deleteZone(id){if(!confirm('Bu alan silinsin mi?'))return;try{await api('/api/zones/'+id,{method:'DELETE'});loadZones();toast('Alan silindi')}catch(e){toast(e.message,true)}}
el('saveZone').onclick=async()=>{if(!selectedRect||selectedRect.w<.01||selectedRect.h<.01){toast('Önce kamera görüntüsü üzerinde alan çiz.',true);return;}try{await api('/api/zones',{method:'POST',body:JSON.stringify({...selectedRect,name:el('zoneName').value||'Yeni alan',zone_type:el('zoneType').value})});selectedRect=null;drawZone();el('zoneName').value='';await loadZones();toast('Alan kaydedildi');}catch(e){toast(e.message,true)}};
async function loadUsers(){if(!admin)return;try{const users=await api('/api/users');el('userList').innerHTML=users.map(u=>`<div class="user-item"><div><strong>${esc(u.username)}</strong><small>${u.role==='admin'?'Yönetici':'Görüntüleyici'} · ${esc(u.created_at)}</small></div><div class="actions" style="margin-top:0"><button class="btn" onclick="resetUser(${u.id})">Parola değiştir</button>${u.username===el('username').textContent?'':`<button class="btn danger" onclick="deleteUser(${u.id})">Sil</button>`}</div></div>`).join('');}catch(e){toast(e.message,true)}}
async function resetUser(uid){const pw=prompt('Yeni parolayı girin (en az 10 karakter):');if(pw===null)return;try{await api('/api/users/'+uid+'/password',{method:'POST',body:JSON.stringify({password:pw})});toast('Parola değiştirildi')}catch(e){toast(e.message,true)}}
async function deleteUser(uid){if(!confirm('Kullanıcı hesabı silinsin mi?'))return;try{await api('/api/users/'+uid,{method:'DELETE'});await loadUsers();toast('Kullanıcı silindi')}catch(e){toast(e.message,true)}}
el('userForm').addEventListener('submit',async e=>{e.preventDefault();try{await api('/api/users',{method:'POST',body:JSON.stringify({username:el('newUser').value,password:el('newPassword').value,role:el('newRole').value})});e.target.reset();await loadUsers();toast('Yeni kullanıcı oluşturuldu.')}catch(ex){toast(ex.message,true)}});
async function loadAccount(){
 try{const d=await api('/api/account/me');el('accountUsername').value=d.username;}
 catch(ex){toast(ex.message,true)}
}
el('username').style.cursor='pointer';
el('username').onclick=()=>go('account');
el('accountForm').addEventListener('submit',async e=>{
 e.preventDefault();const username=el('accountUsername').value.trim();
 const current=el('accountCurrentPassword').value;
 const next=el('accountNewPassword').value,confirmation=el('accountConfirmPassword').value;
 if(next!==confirmation){toast('Yeni parolalar eşleşmiyor.',true);return}
 const submit=e.target.querySelector('[type=submit]');submit.disabled=true;
 try{
  const previous=el('username').textContent;
  const d=await api('/api/account/change',{method:'POST',body:JSON.stringify({username,current_password:current,new_password:next})});
  try{if(localStorage.getItem('visionops_username')===previous)localStorage.setItem('visionops_username',username)}catch(_ignored){}
  e.target.reset();toast('Bilgiler kaydedildi. Güvenliğiniz için yeniden giriş yapmanız gerekiyor.');
  location.replace('/choose');
 }catch(ex){toast(ex.message,true)}finally{submit.disabled=false}
});

async function loadUpdateConfig(){try{const d=await api('/api/updates/config');el('repoOwner').value=d.owner;el('repoName').value=d.repo;el('currentVersion').textContent='v'+d.version;el('versionBadge').textContent='v'+d.version;if(d.pending){el('updateState').textContent='Güncelleme hazır';el('updateDetail').textContent='Uygulamayı kapatıp masaüstü simgesiyle tekrar açın.';}else if(d.owner&&d.repo){el('updateState').textContent='GitHub depo adresi kaydedildi';el('updateDetail').textContent=d.owner+'/'+d.repo;}else{el('updateState').textContent='Henüz güncelleme deposu bağlı değil';}}catch(e){toast(e.message,true)}}
el('repoForm').addEventListener('submit',async e=>{e.preventDefault();try{await api('/api/updates/config',{method:'POST',body:JSON.stringify({owner:el('repoOwner').value,repo:el('repoName').value})});toast('Depo bilgisi kaydedildi.');await loadUpdateConfig();}catch(ex){toast(ex.message,true)}});
el('checkUpdate').onclick=async()=>{el('checkUpdate').disabled=true;try{const d=await api('/api/updates/check',{method:'POST',body:'{}'});lastRelease=d;updateAvailable=d.available&&d.asset;el('updateState').textContent=d.available?`Yeni sürüm: v${d.latest}`:`Güncel sürüm: v${d.current}`;el('updateDetail').textContent=d.available?(d.asset?'Güncelleme paketi mevcut.':'Sürüm var ancak güncelleme ZIP dosyası yok.'):'Yeni sürüm bulunamadı.';el('downloadUpdate').disabled=!updateAvailable;el('updateNotes').textContent=(d.notes||'GitHub Releases sürümü kontrol edildi.').slice(0,600);toast(d.available?'Güncelleme bulundu.':'Yeni güncelleme yok.');}catch(e){toast(e.message,true)}finally{el('checkUpdate').disabled=false}};
el('downloadUpdate').onclick=async()=>{if(!updateAvailable)return;el('downloadUpdate').disabled=true;toast('Güncelleme indiriliyor ve doğrulanıyor...');try{const d=await api('/api/updates/download',{method:'POST',body:'{}'});toast(d.message||'Güncelleme hazır');await loadUpdateConfig();}catch(e){toast(e.message,true)}finally{el('downloadUpdate').disabled=false}};
el('localUpdate').onclick=async()=>{const file=el('updateFile').files[0];if(!file){toast('Önce ZIP dosyası seç.',true);return;}const form=new FormData();form.append('file',file);try{const d=await api('/api/updates/upload',{method:'POST',body:form});toast(d.message||'Güncelleme hazır');await loadUpdateConfig();}catch(e){toast(e.message,true)}};
el('exportEncryptedBackup').onclick=async()=>{
 const password=el('backupPassphrase').value;
 if(password.length<12){toast('En az 12 karakterli yedek parolası gir.',true);return;}
 const btn=el('exportEncryptedBackup');btn.disabled=true;
 try{
  const response=await fetch('/api/security/backup/export',{method:'POST',credentials:'same-origin',
   headers:{'X-CSRF-Token':csrf,'Content-Type':'application/json'},body:JSON.stringify({passphrase:password})});
  if(!response.ok){const err=await response.json().catch(()=>({}));throw Error(err.error||'Şifreli yedek oluşturulamadı');}
  const blob=await response.blob();const url=URL.createObjectURL(blob);const a=document.createElement('a');
  a.href=url;a.download='VisionOps_'+new Date().toISOString().slice(0,10)+'.vopsbak';a.click();
  setTimeout(()=>URL.revokeObjectURL(url),5000);toast('Şifreli yedek indirildi. Yedek parolanı güvenli sakla.');
 }catch(error){toast(error.message,true)}finally{el('backupPassphrase').value='';btn.disabled=false}
};
el('logout').onclick=async()=>{try{await api('/api/auth/logout',{method:'POST',body:'{}'})}catch(e){}location.replace('/choose')};

// Bulut sekmesi: açık kullanıcı işlemiyle veri aktarır. Parolayı hiçbir zaman saklamaz.
async function cloudStatus(){
 try{const d=await api('/api/cloud/status');el('cloudConnection').textContent=d.connected?'Bağlı':'Bağlı değil';if(!d.connected && d.saved_email && !el('cloudLoginEmail').value){el('cloudLoginEmail').value=d.saved_email;el('cloudRemember').checked=true;}el('cloudEmail').textContent=d.email||'—';if(d.connected&&el('cloudDisplayName'))el('cloudDisplayName').value=d.display_name||'';el('cloudRole').textContent=d.connected?(d.role==='admin'?'Yönetici':'Görüntüleyici'):'Bulut girişi yapılmadı';el('cloudMessage').textContent=d.connected?'Bağlantı aktif. Veriler yalnızca istediğinde senkronize edilir.':(d.message||'E-posta hesabınla giriş yap.');}
 catch(e){el('cloudMessage').textContent=e.message;}
}
el('cloudProfileForm').addEventListener('submit',async event=>{
 event.preventDefault();const pw=el('cloudProfilePassword').value;
 if(pw!==el('cloudProfileConfirm').value){el('cloudProfileMessage').textContent='Yeni parolalar eşleşmiyor.';return}
 const submit=event.target.querySelector('[type=submit]');submit.disabled=true;
 try{const d=await api('/api/cloud/profile',{method:'POST',body:JSON.stringify({
  display_name:el('cloudDisplayName').value.trim(),current_password:el('cloudProfileCurrent').value,
  new_password:pw
 })});event.target.reset();el('cloudProfileMessage').textContent=d.message;
 toast('Bulut hesabınız güncellendi. Yeniden giriş yapın.');await cloudStatus();
 }catch(error){el('cloudProfileMessage').textContent=error.message;toast(error.message,true)}finally{submit.disabled=false}
});
el('cloudForm').addEventListener('submit',async e=>{e.preventDefault();try{const email=el('cloudLoginEmail').value,password=el('cloudLoginPassword').value;await api('/api/cloud/login',{method:'POST',body:JSON.stringify({email,password,remember:el('cloudRemember').checked})});el('cloudLoginPassword').value='';toast('Bulut oturumu açıldı');await cloudStatus();}catch(err){el('cloudMessage').textContent=err.message;toast(err.message,true)}});
el('cloudSignup').onclick=async()=>{if(!confirm('Supabase üzerinde bu e-postayla ücretsiz bir hesap oluşturulsun mu?'))return;try{const email=el('cloudLoginEmail').value,password=el('cloudLoginPassword').value;const d=await api('/api/cloud/signup',{method:'POST',body:JSON.stringify({email,password,remember:el('cloudRemember').checked})});el('cloudLoginPassword').value='';if(d.connected)await cloudStatus();el('cloudMessage').textContent=d.message;toast(d.message)}catch(err){toast(err.message,true);el('cloudMessage').textContent=err.message}};
el('cloudRefresh').onclick=cloudStatus;
el('cloudLogout').onclick=async()=>{try{await api('/api/cloud/logout',{method:'POST',body:'{}'});el('cloudEvents').innerHTML='<div class="empty">Bulut oturumu kapatıldı.</div>';el('cloudCount').textContent='—';await cloudStatus();location.replace('/choose')}catch(e){toast(e.message,true)}};
el('cloudSync').onclick=async()=>{if(!confirm('Yerel olay kayıtlarının sıradaki bölümünü buluta gönderelim mi? Video aktarılmaz.'))return;const button=el('cloudSync');button.disabled=true;try{const d=await api('/api/cloud/sync',{method:'POST',body:'{}'});toast(d.message);await cloudLoad()}catch(e){toast(e.message,true)}finally{button.disabled=false}};
async function cloudLoad(){try{const d=await api('/api/cloud/events');el('cloudCount').textContent=d.events.length;el('cloudEvents').innerHTML=d.events.length?d.events.map(x=>`<div class="cloud-event"><strong>${esc(x.event_type)}</strong><span>${esc(x.observed_at||'')}</span></div>`).join(''):'<div class="empty">Bulutta kayıt bulunamadı.</div>';}catch(e){toast(e.message,true)}}
el('cloudLoad').onclick=cloudLoad;

// v0.6 privacy / experimental detection / opt-in background sync
let objectEnabled=false,autoCloudEnabled=false;
async function updateAi(){try{const a=await api('/api/ai/status');objectEnabled=a.object_detection==='on';el('aiObjectToggle').textContent=objectEnabled?'Deneysel nesne tanımayı kapat':'Deneysel nesne tanımayı aç';el('aiObjectStatus').textContent=a.object_model+' · '+(a.objects.length?a.objects.map(o=>o.name+' '+Math.round(o.confidence*100)+'%').join(', '):'Nesne henüz algılanmadı');}catch(e){el('aiObjectStatus').textContent=e.message;}}
el('aiObjectToggle').onclick=async()=>{const enabled=!objectEnabled;if(enabled&&!confirm('Deneysel YOLO-World modeli ilk kullanımda ücretsiz indirilir. Mama, su, kum veya kapı tanıma hatalı olabilir. Etkinleştirilsin mi?'))return;try{await api('/api/ai/object-detection',{method:'POST',body:JSON.stringify({enabled})});await updateAi();toast('Nesne algılama ayarı kaydedildi')}catch(e){toast(e.message,true)}};
el('aiObjectRefresh').onclick=updateAi;
async function cloudAutoStatus(){try{const d=await api('/api/cloud/auto-sync');autoCloudEnabled=d.enabled;el('cloudAuto').textContent=d.enabled?'Otomatik senkronizasyonu kapat':'Otomatik senkronizasyonu aç';el('cloudAuto').title=d.last_result||'';}catch(e){console.log(e.message)}}
el('cloudAuto').onclick=async()=>{const enabled=!autoCloudEnabled;if(enabled&&!confirm('Yerel AI olay kayıtları internet varken yaklaşık dakikada bir Supabase hesabına gönderilsin mi? Video gönderilmez.'))return;try{await api('/api/cloud/auto-sync',{method:'POST',body:JSON.stringify({enabled})});await cloudAutoStatus();toast(enabled?'Arka plan senkronizasyonu açıldı':'Arka plan senkronizasyonu kapatıldı')}catch(e){toast(e.message,true)}};
async function init(){try{const info=await api('/api/info');admin=info.role==='admin';el('username').textContent=info.user||'Kullanıcı';el('avatar').textContent=(info.user||'V').slice(0,1).toUpperCase();el('userrole').textContent=admin?'Yönetici':'Görüntüleyici';el('versionBadge').textContent='v'+info.version;if(admin){document.querySelectorAll('[data-admin]').forEach(e=>e.classList.add('visible'));}else{document.querySelectorAll('button[data-admin]').forEach(e=>e.style.display='none');document.querySelectorAll('.formstack input,.formstack select').forEach(e=>{});el('repoForm').querySelectorAll('input,button').forEach(e=>e.disabled=true);el('checkUpdate').disabled=true;el('downloadUpdate').disabled=true;el('localUpdate').disabled=true;el('updateFile').disabled=true;}
 await Promise.all([refreshAll(),loadCameras(),loadReports(),cloudStatus(),updateAi(),cloudAutoStatus()]);
 if(admin)setTimeout(autoCheckForUpdates,4200);
 }catch(e){console.error(e)}}
async function autoCheckForUpdates(){
 if(!admin)return;
 try{
  const cfg=await api('/api/updates/config');
  if(!cfg.owner||!cfg.repo)return;
  const d=await api('/api/updates/check',{method:'POST',body:'{}'});
  if(d.available){updateAvailable=d.asset;el('downloadUpdate').disabled=!d.asset;el('versionBadge').textContent='YENİ SÜRÜM';el('versionBadge').title=`Yeni sürüm v${d.latest}`;el('updateState').textContent=`v${d.latest} mevcut`;el('updateDetail').textContent='Ayarlar & Güncellemeler bölümünden indirebilirsin.';toast(`Yeni VisionOps sürümü bulundu: v${d.latest}`);}
 }catch(e){console.info('Automatic release check unavailable:',e.message)}
}
setInterval(()=>{refreshAll();},5000);setInterval(()=>{loadReports();},600000);setInterval(autoCheckForUpdates,3600000);init();


// v0.9.5: back navigation using touchpad horizontal gesture / Alt+Left / browser Back.
// A natural two-finger swipe often emits wheel(deltaX) on Windows WebView.
(function(){
 const stack=[];let lastId=null,lastGesture=0,backNavigating=false;
 function current(){return document.querySelector('.nav button[data-page].active')?.dataset.page||'home'}
 function goBack(){
   let previous=stack.pop();if(!previous || previous===current())previous='home';
   if(previous===current()){location.assign('/choose');return}
   const btn=document.querySelector('.nav button[data-page="'+previous+'"]');
   if(btn){backNavigating=true;btn.click();backNavigating=false;lastId=previous}else location.assign('/choose');
 }
 document.querySelectorAll('.nav button[data-page]').forEach(btn=>btn.addEventListener('click',()=>{
   const before=lastId||'home';if(!backNavigating&&btn.dataset.page!==before)stack.push(before);
   lastId=btn.dataset.page;
 }));
 document.addEventListener('keydown',ev=>{if(ev.altKey&&ev.key==='ArrowLeft'){
   if(ev.target.closest('input,textarea,[contenteditable=true]'))return;
   ev.preventDefault();goBack();}});
 document.addEventListener('wheel',ev=>{
   if(Math.abs(ev.deltaX)<65 || Math.abs(ev.deltaX)<Math.abs(ev.deltaY)*2 || Date.now()-lastGesture<900)return;
   if(ev.target.closest('.table-scroll,canvas,[data-horizontal-scroll]'))return;
   if(ev.deltaX<0){lastGesture=Date.now();goBack()}
 },{passive:true});
 window.addEventListener('popstate',()=>goBack());
 history.replaceState({visionops:true},'','#'+current());
 history.pushState({visionops:true},'','#workspace');
})();

window.addEventListener("visionops-appearance-change",()=>{drawChart(el("reportChart"),reportRows,true);drawChart(el("miniChart"),reportRows,false)});
