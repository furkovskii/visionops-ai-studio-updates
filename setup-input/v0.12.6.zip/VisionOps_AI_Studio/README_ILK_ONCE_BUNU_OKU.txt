﻿VisionOps v0.12.5 — Remote Sync (pilot)

Otomatik özet paylaşımı varsayılan olarak kapalıdır. Yetkili müşteri hesabı ile ürün paneline girin; Asistan > Mobil cihazla özet paylaş bölümünde açın. Her 120 saniyede yalnızca son günlük cihaz/ürün özeti gönderilir. Geçici hatalarda 300 saniye sonra yeniden denenir. Oturum kapanırsa, ürün değişirse, lisans iptal edilirse veya uygulama kapanırsa paylaşım durur. Başlamış HTTP isteği geri alınamaz. Kamera görüntüsü, ham olay, IP, parola veya kamera adı bu özellik ile gönderilmez. Paylaşım web hesabından kaldırılabilir; otomatik aktarım açıkken yeniden oluşturulabilir. Önceki Pet klasik motor kayıtları dahil değildir. Gerçek Windows/Supabase uçtan uca doğrulama bekliyor.

VisionOps AI Studio v0.12.2 — Local Language Assistant (pilot)
- Ollama Windows yerel servisini isteğe bağlı kurun: https://ollama.com/download/windows
- Terminal: ollama pull qwen2.5:3b
- Ollama çalışırken asistan içinde Yerel dil modelini kullan seçeneğini açın. Model sadece soru sınıflandırır; gerçek yanıt mevcut veri fonksiyonlarından gelir. Model yoksa kural tabanlı yanıt devam eder.
- İlk model indirmesi internet gerektirir; kamera verisi modele gönderilmez. Yerel servis varsayılan loopback adresinde kalmalıdır. Model kullanımında RAM/VRAM yükü artabilir.
- Gerçek model, Windows, fiziksel kamera ve uçtan uca Flask testi henüz yapılmadı. Paket yayınlanmadı.

--- Önceki notlar ---
VISIONOPS AI STUDIO v0.4 - GECIS KURULUMU
======================================

Bu surum, calisan v0.3 OBS -> VisionOps kamera yolunu korumayi hedefler.

KURULUM (Windows 10/11):
1) Onceki VisionOps penceresini KAPAT; ZIP'in tamamini yeni bir klasore cikart.
2) Gerekliyse OBS ve Fujifilm X Webcam yazilimlarinin kurulu olmasini sagla.
3) KURULUM_YAP.bat dosyasina cift tikla.
4) Kurulum tamamlansin. Python 3.12 bilgisayarinda kurulu olmali ve ilk kurulum icin internet baglantisi gerekir.
5) Masaustunde olusan VisionOps AI Studio kisayolunu ac.
6) Ilk ekranda YONETICI hesabi olustur. Kullanici adi 3-32 karakter, parola en az 10 karakter.
7) OBS'de Fujifilm goruntusu -> Sanal Kamerayi Baslat.
8) VisionOps > Canli Izleme > OBS Virtual Camera > Baglan.

ILK KURULUMDAN SONRA:
- Guncel uygulama %LOCALAPPDATA%\Programs\VisionOpsAIStudio altindadir.
- Olaylar/veriler ve kullanici hesaplari %LOCALAPPDATA%\VisionOpsAIStudio altindadir.
- Masaustu kisayolu arka planda Python'la calisir, siyah CMD acilmaz.
- v0.3 orijinal klasorun silinmez. Eski masaustu kisayolunu yeni kisa yol degistirir.
- Mevcut v0.3 veritabani varsa kisayolun eski calisma klasorunden veriyi tasimaya calisir.
- Kritik verilerinizi ayrica yedekleyin.

GUNCELLEMELER:
- Ayarlar & Guncellemeler ekraninda GitHub repository belirtilebilir.
- Yeni surum Release olarak yayimlandiginda indirilip dogrulanabilir.
- Uygulama kapatilip masaustu kisayoluyla tekrar acildiginda guncelleme uygulanir.
- GitHub baglantisi henuz mevcut degilse gelistirme ZIP'i yerel olarak uygulanabilir.
- Kullanicinin GitHub hesabi/depoyu kurmasi, veya GitHub baglantisini yetkilendirmesi gerekir.

SINIRLAR:
- Bu Windows'ta paketlenmis bagimsiz bir EXE degildir. Bilgisayarda Python 3.12 gerekir.
- YOLO kedi modeli ultralytics tarafindan ilk calistirmada otomatik indirilebilir.
- Mama, su ve kum kabini OTOMATIK tanima henuz gelistirilmedi.
- 10 dakikalik grafikler gecerli kamera olaylarini toplar; gercek tuketim olcumu degildir.
- Kullanici girisi bu bilgisayarda calisir; bulut kimlik dogrulama degildir.
- Kamerayi internete acma; program localhost uzerinde kalir.
- Yerel Windows Fujifilm/OBS donanim testi bu ortamda yapilamadi.

PROBLEMDE:
%LOCALAPPDATA%\VisionOpsAIStudio\visionops_studio.log
%LOCALAPPDATA%\VisionOpsAIStudio\visionops_launcher_error.log

VisionOps v0.9.5: New workspace splash, user list, and fixed sidebar.

VisionOps AI Studio v0.11.1 - Live Performance & Customer Pilot
GitHub'da henüz yayınlanmadı. v0.10.5-0.11.0 geliştirmelerini içerir.
GITHUB_YAYINLA.bat mevcut release-input/setup-input akışını kullanır. GitHub Actions
ve imza denetimi başarılı olduktan sonra uygulama içinden güncelleyin.

SISTEM SAGLIGI
Pet / Cafe / Farm: ortak canlı performans ekranı, 60 saniyelik yerel grafikler,
CPU, fiziksel RAM, GPU (en yoğun motor), disk doluluğu ve kamera/AI durumu.
Windows CPU/RAM GetSystemTimes / GlobalMemoryStatusEx; GPU Windows PowerShell CIM
GPU Engine / GPU Adapter Memory sayaçlarıyla ayrı arka plan iş parçacığında. Ek ücretli
yazılım veya yeni paket bağımlılığı yok. CPU/RAM/disk yaklaşık 1 saniye, GPU yaklaşık
5–8 saniye (yük ve sürücüye göre değişir). GPU ayrılmış/paylaşılan bellek GB olarak,
GPU yüzdesi motorlar arası en yüksek toplam süreç kullanımından türetilir; Görev
Yöneticisiyle birebir eşleşme garantisi yok. Eksik sayaç = bilinmiyor; sahte değer yok.
Ekran görünürken ölçülür; gecikmiş/eksik örnekler boşluk olarak gösterilir.
Disk grafiği kullanım kapasitesi, I/O hızı değil. AI motoru ve kamera son kare yaşı
ayrı gösterilir. Ölçümler yerel; buluta gönderilmez.

MUSTERI VE LISANS PILOTU
Yönetim Merkezi > Lisans & Yedekleme: varsayılan kapalı müşteri pilotu ve mevcut
web paket kayıtlarının salt okunur listesi (yerel ve Supabase yönetici doğrulaması).
Yeni lisans verme / iptal / ödeme işlemi eklenmedi; mevcut web yönetimini kullanın.
Onaylı ve süresi geçmemiş paket olmadan ilgili müşteri paneli açılmaz. Paket eşlemesi
baslangic=Pet, isletme=Cafe, kurumsal=Farm (mevcut order_requests akışı). Yeni ortak
kamera motoru müşteri erişimi opt-in; pilot kapalıyken eski Pet müşteri erişimi
korunur. Yerel admin hesabının erişimi korunur. Süreli sunucu bellek oturumu, API
istekleriyle yaklaşık 20 sn aralıkla tekrar doğrulanır; lisans sona ererse veya
bulut doğrulaması başarısızsa oturum/kameralar kapatılır. İstek gelmezse 40 sn
sonra oturum biter. Tek yerel etkin müşteri oturumu. Aynı Windows hesabı cihaz
sınırıdır; müşterilerin kamera kasası ve analiz dosyaları ürün ve sabit bulut UUID'si
ile ayrılır. Cafe/Farm eski global klasik sayım ekranı yöneticiye özel kalır.
Pet klasik veritabanı hesabı değiştirmek için uygulamayı kapatıp açmak gerekebilir.
Supabase tabloları, RLS politikaları, web sitesi ve GitHub üretim yayını değiştirilmedi.
Gerçek müşteri ve RLS uçtan uca testi olmadan genel ticari kullanıma açmayın.

OTOMATIK SIFRELI YEDEK
Yönetim Merkezi > Lisans & Yedekleme: 12/24/72/168 saat seçeneği, 12–256 karakterlik
yedek parolası, şimdi yedekle ve otomatiği kapat. Varsayılan kapalı. Parola ve zamanlama
Windows DPAPI ile aynı Windows hesabında saklanır; taşınabilir arşiv mevcut AES-GCM /
Scrypt formatında, mevcut yedek geri yükleme aracıyla açılır. Uygulama açıkken çalışır;
kaçan yedek sonraki açılışta (60 sn içinde kontrol) alınır. Son 7 otomatik arşiv tutulur;
el ile dışa aktarılmış arşivler silinmez. Konum: VisionOps veri dizini / auto_backups.
Kamera DPAPI kasaları, bulut tokenları ve otomatik yedek parolası taşınabilir arşive dahil
edilmez. Yedek parolasını ayrıca saklayın; yedek bu diskteyse disk arızasına karşı ikinci
bir kopya gereklidir. Geri yükleme sırasında uygulama tamamen kapalı olmalıdır.

TEST DURUMU
Python derleme; Linux geliştirici CPU/RAM örnekleme ve sentetik GPU ölçümleri;
mock lisans rol/paket/iptal, kamera sahipliği; gerçek AES-GCM/Scrypt şifreli SQLite
backup/restore ve 7 arşiv sınırı (DPAPI mock); v0.11.0 otomatik iz/alan regresyonu;
Chromium sahte API ile Pet/Cafe/Farm grafik güncellemeleri, müşteri Cafe görünümü,
yönetici lisans listesi ve yedek ayarları. Flask gerçek sunucu, Windows sayaçları,
DPAPI ve GPU, gerçek Supabase kullanıcıları/RLS, fiziksel kamera/model doğruluğu,
uzun süreli çalışma ve GitHub Actions henüz test edilmedi. Önizlemeler simülasyondur.
Ticari dağıtım öncesinde KVKK, model/kitaplık lisansları ve güvenlik QA gereklidir.


VisionOps AI Studio v0.11.2 — Stability & Recovery
GitHub'da henüz yayımlanmadı. v0.11.1 dahil önceki özellikler korunur.

KAMERA VE SISTEM SAGLIGI
- Dört ortak kamera kaynağı, her kaynak son JPEG ve en yeni AI örneğini tutar.
  Önizleme hedefi en fazla 8 FPS (önceki sürümle aynı); kare boyutu en fazla 960×720.
- Hızlı kaynaklarda dekoder eski kareleri biriktirmeden boşaltılır; döngüye küçük bekleme eklendi.
- Bağlantı başarısızsa 2–30 saniye artan bekleme, 10 saniye kararlı görüntü sonrası sıfırlama.
  Sürücü release hatası diğer bağlantı denemelerini engellemez.
- 12 saniye yeni kare yoksa görüntü gecikiyor, 25 saniye açılış yoksa sürücü yanıtı bekleniyor.
  Eski kare yerine bekleme görüntüsü; görüntü gelince aynı akışta devam edilir. Yeniden açılan
  tarayıcı görüntüleri hata sonrası yeniden denenir. Sürücü tamamen kilitlenirse Python iş
  parçacığı zorla durdurulmaz; uygulamayı yeniden açmak gerekebilir.
- Sistem Sağlığı: kamera bazında ölçülen önizleme FPS, yeniden bağlantı sayısı, son kare yaşı,
  sonraki bağlantı denemesine kalan süre ve durmuş iş parçacığı göstergesi. Sayaçlar oturumluk.
- İzleyici sayısı kamera başına 3 (akış kapanınca serbest kalır), görüntü kuyruğu yok.
- İş parçacığı beklenmedik şekilde sona ererse watchdog yeniden başlatır (15 sn sınırla);
  müşteri lisansı sona erdiğinde yayın kapanır. Yerel olarak hiçbir kamera parolası loglanmaz.
- AI modeli 120 saniye aktif analiz yoksa serbest bırakılır (CUDA önbelleği mümkünse temizlenir).
  Yeniden analiz başlatınca yüklenir; ilk kare gecikebilir. CUDA yükü, gerçek RAM ve GPU kazancı
  fiziksel test yapılmadığından ölçülmemiştir.

GUVENLIK / GUNCELLEME
- Oturumlu sayfalar ve API yanıtları no-store; yeni güncelleyici tekrarlanan ZIP dosyalarını reddeder.
- Güncelleme sırasında kısmi dosya yazımı bozulursa geri alma kapsamına alınır.
- Mevcut imzalı GitHub Actions akışı, yerel kimlik, müşteri pilotu ve yedekleme korunur.
- Supabase tabloları/RLS, üretim sitesi ve GitHub yayını değiştirilmedi; yeni hizmet yok.

TEST SINIRLARI
Python derleme; gerçek OpenCV JPEG kodlaması ile dört eş zamanlı sahte kaynak, tek kaynak kopma
ve yeniden bağlanma, release istisnası, kare boyutu, akış sınırı ve temizliği, eski kare yerine
bekleme karesi, müşteri oturum süresi. Önceki hesap/paket, otomatik analiz, AES-GCM yedek/geri
alma regresyonları; eski güncelleyici sahneleme/uygulama kontrolleri. Testler Linux ve simüle
edilmiş kamera/verilerle. Windows fiziksel kamera/GPU, 24–72 saat gerçek dayanıklılık testi,
Flask canlı sunucu / WebView uçtan uca, Supabase canlı RLS, GitHub Actions ve ticari güvenlik
incelemesi henüz yapılmadı. Ticari hazır sürüm olarak değerlendirilmemeli.

YAYIN
GITHUB_YAYINLA.bat mevcut release-input/setup-input ile yayınlar. GitHub Actions ve imza
kontrolleri başarılı olduktan sonra uygulama içinden güncellemeleri denetleyin. Şimdilik
paketi saklayabilir, fiziksel pilot testine hazır olunca yayınlayabilirsiniz.


VisionOps AI Studio v0.11.3 — Analytics Review & Regression
GitHub'da yayımlanmadı. v0.11.2 dahil önceki tüm paket dosyaları temel alınmıştır.

AKILLI RAPOR MERKEZI
Canlı İzleme / Çoklu Kamera > ilgili kamera > Analiz & rapor.
- Günlük, geriye dönük 7 günlük bloklar, aylık (yalnız son 30 gün kayıtları) grafikler.
- Bugünün otomatik metin özeti, ölçülen ortalama algılama, geçici iz sayısı ve gözlenen süre.
  Özet yerel deterministik hesaplama; yeni üretken AI API'si veya ücretli hizmet yok.
- Cafe: birden fazla kişi aynı masadaysa bir kez sayılan masa yakınlığı ve oturma adayı;
  örnekte tanınan masalar paydadır, görünmeyen masa verisi bilinmiyor (0 kabul edilmez).
  Örneklerden türetilmiş oran; kesin masa doluluğu veya ziyaretçi sayısı değildir.
- Kaybolan iz en son görüldüğü anda süreyi bitirir; gerçek çıkış olarak sayılmaz.
  Kesinti ve manuel analiz durdurma gibi durumlarda sonlanmamış izler süre hesabına alınmaz.
- Günlük 7/30 gün CSV; 7 tamamlanmış gün ile önceki 7 gün karşılaştırması, her iki
  dönemde de her gün kayıt varsa gösterilir; çalışma süresi eşit olmayabilir.
- Mevcut yerel SQLite dosyalarına ek tablo, eski kayıtlar korunur; eski masa örneği yoksa boş.
- Eski AI karesi ve alan sayımı bağlantı gecikmesinde geçerli sonuç olarak gösterilmez.
- Bazı yanlış biçimli istekler reddedilir; müşteri Cafe/Farm rol etiketi düzeltildi.
- Panel renkleri ve ayrı akıllı uyarı / sağlık ekranları korunur. Supabase ve web sitesi
  değişmedi; GitHub otomatik imzalı yayımlama akışı aynı.

DENETIM / TESTLER
Linux: Python derleme, üç Jinja şablonu ve JavaScript sözdizimi; Chromium'da gerçek
rapor bileşeni + sentetik veri (günlük/haftalık/aylık filtre ve boş değerler); dört eşzamanlı
sahte kamera, yeniden bağlantı, bayat kare, izleyici sınırı, müşteri lisans kontrolleri,
CPU/RAM ve sentetik GPU sayaçları, gerçek şifreli yedek/geri yükleme (DPAPI taklit),
otomatik iz/alan/uyarı, eski SQLite şeması, masa başına tek sayım, kasa ve rapor sahipliği,
eski sürüm güncelleyici stage/apply ve bozuk güncelleme geri alma testleri.
Bu kapsam tam güvenlik sertifikası değildir. Gerçek Windows/WebView/Flask uçtan uca,
Supabase RLS, DPAPI, GPU/model doğruluğu, dört fiziksel kamera, 24–72 saat dayanıklılık,
GitHub Actions ve ticari lisans/KVKK denetimi henüz yapılmadı. Üretim yayını değildir.

YAYIN
GITHUB_YAYINLA.bat mevcut release-input/setup-input akışı içindir. Önce Windows pilot
ve imza denetimi önerilir. Uygulama içi güncelleme yalnız imzalı yayımlanmış paketi alır.


VisionOps AI Studio v0.11.4 — Admin Studio
GitHub'da yayımlanmadı. v0.11.3 temeli korunur.
- Yeni sol menü ve ayrı Genel Bakış, Kullanıcılar, Lisanslar, Yedekleme, Hesap Ayarları ekranları.
- Kullanıcı ve lisans listelerinde yerel arama; gerçek API yanıtından aktif hesap sayısı ve pilot/yedek durumu.
- Mevcut yönetici API'leri, CSRF, ürün erişim bağlantıları, hesap işlemleri ve yedekleme işlevleri korunur.
- Chromium: gerçek Jinja şablonu + taklit API yanıtları ile gezinme, arama, pilot/yedek istekleri, geçmiş ve dar ekran testi.
- Windows, canlı Supabase, fiziksel kameralar ve yayın imzası henüz uçtan uca test edilmedi.
- Paket değerlendirme içindir; yayınlama için ayrıca onay gerekir.


VisionOps AI Studio v0.12.0 — Beta / Personalization
- Yönetim merkezi: antrasit ve bronz, fotoğraflı çalışma alanları, gerçek CPU/RAM/GPU/disk mini grafikleri; GPU ölçümü yoksa boş gösterilir.
- Pet, Cafe, Farm ve yönetim panelinde tema (varsayılan / antrasit / açık), yerleşim, yazı boyutu ve animasyon ayarları.
- Ayarlar yerel hesap ve panel bazında dosyaya kaydedilir; kamera ve lisans bilgileri değiştirilmez. Görünüm ayarları taşınabilir yedeğe henüz dahil değildir.
- Python/Jinja/JavaScript kontrolleri, Chromium taklit API testleri ve hesap/panel izolasyonu testleri. Gerçek Windows/WebView, GPU, fiziksel kamera ve canlı Supabase doğrulaması bekler.
- Yayın paketi mevcut imzalı GitHub iş akışıyla dağıtılmalıdır.


V0.12.1 — Yerel asistan ve operasyon merkezi
Pet/Cafe/Farm ve yönetici ekranında VisionOps Asistan düğmesi. Kural tabanlı; üretken model veya harici API yok. Ortak kamera motoru verilerini sorgular; eski Pet klasik kayıtları kapsam dışıdır. Süreler görünür iz süreleri ve doluluk tahminidir, gerçek ziyaretçi sayısı değildir. Yönetim özeti yalnızca bu bilgisayardaki çalışmakta olan kamera oturumları, yerel hesaplar, pilot ve yedek durumunu içerir. Bulut merkezi cihaz yönetimi ve yeni lisans işlemleri eklenmedi.
Test: Python derleme, Jinja şablon ayrıştırma ve dört asistan makrosu, Node JS sözdizimi, SQLite örnek hesaplama ve hesap/panel ayrımı, yönetim özeti sentetik verilerle başarılı. Flask mevcut olmadığından HTTP oturum, gerçek tarayıcı, Windows, fiziksel kamera ve GitHub yayın testleri yapılmadı.
