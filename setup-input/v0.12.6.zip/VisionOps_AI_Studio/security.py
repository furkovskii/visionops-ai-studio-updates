"""Local-only authentication. No password or private event data is uploaded to GitHub."""
import os
import re
import hashlib
import urllib.request
import secrets
import sqlite3
import time
from datetime import timedelta
import threading
from pathlib import Path
from functools import wraps
from flask import abort, g, jsonify, redirect, render_template, request, session, url_for
from werkzeug.security import generate_password_hash, check_password_hash

LOCK = threading.Lock()
FAILURES = {}
USERNAME = re.compile(r'^[a-zA-Z0-9_.-]{3,32}$')


def check_known_breached_password(password):
    """HIBP k-anonymity: sends only five SHA-1 hex chars, never password/full digest.

    Returns a user-facing error if compromised OR checking is unavailable.
    Password itself is never logged or uploaded.
    """
    if not password:
        return 'Yeni parola boş olamaz.'
    digest=hashlib.sha1(password.encode('utf-8')).hexdigest().upper()
    request=urllib.request.Request(
        'https://api.pwnedpasswords.com/range/'+digest[:5],
        headers={'User-Agent':'VisionOpsAIStudio/0.9.3 PasswordSafety', 'Add-Padding':'true'}
    )
    try:
        with urllib.request.urlopen(request, timeout=8) as response:
            if response.status != 200:
                return 'Parola güvenlik denetimi şu anda kullanılamıyor; tekrar deneyin.'
            content=response.read(1200000).decode('ascii')
    except Exception:
        return 'Güvenli parola kontrolüne ulaşılamadı. İnternet bağlantısını kontrol edin ve tekrar deneyin.'
    suffix=digest[5:]
    for line in content.splitlines():
        left,_,count=line.partition(':')
        if len(left)==35 and secrets.compare_digest(left.upper(),suffix) and count.strip().isdigit() and int(count)>0:
            return 'Bu parola bilinen bir veri ihlalinde görülmüş. Farklı ve benzersiz bir parola seçin.'
    return None



def init_security(app, data_dir):
    users_db = Path(data_dir) / 'users.db'
    secret_file = Path(data_dir) / '.session_secret'
    if not secret_file.exists():
        try:
            with secret_file.open('x', encoding='ascii') as f:
                f.write(secrets.token_hex(32))
            if os.name != 'nt': os.chmod(secret_file, 0o600)
        except FileExistsError:
            pass
    # New ephemeral session signing key each time desktop process starts: reopen requires login.
    app.secret_key = secrets.token_urlsafe(48)
    app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Strict',
                      SESSION_COOKIE_SECURE=False, PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
                      MAX_CONTENT_LENGTH=32*1024*1024)

    def database():
        connection = sqlite3.connect(users_db, timeout=20)
        connection.row_factory = sqlite3.Row
        return connection

    with database() as conn:
        conn.execute('''CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE COLLATE NOCASE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('admin','viewer')),
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            is_active INTEGER DEFAULT 1)''')

    with database() as conn:
        columns={row['name'] for row in conn.execute('PRAGMA table_info(users)')}
        if 'credential_version' not in columns:
            conn.execute('ALTER TABLE users ADD COLUMN credential_version INTEGER NOT NULL DEFAULT 0')
        if 'last_login_at' not in columns:
            conn.execute('ALTER TABLE users ADD COLUMN last_login_at TEXT')

    def any_users():
        with database() as conn:
            return conn.execute('SELECT 1 FROM users LIMIT 1').fetchone() is not None

    def form_session():
        if 'csrf' not in session: session['csrf'] = secrets.token_hex(24)
        return session['csrf']

    @app.before_request
    def authentication_gate():
        # The local HTTP server is bound only to 127.0.0.1 by studio.py.
        path = request.path
        if request.host.split(':')[0].lower() not in ('127.0.0.1','localhost'):
            return jsonify({'error':'Geçersiz sunucu adı.'}),403
        if path in ('/login', '/setup', '/choose', '/workspace/leave', '/api/workspace/customer-login') or path.startswith('/activate/') or path.startswith('/api/auth/'):
            if request.method not in ('GET','HEAD','OPTIONS'):
                origin = request.headers.get('Origin')
                if origin and origin != request.host_url.rstrip('/'):
                    return jsonify({'error':'Geçersiz kaynak.'}),403
                if not session.get('csrf') or not secrets.compare_digest(request.headers.get('X-CSRF-Token',''), session['csrf']):
                    return jsonify({'error':'İstek doğrulama hatası.'}),403
            return None
        customer = session.get('customer_key')
        if customer:
            allowed = ('/', '/video', '/api/account/me', '/api/workspace/select',
                       '/api/cameras', '/api/status', '/api/start', '/api/stop',
                       '/api/zones', '/api/events', '/api/summary', '/api/reports/ten-minute',
                       '/api/info', '/api/ai/status', '/api/ai/object-detection',
                       '/api/cloud/status', '/api/workspace/license', '/api/workspace/system-health',
                       '/api/workspace/ip-cameras', '/api/workspace/onvif/discover', '/api/workspace/onvif/profiles',
                       '/api/workspace/camera-devices', '/api/workspace/wall-alerts', '/api/workspace/appearance', '/api/workspace/assistant', '/api/workspace/remote-share', '/api/workspace/remote-auto')
            if path.startswith('/static/'):
                return None
            if path not in allowed and not path.startswith(('/workspace/', '/api/zones/', '/api/workspace/ip-cameras/', '/api/workspace/wall-analytics/', '/api/workspace/wall-rules/')):
                return jsonify({'error':'Bu işlem müşteri oturumuna açık değil.'}),403
            if request.method not in ('GET','HEAD','OPTIONS'):
                origin = request.headers.get('Origin')
                if origin and origin != request.host_url.rstrip('/'):
                    return jsonify({'error':'Geçersiz kaynak.'}),403
                if not session.get('csrf') or not secrets.compare_digest(request.headers.get('X-CSRF-Token',''), session['csrf']):
                    return jsonify({'error':'İstek doğrulama hatası.'}),403
            g.current_user = {'id':customer, 'username':session['customer_email'], 'role':'viewer'}
            return None
        uid = session.get('user_id')
        if not uid:
            if path.startswith('/api/') or path == '/video': return jsonify({'error':'Oturum açılmalı.'}),401
            return redirect('/setup' if not any_users() else '/login')
        with database() as conn:
            user = conn.execute('SELECT id,username,role,is_active,credential_version FROM users WHERE id=?',(uid,)).fetchone()
        if user and int(session.get('credential_version', 0)) != int(user['credential_version']):
            session.clear()
            if path.startswith('/api/') or path == '/video':
                return jsonify({'error':'Hesap bilgileri degistirildi; yeniden giris yapin.'}),401
            return redirect('/choose')
        if not user or not user['is_active']:
            session.clear()
            if path.startswith('/api/') or path == '/video':
                return jsonify({'error':'Oturum geçersiz.'}),401
            return redirect('/login')
        g.current_user = dict(user)
        session['username'] = user['username']
        session['role'] = user['role']
        if request.method not in ('GET','HEAD','OPTIONS'):
            if path.startswith('/api/') and session.get('role')!='admin' and path not in ('/api/account/change','/api/cloud/login','/api/cloud/logout','/api/cloud/signup','/api/cloud/profile','/api/workspace/select'):
                return jsonify({'error':'Bu işlem için yönetici yetkisi gerekiyor.'}),403
            origin = request.headers.get('Origin')
            if origin and origin != request.host_url.rstrip('/'):
                return jsonify({'error':'Geçersiz kaynak.'}),403
            if not session.get('csrf') or not secrets.compare_digest(request.headers.get('X-CSRF-Token',''), session['csrf']):
                return jsonify({'error':'Güvenlik doğrulaması başarısız; sayfayı yenileyin.'}),403
        return None

    @app.after_request
    def security_headers(resp):
        resp.headers['X-Content-Type-Options'] = 'nosniff'
        resp.headers['X-Frame-Options'] = 'SAMEORIGIN' if request.path == '/admin/preview' else 'DENY'
        resp.headers['Referrer-Policy'] = 'no-referrer'
        if request.path in ('/','/video','/login','/setup','/choose','/admin','/activate/pet','/activate/cafe','/activate/farm') or request.path.startswith(('/api/','/workspace/')):
            resp.headers['Cache-Control'] = 'no-store'
        return resp

    @app.route('/login')
    def login_page():
        if not any_users(): return redirect('/setup')
        if session.get('user_id'): return redirect('/choose')
        return render_template('login.html', mode='login', csrf=form_session())

    @app.route('/setup')
    def setup_page():
        if any_users(): return redirect('/login')
        return render_template('login.html', mode='setup', csrf=form_session())

    @app.route('/api/auth/setup',methods=['POST'])
    def setup():
        data = request.get_json(silent=True) or {}
        username = str(data.get('username','')).strip()
        password = str(data.get('password',''))
        if not USERNAME.fullmatch(username) or len(password)<10 or len(password)>256:
            return jsonify({'error':'Kullanıcı adı 3–32 karakter; parola en az 10 karakter olmalı.'}),400
        warning=check_known_breached_password(password)
        if warning:return jsonify({'error':warning}),400
        with LOCK:
            if any_users(): return jsonify({'error':'Yönetici kurulumu zaten tamamlanmış.'}),409
            with database() as conn:
                cur=conn.execute('INSERT INTO users(username,password_hash,role) VALUES(?,?,?)',
                                (username,generate_password_hash(password,method='scrypt'),'admin'))
                uid=cur.lastrowid
        session.clear(); session.update(user_id=uid,username=username,role='admin',credential_version=0,csrf=secrets.token_hex(24))
        session.permanent=False
        return jsonify({'ok':True})

    @app.route('/api/auth/login',methods=['POST'])
    def login():
        data=request.get_json(silent=True) or {}
        username=str(data.get('username','')).strip()[:64]
        password=str(data.get('password',''))
        key=username.lower()
        now=time.monotonic()
        with LOCK:
            failures=[t for t in FAILURES.get(key,[]) if now-t<600]
            FAILURES[key]=failures
            if len(failures)>=6: return jsonify({'error':'Çok fazla hatalı deneme. 10 dakika sonra tekrar deneyin.'}),429
        with database() as conn:
            user=conn.execute('SELECT * FROM users WHERE username=? AND is_active=1',(username,)).fetchone()
        if not user or user['role'] != 'admin' or not check_password_hash(user['password_hash'], password):
            with LOCK: FAILURES.setdefault(key,[]).append(now)
            return jsonify({'error':'Kullanıcı adı veya parola hatalı.'}),401
        callback = app.config.get('VISIONOPS_CLEAR_SESSION')
        if callback:
            callback()
        with LOCK: FAILURES.pop(key,None)
        with database() as conn:
            conn.execute('UPDATE users SET last_login_at=CURRENT_TIMESTAMP WHERE id=?',(user['id'],))
        session.clear();session.update(user_id=user['id'],username=user['username'],role=user['role'],credential_version=user['credential_version'],csrf=secrets.token_hex(24))
        session.permanent=False
        return jsonify({'ok':True})

    @app.route('/api/auth/session')
    def current_session():
        if not session.get('user_id'): return jsonify({'authenticated':False}),401
        return jsonify({'authenticated':True,'username':session['username'],
                        'role':session['role'],'csrf':form_session()})

    @app.route('/api/auth/logout',methods=['POST'])
    def logout():
        callback = app.config.get('VISIONOPS_CLEAR_SESSION')
        if callback:
            callback()
        session.clear()
        return jsonify({'ok':True})

    @app.route('/api/account/me', methods=['GET'])
    def account_me():
        user=g.current_user
        return jsonify({'username':user['username'],'role':user['role']})

    @app.route('/api/account/change', methods=['POST'])
    def account_change():
        """Any signed-in user may change only their own credentials with current password."""
        data=request.get_json(silent=True) or {}
        uid=g.current_user['id']
        current=str(data.get('current_password',''))
        desired_username=str(data.get('username','')).strip()
        fresh_pw=str(data.get('new_password',''))
        if not USERNAME.fullmatch(desired_username):
            return jsonify({'error':'Kullanıcı adı 3-32 karakter olmalı (harf, rakam, _, -, .).'}),400
        if fresh_pw and not 10 <= len(fresh_pw) <= 256:
            return jsonify({'error':'Yeni parola en az 10 karakter olmalı.'}),400
        if not current:
            return jsonify({'error':'Değişiklik için mevcut parolanızı girin.'}),400
        if fresh_pw:
            warning=check_known_breached_password(fresh_pw)
            if warning:return jsonify({'error':warning}),400
        now=time.monotonic()
        key='account-change:'+str(uid)
        with LOCK:
            recent=[v for v in FAILURES.get(key,[]) if now-v < 600]
            FAILURES[key]=recent
            if len(recent)>=6:
                return jsonify({'error':'Çok fazla yanlış parola. 10 dakika sonra deneyin.'}),429
            with database() as conn:
                user=conn.execute('SELECT id,username,password_hash FROM users WHERE id=? AND is_active=1',(uid,)).fetchone()
                if not user or user['role'] != 'admin' or not check_password_hash(user['password_hash'],current):
                    FAILURES.setdefault(key,[]).append(now)
                    return jsonify({'error':'Mevcut parola yanlış.'}),401
                FAILURES.pop(key,None)
                try:
                    with conn:
                        if fresh_pw:
                            conn.execute('UPDATE users SET username=?,password_hash=?,credential_version=credential_version+1 WHERE id=?',
                                (desired_username,generate_password_hash(fresh_pw,method='scrypt'),uid))
                        else:
                            conn.execute('UPDATE users SET username=?,credential_version=credential_version+1 WHERE id=?',
                                (desired_username,uid))
                except sqlite3.IntegrityError:
                    return jsonify({'error':'Bu kullanıcı adı başka bir hesaba ait.'}),409
        # Invalidate the old session after all changes, including username-only updates.
        session.clear()
        return jsonify({'ok':True,'username':desired_username,'relogin_required':True})

    @app.route('/api/users')
    def users():
        if session.get('role')!='admin': return jsonify({'error':'Yönetici yetkisi gerekiyor.'}),403
        with database() as conn:
            records=[dict(row) for row in conn.execute('SELECT id,username,role,created_at,is_active,last_login_at FROM users ORDER BY id')]
        return jsonify(records)

    @app.route('/api/users',methods=['POST'])
    def add_user():
        if session.get('role')!='admin': return jsonify({'error':'Yönetici yetkisi gerekiyor.'}),403
        data=request.get_json(silent=True) or {}
        username=str(data.get('username','')).strip()
        password=str(data.get('password',''))
        role=data.get('role','viewer')
        if not USERNAME.fullmatch(username) or not 10<=len(password)<=256 or role not in ('admin','viewer'):
            return jsonify({'error':'Geçersiz kullanıcı adı, parola veya rol.'}),400
        try:
            with database() as conn:
                conn.execute('INSERT INTO users(username,password_hash,role) VALUES(?,?,?)',
                             (username,generate_password_hash(password,method='scrypt'),role))
        except sqlite3.IntegrityError:
            return jsonify({'error':'Bu kullanıcı adı kullanılıyor.'}),409
        return jsonify({'ok':True}),201

    @app.route('/api/users/<int:uid>/password',methods=['POST'])
    def reset_password(uid):
        if session.get('role')!='admin': return jsonify({'error':'Yönetici yetkisi gerekiyor.'}),403
        password=str((request.get_json(silent=True) or {}).get('password',''))
        if not 10<=len(password)<=256: return jsonify({'error':'En az 10 karakterli parola gerekli.'}),400
        with database() as conn:
            changed=conn.execute('UPDATE users SET password_hash=?, credential_version=credential_version+1 WHERE id=?',(generate_password_hash(password,method='scrypt'),uid)).rowcount
        return jsonify({'ok':bool(changed)}),200 if changed else 404

    @app.route('/api/users/<int:uid>',methods=['DELETE'])
    def remove_user(uid):
        if session.get('role')!='admin': return jsonify({'error':'Yönetici yetkisi gerekiyor.'}),403
        if uid==session.get('user_id'): return jsonify({'error':'Kendi hesabınızı silemezsiniz.'}),400
        with database() as conn:
            target=conn.execute('SELECT role FROM users WHERE id=?',(uid,)).fetchone()
            if not target: return jsonify({'error':'Kullanıcı bulunamadı.'}),404
            if target['role']=='admin':
                count=conn.execute("SELECT COUNT(*) FROM users WHERE role='admin'").fetchone()[0]
                if count<=1: return jsonify({'error':'Son yönetici silinemez.'}),400
            conn.execute('DELETE FROM users WHERE id=?',(uid,))
        return jsonify({'ok':True})

    # Provide token through template, not public API.
    app.context_processor(lambda: {'csrf_token': lambda:form_session()})
