"""Hidden Windows launcher that also applies verified staged updates before startup."""
from pathlib import Path
import os
import subprocess
import traceback

ROOT=Path(__file__).resolve().parent
DATA=Path(os.environ.get('VISIONOPS_DATA_DIR',Path(os.environ.get('LOCALAPPDATA',str(Path.home())))/'VisionOpsAIStudio'))
DATA.mkdir(parents=True,exist_ok=True)
PYTHONW=ROOT/'.venv'/'Scripts'/'pythonw.exe'
try:
    if not PYTHONW.is_file():
        raise RuntimeError('Kurulum tamamlanmamış. KURULUM_YAP.bat dosyasını çalıştırın.')
    os.chdir(ROOT)
    # The app is not running yet; source files can safely be replaced.
    if (DATA/'update_pending.json').exists():
        proc=subprocess.run([str(PYTHONW),str(ROOT/'update_manager.py'),'--apply'],
            cwd=str(ROOT),creationflags=subprocess.CREATE_NO_WINDOW,timeout=120)
        if proc.returncode != 0:raise RuntimeError('Güncelleme uygulanamadı; eski sürüm korunuyor.')
    # Install free cryptography dependency once after v0.9.4 upgrade.
    marker_file=DATA/'cryptography_dependency_ready'
    if not marker_file.is_file():
        test=subprocess.run([str(PYTHONW),'-c','from cryptography.hazmat.primitives.ciphers.aead import AESGCM'],
            cwd=str(ROOT),creationflags=subprocess.CREATE_NO_WINDOW,timeout=15)
        if test.returncode!=0:
            install=subprocess.run([str(PYTHONW),'-m','pip','install','cryptography>=43,<47'],
                cwd=str(ROOT),creationflags=subprocess.CREATE_NO_WINDOW,timeout=180,
                stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            if install.returncode!=0:
                (DATA/'visionops_dependency_error.log').write_text(
                    'Ucretsiz cryptography kurulumu basarisiz. Yedekleme kullanilamaz; diger ozellikler calisir.\n',encoding='utf-8')
            else:marker_file.write_text('ok',encoding='ascii')
        else:marker_file.write_text('ok',encoding='ascii')
    with (DATA/'visionops_launcher.log').open('a',encoding='utf-8') as logfile:
        subprocess.Popen([str(PYTHONW),str(ROOT/'studio.py')],cwd=str(ROOT),
            stdout=logfile,stderr=logfile,creationflags=subprocess.CREATE_NO_WINDOW)
except Exception as e:
    (DATA/'visionops_launcher_error.log').write_text(traceback.format_exc(),encoding='utf-8')
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0,str(e)+'\n\nHata kaydı: '+str(DATA/'visionops_launcher_error.log'),
            'VisionOps AI Studio',0x10)
    except Exception:pass
