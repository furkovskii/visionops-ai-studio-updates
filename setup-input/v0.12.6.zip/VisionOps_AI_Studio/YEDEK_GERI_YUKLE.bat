﻿@echo off
chcp 65001 >nul
title VisionOps Sifreli Yedek Geri Yukleme
echo ONEMLI: VisionOps programini tamamen kapatin.
set /p FILE=Yedek dosyasinin tam yolunu girin: 
if not exist "%FILE%" (echo Yedek bulunamadi.&pause&exit /b 1)
"%~dp0.venv\Scripts\python.exe" "%~dp0secure_store.py" --restore "%FILE%"
pause
