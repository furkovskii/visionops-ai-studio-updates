﻿$ErrorActionPreference = 'Stop'
$source=Split-Path -Parent $MyInvocation.MyCommand.Path
$program=Join-Path $env:LOCALAPPDATA 'Programs\VisionOpsAIStudio'
$data=Join-Path $env:LOCALAPPDATA 'VisionOpsAIStudio'
Write-Host 'VisionOps AI Studio v0.10.6 - Kurulum' -ForegroundColor Cyan
Write-Host 'Gecis paketi mevcut v0.3 uygulamasini silmez.'
New-Item -ItemType Directory -Force -Path $program,$data | Out-Null
$desktop=[Environment]::GetFolderPath('Desktop')
$shell=New-Object -ComObject WScript.Shell
$shortcutPath=Join-Path $desktop 'VisionOps AI Studio.lnk'
if ((Test-Path $shortcutPath) -and !(Test-Path (Join-Path $data 'visionops.db'))) {
    try {
       $old=$shell.CreateShortcut($shortcutPath)
       $legacy=Join-Path $old.WorkingDirectory 'visionops.db'
       if (Test-Path $legacy) {
           Copy-Item -LiteralPath $legacy -Destination (Join-Path $data 'visionops.db') -ErrorAction Stop
           Write-Host 'Mevcut v0.3 olay ve alan verileri aktarildi.' -ForegroundColor Green
       }
    } catch { Write-Host 'Eski veri tasinmadi, onceki kurulum oldugu gibi korunuyor.' -ForegroundColor Yellow }
}
$files=@('app.py','security.py','secure_store.py','update_manager.py','studio.py','launcher.pyw','requirements.txt','version.json','VisionOps.ico')
foreach ($file in $files) { Copy-Item -LiteralPath (Join-Path $source $file) -Destination (Join-Path $program $file) -Force }
foreach ($dir in @('templates','static')) {
  $destination=Join-Path $program $dir
  if (Test-Path $destination) { Remove-Item -LiteralPath $destination -Recurse -Force }
  Copy-Item -LiteralPath (Join-Path $source $dir) -Destination $destination -Recurse -Force
}
Copy-Item -LiteralPath (Join-Path $source 'GITHUB_GUNCELLEME_REHBERI.txt') -Destination (Join-Path $program 'GITHUB_GUNCELLEME_REHBERI.txt') -Force
$python=Join-Path $program '.venv\Scripts\python.exe'
if (!(Test-Path $python)) {
   & py -3.12 --version
   if ($LASTEXITCODE -ne 0) { throw 'Python 3.12 bulunamadi. Python 3.12 gerekli.' }
   & py -3.12 -m venv (Join-Path $program '.venv')
   if ($LASTEXITCODE -ne 0) { throw 'Sanal ortam olusturulamadi.' }
}
Write-Host 'Gerekli kutuphaneler kontrol ediliyor / eksik olanlar yukleniyor...' -ForegroundColor Cyan
& $python -m pip install -r (Join-Path $program 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw 'Python paket kurulumu basarisiz.' }
# Optional on-disk camera model download happens at first camera analysis if uncached.
$shortcut=$shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath=Join-Path $program '.venv\Scripts\pythonw.exe'
$shortcut.Arguments='"'+(Join-Path $program 'launcher.pyw')+'"'
$shortcut.WorkingDirectory=$program
$shortcut.Description='VisionOps AI Studio v0.10.6 - kamera analizi, bulut ve guncelleme'
$ico=Join-Path $program 'VisionOps.ico'
if (Test-Path $ico) {$shortcut.IconLocation=$ico}
$shortcut.Save()
Write-Host 'Kurulum tamamlandi. Masaustu simgesi olusturuldu.' -ForegroundColor Green
Write-Host ('Uygulama konumu: ' + $program)
Write-Host ('Kisisel veriler: ' + $data)
