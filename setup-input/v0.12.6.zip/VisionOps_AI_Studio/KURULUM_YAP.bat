@echo off
setlocal
cd /d "%~dp0"
title VisionOps AI Studio - v0.7 Kurulum
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0KURULUM.ps1"
if errorlevel 1 (
 echo.
 echo Kurulum basarisiz oldu. Yukaridaki hata mesajini kontrol edin.
 pause
 exit /b 1
)
echo.
echo Kurulum tamamlandi. Masaustundeki VisionOps AI Studio kisayolunu kullanin.
pause
exit /b 0
