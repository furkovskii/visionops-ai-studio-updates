VISIONOPS AI STUDIO v0.4 - GECIS KURULUMU
======================================

Bu surum, calisan v0.3 OBS -> VisionOps kamera yolunu korumayi hedefler.

KURULUM (Windows 10/11):
1) Onceki VisionOps penceresini KAPAT; ZIP'in tamamini yeni bir klasore cikart.
2) Gerekliyse OBS ve Fujifilm X Webcam yazilimlarinin kurulu olmasini sagla.
3) KURULUM_YAP.bat dosyasina cift tikla.
4) Kurulum tamamlansin. Python 3.12 bilgisayarinda kurulu olmali ve ilk kurulum icin internet baglantisi gerekir.
5) Masaustunde olusan VisionOps AI Studio kisayolunu ac.
6) Ilk ekranda YONETICI hesabi olustur. Kullanici adi 3-32 karakter, parola en az 10 karakter.
7) OBS'de Fujifilm goruntusu -> Sanal Kamerayi Baslat.
8) VisionOps > Canli Izleme > OBS Virtual Camera > Baglan.

ILK KURULUMDAN SONRA:
- Guncel uygulama %LOCALAPPDATA%\Programs\VisionOpsAIStudio altindadir.
- Olaylar/veriler ve kullanici hesaplari %LOCALAPPDATA%\VisionOpsAIStudio altindadir.
- Masaustu kisayolu arka planda Python'la calisir, siyah CMD acilmaz.
- v0.3 orijinal klasorun silinmez. Eski masaustu kisayolunu yeni kisa yol degistirir.
- Mevcut v0.3 veritabani varsa kisayolun eski calisma klasorunden veriyi tasimaya calisir.
- Kritik verilerinizi ayrica yedekleyin.

GUNCELLEMELER:
- Ayarlar & Guncellemeler ekraninda GitHub repository belirtilebilir.
- Yeni surum Release olarak yayimlandiginda indirilip dogrulanabilir.
- Uygulama kapatilip masaustu kisayoluyla tekrar acildiginda guncelleme uygulanir.
- GitHub baglantisi henuz mevcut degilse gelistirme ZIP'i yerel olarak uygulanabilir.
- Kullanicinin GitHub hesabi/depoyu kurmasi, veya GitHub baglantisini yetkilendirmesi gerekir.

SINIRLAR:
- Bu Windows'ta paketlenmis bagimsiz bir EXE degildir. Bilgisayarda Python 3.12 gerekir.
- YOLO kedi modeli ultralytics tarafindan ilk calistirmada otomatik indirilebilir.
- Mama, su ve kum kabini OTOMATIK tanima henuz gelistirilmedi.
- 10 dakikalik grafikler gecerli kamera olaylarini toplar; gercek tuketim olcumu degildir.
- Kullanici girisi bu bilgisayarda calisir; bulut kimlik dogrulama degildir.
- Kamerayi internete acma; program localhost uzerinde kalir.
- Yerel Windows Fujifilm/OBS donanim testi bu ortamda yapilamadi.

PROBLEMDE:
%LOCALAPPDATA%\VisionOpsAIStudio\visionops_studio.log
%LOCALAPPDATA%\VisionOpsAIStudio\visionops_launcher_error.log

VisionOps v0.9.5: New workspace splash, user list, and fixed sidebar.
