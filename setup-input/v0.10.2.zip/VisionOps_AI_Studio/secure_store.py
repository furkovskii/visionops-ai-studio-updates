"""Windows-only DPAPI protection for opt-in cloud refresh token. No passwords saved."""
import ctypes, os
from ctypes import wintypes
from pathlib import Path

class DATA_BLOB(ctypes.Structure):
    _fields_=[('cbData',wintypes.DWORD),('pbData',ctypes.POINTER(ctypes.c_byte))]

def _blob(data):
    buffer=ctypes.create_string_buffer(data)
    return DATA_BLOB(len(data),ctypes.cast(buffer,ctypes.POINTER(ctypes.c_byte))),buffer

def _crypt(data,encrypt):
    if os.name!='nt': raise OSError('Windows DPAPI required for persistent cloud sessions')
    inp,buf=_blob(data)
    out=DATA_BLOB()
    crypt=ctypes.windll.crypt32
    crypt.CryptProtectData.argtypes=[ctypes.POINTER(DATA_BLOB),ctypes.c_wchar_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(DATA_BLOB)]
    crypt.CryptUnprotectData.argtypes=[ctypes.POINTER(DATA_BLOB),ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(DATA_BLOB)]
    action=crypt.CryptProtectData if encrypt else crypt.CryptUnprotectData
    ok=action(ctypes.byref(inp),None,None,None,None,0x01,ctypes.byref(out))
    if not ok: raise ctypes.WinError()
    try: return ctypes.string_at(out.pbData,out.cbData)
    finally:
        free=ctypes.windll.kernel32.LocalFree
        free.argtypes=[ctypes.c_void_p]
        free.restype=ctypes.c_void_p
        free(ctypes.cast(out.pbData,ctypes.c_void_p))

def save(path,data):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.tmp');tmp.write_bytes(_crypt(data,True));tmp.replace(path)

def read(path):
    return _crypt(Path(path).read_bytes(),False)

def delete(path):
    Path(path).unlink(missing_ok=True)


# Portable opt-in encrypted backup; embedded to support upgrading from v0.9.2 / v0.9.3
"""Password-encrypted, portable VisionOps SQLite backup; no cloud upload.

A backup contains sqlite3 consistent snapshots and selected visual settings.
It never includes raw cloud tokens, developer keys, or session secrets.
"""
import getpass
import io
import json
import os
import sqlite3
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

HEADER = b'VOPSBAK2\0'
MAX_SIZE = 160 * 1024 * 1024
FILES = {'visionops.db', 'users.db', 'panel_design.json', 'updates.json'}

def _keys(password, salt):
    if len(password) < 12:
        raise ValueError('Yedek parolası en az 12 karakter olmalı.')
    from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
    return Scrypt(salt=salt, length=32, n=2**15, r=8, p=1).derive(password.encode('utf-8'))

def _db_snapshot(path):
    # SQLite online backup avoids partial WAL snapshots while app is open.
    with tempfile.TemporaryDirectory() as temp:
        dest = Path(temp) / 'snapshot.db'
        source = sqlite3.connect(f'file:{path.as_posix()}?mode=ro', uri=True, timeout=15)
        try:
            target = sqlite3.connect(str(dest))
            try: source.backup(target)
            finally: target.close()
        finally: source.close()
        return dest.read_bytes()

def create_encrypted_backup(data_dir, password):
    data_dir = Path(data_dir)
    raw = io.BytesIO()
    with zipfile.ZipFile(raw, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as out:
        out.writestr('manifest.json', json.dumps({'format': 2, 'created_at': datetime.now(timezone.utc).isoformat(),
            'files': sorted(x for x in FILES if (data_dir/x).is_file())}))
        for name in sorted(FILES):
            f = data_dir / name
            if f.is_file():
                out.writestr(name, _db_snapshot(f) if name.endswith('.db') else f.read_bytes())
    plaintext = raw.getvalue()
    if len(plaintext) > MAX_SIZE: raise ValueError('Yedek çok büyük; kayıtları arşivleyin.')
    salt, nonce = os.urandom(16), os.urandom(12)
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    ciphertext = AESGCM(_keys(password, salt)).encrypt(nonce, plaintext, HEADER)
    return HEADER + salt + nonce + ciphertext

def decrypt_and_inspect(blob, password):
    if len(blob) > MAX_SIZE + 8192 or not blob.startswith(HEADER):
        raise ValueError('Dosya geçerli bir VisionOps şifreli yedeği değil.')
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    i = len(HEADER)
    # Salt (16), nonce (12), then AES-GCM ciphertext with authentication tag.
    plaintext = AESGCM(_keys(password, blob[i:i+16])).decrypt(blob[i+16:i+28], blob[i+28:], HEADER)
    archive = zipfile.ZipFile(io.BytesIO(plaintext))
    names = set(archive.namelist())
    if 'manifest.json' not in names or not (names-{'manifest.json'}) <= FILES:
        raise ValueError('Yedek içeriği beklenmeyen dosyalar barındırıyor.')
    if sum(z.file_size for z in archive.infolist()) > MAX_SIZE:
        raise ValueError('Yedek açılım sınırını aşıyor.')
    return archive

def restore_encrypted_backup(data_dir, backup_path, password):
    """Run only when VisionOps is stopped. Caller responsible for offline shutdown."""
    data_dir = Path(data_dir)
    archive = decrypt_and_inspect(Path(backup_path).read_bytes(), password)
    to_copy = {name: archive.read(name) for name in FILES if name in archive.namelist()}
    if not to_copy: raise ValueError('Yedekte aktarılacak veri dosyası yok.')
    # Validate sqlite bytes before altering existing files.
    with tempfile.TemporaryDirectory() as temp:
        for name, data in to_copy.items():
            if name.endswith('.db'):
                f = Path(temp) / name
                f.write_bytes(data)
                con = sqlite3.connect(str(f))
                try:
                    status = con.execute('PRAGMA integrity_check').fetchone()[0]
                    if status != 'ok': raise ValueError(name + ': SQL bütünlüğü bozuk.')
                finally: con.close()
    # All validation succeeded; retain old files under versioned folder.
    old = data_dir / ('restore_previous_' + datetime.now().strftime('%Y%m%d_%H%M%S'))
    old.mkdir(parents=True, exist_ok=False)
    for name, raw in to_copy.items():
        target = data_dir / name
        if target.exists(): target.replace(old/name)
        tmp = data_dir / (name+'.restore.tmp')
        tmp.write_bytes(raw)
        tmp.replace(target)
    return sorted(to_copy)


if __name__ == '__main__':
    import argparse, getpass
    ap=argparse.ArgumentParser(description='Restore encrypted VisionOps backup while the app is closed')
    ap.add_argument('--restore',required=True)
    ap.add_argument('--data-dir',default=str(Path(os.environ.get('VISIONOPS_DATA_DIR', Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'VisionOpsAIStudio'))))
    args=ap.parse_args()
    print('Close VisionOps completely before restoration. Previous data files will be preserved.')
    if input('Type RESTORE to continue: ') != 'RESTORE': raise SystemExit('Cancelled')
    result=restore_encrypted_backup(args.data_dir,args.restore,getpass.getpass('Backup password: '))
    print('Restored:', ', '.join(result))
