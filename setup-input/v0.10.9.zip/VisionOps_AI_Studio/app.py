import os, time, json, sqlite3, threading, shutil
from datetime import datetime
from pathlib import Path

import cv2
from flask import Flask, Response, jsonify, request, render_template

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("VISIONOPS_DATA_DIR", Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "VisionOpsAIStudio"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "visionops.db"
LEGACY_DB = APP_DIR / "visionops.db"
if not DB_PATH.exists() and LEGACY_DB.exists():
    shutil.copy2(LEGACY_DB, DB_PATH)
app = Flask(__name__)
from security import init_security
from update_manager import init_updates
init_security(app, DATA_DIR)
init_updates(app, DATA_DIR, APP_DIR)
# v0.9.4: opt-in encrypted backups; no passwords persisted.
from flask import send_file, session
from io import BytesIO
@app.post('/api/security/backup/export')
def export_secured_backup():
    if session.get('role')!='admin':
        return jsonify({'error':'Yönetici yetkisi gerekiyor.'}),403
    body=request.get_json(silent=True) or {}
    password=str(body.get('passphrase',''))
    if len(password)<12 or len(password)>256:
        return jsonify({'error':'12-256 karakterli, benzersiz bir yedek parolası girin.'}),400
    try:
        from secure_store import create_encrypted_backup
        from datetime import datetime
        blob=create_encrypted_backup(DATA_DIR,password)
        return send_file(BytesIO(blob),as_attachment=True,mimetype='application/octet-stream',
             download_name='VisionOps_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.vopsbak')
    except ImportError:
        return jsonify({'error':'Şifreleme kitaplığı eksik. Bir defa kurulumu yenileyin.'}),503
    except Exception as exc:
        return jsonify({'error':'Yedek oluşturulamadı: '+str(exc)}),400


# ---- VisionOps optional cloud bridge (bundled for v0.4.1 updater compatibility) ----
"""VisionOps cloud bridge: optional, explicit Supabase sync, in-memory user tokens.

No access/refresh tokens or passwords are written to disk or browser storage.
Cloud data is scoped by Supabase RLS (auth.uid()).
"""
import json
import time
import uuid
import threading
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path
import secrets
from secure_store import save as dpapi_save, read as dpapi_read, delete as dpapi_delete
from flask import jsonify, request, g, session, redirect, render_template

CLOUD_URL = 'https://uozderqllvhuiaquulhg.supabase.co'
CLOUD_PUBLISHABLE_KEY = 'sb_publishable_UynYBjWSFYyR4Samj6PeXA_gBD8OmCu'
_SESSIONS = {}  # local user id -> token data; wiped on app exit
for _old_token in DATA_DIR.glob('cloud_refresh_*.bin'):
    try: _old_token.unlink()
    except OSError: pass
_LOCK = threading.RLock()
_NS = uuid.UUID('f3a64975-4073-4cdd-9045-c2e329b7a453')

def _local_key():
    return g.current_user['id']

class CloudError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def _http(path, method='GET', data=None, jwt=None, prefer=None):
    headers = {'apikey': CLOUD_PUBLISHABLE_KEY, 'Accept': 'application/json'}
    if jwt: headers['Authorization'] = 'Bearer ' + jwt
    if data is not None: headers['Content-Type'] = 'application/json'
    if prefer: headers['Prefer'] = prefer
    body = json.dumps(data).encode('utf-8') if data is not None else None
    req = urllib.request.Request(CLOUD_URL + path, data=body, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            raw = response.read(1024 * 1024)
            return json.loads(raw) if raw else None
    except urllib.error.HTTPError as e:
        try:
            error = json.loads(e.read(4096).decode('utf-8'))
            message = error.get('msg') or error.get('message') or error.get('error_description') or 'Bulut sunucusu isteği reddetti.'
        except Exception: message = 'Bulut sunucusu isteği reddetti.'
        raise CloudError(message, e.code)
    except (TimeoutError, OSError, urllib.error.URLError):
        raise CloudError('Bulut bağlantısı kurulamadı. İnternet bağlantısını kontrol et.', 503)


def _set_session(local_id, response, remember=None):
    session = {
        'token': response['access_token'],
        'refresh': response.get('refresh_token'),
        'expiry': time.time() + int(response.get('expires_in', 3600)),
        'cloud_id': str(response['user']['id']),
        'email': response['user'].get('email', ''),
    }
    with _LOCK: _SESSIONS[local_id] = session
    if remember is True:
        (DATA_DIR / ('cloud_email_'+str(local_id)+'.txt')).write_text(session.get('email',''),encoding='utf-8')
    elif remember is False:
        (DATA_DIR / ('cloud_email_'+str(local_id)+'.txt')).unlink(missing_ok=True)
    dpapi_delete(DATA_DIR / ('cloud_refresh_'+str(local_id)+'.bin'))
    return session


def _active_session(local_id):
    with _LOCK: s = _SESSIONS.get(local_id)
    if not s:
        raise CloudError('Bulut bağlantısı için panel içinden giriş yap.',401)
    if time.time() > s['expiry'] - 90:
        if not s.get('refresh'):
            with _LOCK: _SESSIONS.pop(local_id, None)
            raise CloudError('Bulut oturumu sona erdi. Yeniden giriş yap.',401)
        try:
            new = _http('/auth/v1/token?grant_type=refresh_token', 'POST', {'refresh_token':s['refresh']})
            new['user'] = new.get('user') or {'id':s['cloud_id'],'email':s['email']}
            s = _set_session(local_id, new)
        except CloudError:
            with _LOCK: _SESSIONS.pop(local_id, None)
            raise CloudError('Bulut oturumu sona erdi. Yeniden giriş yap.',401)
    return s


def _ensure_profile(s):
    profile = _http('/rest/v1/visionops_profiles?select=user_id,role,display_name&limit=1', jwt=s['token'])
    if not profile:
        _http('/rest/v1/visionops_profiles', 'POST', {
            'user_id':s['cloud_id'], 'role':'viewer', 'display_name':s['email'].split('@')[0][:80]
        }, jwt=s['token'], prefer='return=minimal')
        profile = _http('/rest/v1/visionops_profiles?select=user_id,role,display_name&limit=1', jwt=s['token'])
    return profile[0] if profile else {'role':'viewer'}


def _sync_batch(local_id, db_factory, device_id, data_dir, batch_size=80):
    """Idempotent, cursor-based upload; tokens never persisted and frames never uploaded."""
    s=_active_session(local_id)
    user=s['cloud_id']
    cursor_path=Path(data_dir)/('sync_cursor_'+user+'.json')
    try: cursor=int(json.loads(cursor_path.read_text(encoding='utf-8')).get(device_id,0)) if cursor_path.exists() else 0
    except (ValueError,TypeError,json.JSONDecodeError,OSError):cursor=0
    with db_factory() as conn:
        rows=conn.execute('SELECT id,ts,event_type,zone_name,track_id,detail FROM events WHERE id>? ORDER BY id ASC LIMIT ?', (cursor,batch_size)).fetchall()
    payload=[]
    for r in rows:
        rd=dict(r)
        try:
            dt=datetime.fromisoformat(rd['ts'])
            if dt.tzinfo is None:dt=dt.replace(tzinfo=timezone.utc)
            t=dt.astimezone(timezone.utc).isoformat()
        except (ValueError,TypeError):continue
        ident=str(uuid.uuid5(_NS,user+':'+device_id+':'+str(rd['id'])))
        payload.append({'id':ident,'user_id':user,'event_type':rd['event_type'][:80],
                        'observed_at':t,'details':{'zone':rd['zone_name'],'track_id':rd['track_id'],
                        'description':(rd['detail'] or '')[:180],'source':'VisionOps Desktop'}})
    if payload:
        _http('/rest/v1/visionops_events?on_conflict=id','POST',payload,jwt=s['token'],prefer='resolution=ignore-duplicates,return=minimal')
    if rows:
        last_id=rows[-1]['id']
        # Preserve cursors for all accounts if same PC is used by several people.
        try: all_cursors=json.loads(cursor_path.read_text(encoding='utf-8')) if cursor_path.exists() else {}
        except (ValueError,OSError):all_cursors={}
        all_cursors[device_id]=last_id
        tmp=cursor_path.with_suffix('.tmp');tmp.write_text(json.dumps(all_cursors),encoding='utf-8');tmp.replace(cursor_path)
    return {'uploaded':len(payload),'processed':len(rows),'more':len(rows)==batch_size}

def init_cloud(app, db, data_dir):
    device_path = Path(data_dir) / '.cloud_device_id'
    if not device_path.exists():
        try:
            with device_path.open('x',encoding='ascii') as f: f.write(str(uuid.uuid4()))
        except FileExistsError: pass
    device_id = device_path.read_text(encoding='ascii').strip()
    @app.errorhandler(CloudError)
    def cloud_error(exc): return jsonify({'error':str(exc)}), exc.status if 400 <= exc.status < 600 else 400

    @app.get('/api/cloud/status')
    def cloud_status():
        local_id = _local_key()
        try:
            s = _active_session(local_id)
            profile = _ensure_profile(s)
            return jsonify({'connected':True, 'email':s['email'], 'role':profile.get('role','viewer'), 'display_name':profile.get('display_name') or '', 'project':'VisionOps AI Studio', 'store':'Supabase · Frankfurt', 'video_uploaded':False})
        except CloudError as e:
            return jsonify({'connected':False, 'message':str(e), 'saved_email':(DATA_DIR / ('cloud_email_'+str(local_id)+'.txt')).read_text(encoding='utf-8') if (DATA_DIR / ('cloud_email_'+str(local_id)+'.txt')).exists() else '', 'project':'VisionOps AI Studio', 'store':'Supabase · Frankfurt'})

    @app.post('/api/cloud/signup')
    def cloud_signup():
        data = request.get_json(silent=True) or {}
        email = str(data.get('email','')).strip().lower()
        password = str(data.get('password',''))
        if len(email)>254 or '@' not in email or len(password)<10 or len(password)>128:
            raise CloudError('Geçerli e-posta ve en az 10 karakterli parola gir.',400)
        result = _http('/auth/v1/signup','POST',{'email':email,'password':password})
        # On hosted projects email confirmation is commonly enabled.
        if result.get('access_token') and result.get('user'):
            s = _set_session(_local_key(), result, bool(data.get('remember')))
            _ensure_profile(s)
            return jsonify({'ok':True,'connected':True, 'message':'Bulut hesabı oluşturuldu ve bağlandı.'})
        return jsonify({'ok':True, 'connected':False, 'message':'Kayıt isteği alındı. E-postana gelen onay bağlantısını doğrulayıp bu panelden giriş yap.'})

    @app.post('/api/cloud/login')
    def cloud_login():
        data = request.get_json(silent=True) or {}
        email = str(data.get('email','')).strip().lower()
        password = str(data.get('password',''))
        if not email or not password: raise CloudError('E-posta ve parola gerekli.',400)
        token = _http('/auth/v1/token?grant_type=password','POST',{'email':email,'password':password})
        s = _set_session(_local_key(), token, bool(data.get('remember')))
        try: profile = _ensure_profile(s)
        except CloudError:
            with _LOCK: _SESSIONS.pop(_local_key(), None)
            raise
        return jsonify({'ok':True,'connected':True,'email':s['email'],'role':profile['role']})

    @app.post('/api/cloud/profile')
    def cloud_profile_change():
        """Self-service Supabase profile/password update after re-authentication."""
        user=_active_session(_local_key())
        data=request.get_json(silent=True) or {}
        old_pw=str(data.get('current_password',''))
        display_name=data.get('display_name',None)
        new_pw=str(data.get('new_password',''))
        if not old_pw:
            raise CloudError('Mevcut bulut parolanız gerekli.',400)
        if display_name is not None and (not isinstance(display_name,str) or len(display_name.strip())>80):
            raise CloudError('Görünen ad en fazla 80 karakter olmalı.',400)
        if new_pw and not 12 <= len(new_pw) <= 128:
            raise CloudError('Yeni bulut parolası en az 12 karakter olmalı.',400)
        # Reauthenticate before accepting sensitive changes. Never store the supplied password.
        proof=_http('/auth/v1/token?grant_type=password','POST',{'email':user['email'],'password':old_pw})
        jwt=proof['access_token']
        if display_name is not None:
            _http('/rest/v1/visionops_profiles?user_id=eq.'+user['cloud_id'],'PATCH',
                 {'display_name':display_name.strip()},jwt=jwt,prefer='return=minimal')
        if new_pw:
            _http('/auth/v1/user','PUT',{'password':new_pw},jwt=jwt)
        with _LOCK: _SESSIONS.pop(_local_key(),None)
        dpapi_delete(DATA_DIR / ('cloud_refresh_'+str(_local_key())+'.bin'))
        return jsonify({'ok':True,'relogin_required':True,
                        'message':'Hesap güncellendi. Güvenliğiniz için bulut oturumu kapatıldı.'})

    @app.get('/api/cloud/modules')
    def cloud_modules():
        """Read-only, server-verified plan catalogue and current user's entitlements.

        The client never sends or controls licensing state. A publishable Supabase key
        is used; PostgreSQL RLS limits entitlement rows to auth.uid().
        """
        s = _active_session(_local_key())
        catalogue = _http('/rest/v1/visionops_modules?select=code,display_name,description,availability&order=code.asc', jwt=s['token']) or []
        grants = _http('/rest/v1/visionops_entitlements?select=module_code,status,access_type,expires_at', jwt=s['token']) or []
        now = datetime.now(timezone.utc)
        active = set()
        for gnt in grants:
            if gnt.get('status') != 'active':
                continue
            expiry = gnt.get('expires_at')
            try:
                if expiry and datetime.fromisoformat(expiry.replace('Z','+00:00')) <= now:
                    continue
            except (ValueError,TypeError):
                continue
            active.add(gnt.get('module_code'))
        return jsonify({'modules':[{**m, 'unlocked':m['code'] in active and m['availability']=='available'} for m in catalogue], 'account':s['email']})

    @app.post('/api/cloud/logout')
    def cloud_logout():
        with _LOCK: s = _SESSIONS.pop(_local_key(), None)
        dpapi_delete(DATA_DIR / ('cloud_refresh_'+str(_local_key())+'.bin'))
        session.pop('active_module',None)
        session.pop('cloud_owner',None)
        session.pop('license_verified_at',None)
        if s:
            try: _http('/auth/v1/logout','POST',{},jwt=s['token'])
            except CloudError: pass
        return jsonify({'ok':True})

    @app.get('/api/cloud/events')
    def cloud_events():
        s = _active_session(_local_key())
        rows = _http('/rest/v1/visionops_events?select=id,event_type,observed_at,details,confidence&order=observed_at.desc&limit=100',jwt=s['token'])
        return jsonify({'events':rows or [],'user':s['email']})

    @app.post('/api/cloud/sync')
    def cloud_sync():
        if _PET_OWNER not in (None, 'local-admin'):
            raise CloudError('Bu çalışma alanında bulut aktarımı kapalı.', 403)
        result=_sync_batch(_local_key(),db,device_id,data_dir)
        return jsonify({'ok':True,**result,'message':f"{result['uploaded']} olay aktarıldı." + (' Kalan kayıtlar sonraki aktarımda gönderilir.' if result['more'] else ' Tüm kayıtlar güncel.')})

    @app.get('/api/cloud/auto-sync')
    def cloud_auto_status():
        return jsonify({'enabled':_cloud_auto_on(),'last_result':_auto_status['message']})

    @app.post('/api/cloud/auto-sync')
    def cloud_auto_set():
        if _PET_OWNER not in (None, 'local-admin'):
            raise CloudError('Bu çalışma alanında bulut aktarımı kapalı.', 403)
        enabled=bool((request.get_json(silent=True) or {}).get('enabled'))
        with db() as conn:
            conn.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('cloud_auto_sync',?)",('on' if enabled else 'off',))
        return jsonify({'ok':True,'enabled':enabled})

    _auto_status={'message':'Henüz çalışmadı'}
    def _cloud_auto_on():
        try:
            with db() as conn:
                row=conn.execute("SELECT value FROM settings WHERE key='cloud_auto_sync'").fetchone()
            return bool(row and row['value']=='on')
        except sqlite3.Error:return False

    def _auto_loop():
        while True:
            time.sleep(60)
            if _PET_OWNER not in (None, 'local-admin') or not _cloud_auto_on():continue
            with _LOCK: active=list(_SESSIONS.keys())
            for local_id in active:
                try:
                    result=_sync_batch(local_id,db,device_id,data_dir)
                    _auto_status['message']=f"Son aktarım: {result['uploaded']} kayıt"
                except Exception as exc:
                    _auto_status['message']='Bağlantı bekleniyor: '+str(exc)[:110]
    threading.Thread(target=_auto_loop,daemon=True,name='visionops-cloud-sync').start()


init_cloud(app, lambda: db(), DATA_DIR)


state = {
    "camera": None, "running": False, "camera_ready": False, "frame": None, "lock": threading.Lock(),
    "thread": None, "source": 0, "error": None, "model_status": "Henüz yüklenmedi",
    "detector": None, "last_detections": [], "last_people": [], "tracks": {}, "next_track": 1000000,
    "object_model": None, "object_model_status": "Kapalı", "objects": [], "objects_lock": threading.Lock(), "object_busy": False,
    "object_last_scan": 0, "object_seen": {}, "interaction_seen": {}, "last_detect_at": 0,
    "zone_states": {}, "last_event": 0, "fps": 0.0, "frame_count": 0
}

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT NOT NULL, event_type TEXT NOT NULL, zone_name TEXT,
            track_id INTEGER, detail TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS zones(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
            zone_type TEXT NOT NULL, x REAL NOT NULL, y REAL NOT NULL,
            w REAL NOT NULL, h REAL NOT NULL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT)""")
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('camera_source','0')")
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('confidence','0.35')")

def log_event(event_type, zone=None, track_id=None, detail=""):
    now = datetime.now().astimezone().isoformat(timespec="seconds")
    with db() as c:
        c.execute("INSERT INTO events(ts,event_type,zone_name,track_id,detail) VALUES(?,?,?,?,?)",
                  (now, event_type, zone, track_id, detail))

def load_zones():
    with db() as c:
        return [dict(r) for r in c.execute("SELECT * FROM zones ORDER BY id").fetchall()]

def load_detector():
    try:
        from ultralytics import YOLO
        model_path = APP_DIR / "yolov8n.pt"
        state["detector"] = YOLO(str(model_path) if model_path.exists() else "yolov8n.pt")
        state["model_status"] = "YOLOv8n hazır"
        return True
    except Exception as e:
        state["model_status"] = "Model yüklenemedi: " + str(e)[:160]
        state["error"] = state["model_status"]
        return False

def detect_cats(frame):
    model = state["detector"]
    if model is None:
        return []
    try:
        # Persisted ByteTrack IDs handle occlusion and crossing paths better than centroid-only association.
        results = model.track(frame, persist=True, tracker="bytetrack.yaml", conf=float(get_setting("confidence", "0.35")),
                              classes=[0,15], verbose=False, imgsz=640)
        detections, people = [], []
        for r in results:
            if r.boxes is None: continue
            for b in r.boxes:
                x1,y1,x2,y2 = [int(v) for v in b.xyxy[0].tolist()]
                conf = float(b.conf[0]); cls = int(b.cls[0])
                tid = int(b.id[0]) if b.id is not None else None
                item={"x":x1,"y":y1,"w":x2-x1,"h":y2-y1,"cx":(x1+x2)//2,"cy":(y1+y2)//2,"conf":conf,"track_id":tid}
                (people if cls==0 else detections).append(item)
        state["last_people"] = people
        return detections
    except Exception as e:
        state["error"] = "Algılama hatası: " + str(e)[:120]
        return []

def get_setting(key, default=None):
    with db() as c:
        row = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default

def assign_tracks(detections):
    """Use ByteTrack IDs where supplied, retaining a centroid fallback if tracker IDs are unavailable."""
    tracks=state['tracks']; now=time.monotonic(); used=set()
    for d in detections:
        tid=d.get('track_id')
        if tid is None:
            best=None; cost=float('inf')
            for k,t in tracks.items():
                if k in used: continue
                dt=min(1.0,now-t['seen'])
                px=t['cx']+t.get('vx',0)*dt; py=t['cy']+t.get('vy',0)*dt
                delta=((d['cx']-px)**2+(d['cy']-py)**2)**.5
                if delta<cost: best,cost=k,delta
            tid=best if best is not None and cost<max(100,d['w']*.8) else state['next_track']
            if tid==state['next_track']: state['next_track']+=1
        d['track_id']=tid
        if tid not in tracks:
            tracks[tid]={'zones':set(),'cx':d['cx'],'cy':d['cy'],'seen':now,'vx':0,'vy':0}
            log_event('cat_detected',None,tid,'Yeni kedi izi algılandı')
        else:
            tr=tracks[tid];dt=max(.05,now-tr['seen'])
            tr['vx']=.5*tr.get('vx',0)+.5*(d['cx']-tr['cx'])/dt
            tr['vy']=.5*tr.get('vy',0)+.5*(d['cy']-tr['cy'])/dt
        tracks[tid].update(cx=d['cx'],cy=d['cy'],seen=now)
        used.add(tid)
    for tid in list(tracks):
        if now-tracks[tid]['seen']>5:
            del tracks[tid]
            log_event('cat_lost_view',None,tid,'İz kayboldu; odadan çıkış anlamına gelmez')
    return detections


def process_zones(detections, zones):
    # Compare the current set of occupied zones with the previous frame's set.
    # Enter/exit events are emitted once per transition, not once per zone loop.
    for d in detections:
        tid = d["track_id"]
        tr = state["tracks"].get(tid)
        if tr is None:
            continue
        current = set()
        fw, fh = state.get("frame_size", (640, 480))
        for z in zones:
            x, y = z["x"] * fw, z["y"] * fh
            w, h = z["w"] * fw, z["h"] * fh
            if x <= d["cx"] <= x + w and y <= d["cy"] <= y + h:
                current.add(z["id"])
        previous = set(tr.get("zones", set()))
        zone_by_id = {z["id"]: z for z in zones}
        for zid in current - previous:
            z = zone_by_id.get(zid)
            if z:
                log_event("zone_enter", z["name"], tid, z["zone_type"])
        for zid in previous - current:
            z = zone_by_id.get(zid)
            if z:
                log_event("zone_exit", z["name"], tid, z["zone_type"])
        tr["zones"] = current

def list_cameras():
    """Enumerate DirectShow friendly names without opening camera streams."""
    try:
        from pygrabber.dshow_graph import FilterGraph
        names = FilterGraph().get_input_devices()
        return [{"id": i, "name": name, "preferred": "obs" in name.lower()} for i, name in enumerate(names)]
    except Exception as exc:
        state["device_error"] = str(exc)[:180]
        return []


def open_camera(source):
    """Open ONLY the selected camera. Prefer OBS, never silently select Fujifilm's warning slate."""
    devices = list_cameras()
    if str(source).lower() in ("obs", "auto"):
        obs = [d for d in devices if "obs" in d["name"].lower()]
        if not obs:
            return None, None, None, ("OBS Virtual Camera aygiti bulunamadi. OBS icinde "
                "Sanal Kamerayi Baslat'a basin. Aygitlar: " + ", ".join(d["name"] for d in devices))
        indices = [d["id"] for d in obs]
    else:
        try: indices = [int(source)]
        except (ValueError, TypeError): return None, None, None, "Gecersiz kamera secimi"
    errors = []
    for index in indices:
        # DirectShow index corresponds to pygrabber device order.
        for backend_name, backend in (("DirectShow", cv2.CAP_DSHOW), ("MediaFoundation", cv2.CAP_MSMF)):
            cap = None
            success = False
            try:
                cap = cv2.VideoCapture(index, backend)
                if not cap.isOpened():
                    errors.append(f"{index}/{backend_name}: acilamadi")
                    continue
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
                for attempt in range(18):
                    ok, frame = cap.read()
                    if ok and frame is not None and frame.size and float(frame.mean()) > 2:
                        success = True
                        return cap, frame, index, backend_name
                    time.sleep(.10)
                errors.append(f"{index}/{backend_name}: goruntu yok")
            except Exception as exc:
                errors.append(f"{index}/{backend_name}: {str(exc)[:80]}")
            finally:
                if cap is not None:
                    if not success:
                        cap.release()
    return None, None, None, "; ".join(errors[-6:])

# ---- VisionOps v0.6: privacy and experimental movable-object detector ----
_FACE_CASCADE=None
_FACE_LOCK=threading.Lock()
OBJECT_LABELS=['cat food bowl','pet water bowl','cat litter box','doorway entrance']
OBJECT_NAMES=['Mama kabı','Su kabı','Kum kabı','Kapı girişi']

def redact_faces(frame, people):
    """Best-effort anonymization of faces and upper-body fallback; not a privacy guarantee."""
    global _FACE_CASCADE
    try:
        if _FACE_CASCADE is None:
            with _FACE_LOCK:
                if _FACE_CASCADE is None:
                    detector=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
                    _FACE_CASCADE=detector if not detector.empty() else False
        h,w=frame.shape[:2]
        if _FACE_CASCADE is not False:
            small=cv2.resize(frame,(max(1,w//2),max(1,h//2)))
            gray=cv2.cvtColor(small,cv2.COLOR_BGR2GRAY)
            with _FACE_LOCK:
                faces = _FACE_CASCADE.detectMultiScale(gray,scaleFactor=1.15,minNeighbors=4,minSize=(18,18))
            for x,y,ww,hh in faces:
                x0=max(0,2*x-12);y0=max(0,2*y-12);x1=min(w,2*(x+ww)+12);y1=min(h,2*(y+hh)+12)
                roi=frame[y0:y1,x0:x1]
                if roi.size:frame[y0:y1,x0:x1]=cv2.GaussianBlur(roi,(61,61),25)
        if _FACE_CASCADE is False and not people:
            # Face detector unavailable: avoid emitting raw frames.
            return cv2.GaussianBlur(frame,(91,91),40)
        # Extra precaution: obscure person head region even when frontal face is missed.
        for d in people:
            x=max(0,d['x']);y=max(0,d['y']);xx=min(w,d['x']+d['w']);yy=min(h,d['y']+int(d['h']*.43))
            roi=frame[y:yy,x:xx]
            if roi.size:frame[y:yy,x:xx]=cv2.GaussianBlur(roi,(71,71),31)
    except Exception as exc:
        # Conservative fallback: never publish a potentially unblurred face if processing fails.
        state['privacy_error']=str(exc)[:120] if 'state' in globals() else str(exc)[:120]
        return cv2.GaussianBlur(frame,(91,91),40)
    return frame


def _object_worker(snapshot):
    try:
        if state['object_model'] is None:
            state['object_model_status']='Model yükleniyor (ilk kullanımda internet gerekir)'
            from ultralytics import YOLOWorld
            model=YOLOWorld('yolov8s-worldv2.pt')
            model.set_classes(OBJECT_LABELS)
            state['object_model']=model
        result=state['object_model'].predict(snapshot,conf=.42,verbose=False,imgsz=640)
        found=[]
        for r in result:
            for b in (r.boxes if r.boxes is not None else []):
                label_id=int(b.cls[0]);conf=float(b.conf[0]);
                if not 0<=label_id<len(OBJECT_NAMES):continue
                x1,y1,x2,y2=map(int,b.xyxy[0].tolist())
                if x2<=x1 or y2<=y1:continue
                found.append({'label':OBJECT_NAMES[label_id], 'kind':label_id,'box':(x1,y1,x2-x1,y2-y1),'conf':conf,'seen':time.monotonic()})
        with state['objects_lock']:
            state['objects']=found
        state['object_model_status']='Deneysel nesne algılama aktif'
    except Exception as exc:
        state['object_model_status']='Nesne modeli yüklenemedi: '+str(exc)[:110]
        state['object_model']=None
        # Do not retry downloads endlessly in the camera thread.
        state['object_retry_after']=time.monotonic()+120
    finally:
        state['object_busy']=False


def maybe_scan_objects(frame):
    now=time.monotonic()
    if state['object_busy'] or now-state['object_last_scan']<3 or now<state.get('object_retry_after',0):return
    state['object_last_scan']=now
    state['object_busy']=True
    threading.Thread(target=_object_worker,args=(frame.copy(),),daemon=True).start()


def current_objects():
    if get_setting('object_detection','off')!='on':return []
    with state['objects_lock']:
        return [dict(o) for o in state['objects'] if time.monotonic()-o['seen']<8]


def mark_object_interactions(cats,people):
    if people:return
    now=time.monotonic()
    for obj in current_objects():
        x,y,w,h=obj['box']
        for d in cats:
            cx,cy=d['cx'],d['cy'];margin=max(35,int(max(w,h)*.55))
            if x-margin<=cx<=x+w+margin and y-margin<=cy<=y+h+margin:
                key=f"{d['track_id']}:{obj['kind']}"
                record=state['interaction_seen'].setdefault(key,{'first':now,'logged':0,'last':now})
                if now-record['last']>2:record['first']=now
                record['last']=now
                if now-record['first']>=2 and now-record['logged']>90:
                    log_event('cat_near_object',obj['label'],d['track_id'],'Yakınlık algılandı; gerçek kullanım doğrulanmadı')
                    record['logged']=now
    state['interaction_seen']={k:v for k,v in state['interaction_seen'].items() if now-v['last']<15}

@app.get('/api/ai/status')
def ai_status():
    return jsonify({'faces':'Best effort; guaranteed anonymization değildir',
                   'object_detection':get_setting('object_detection','off'),
                   'object_model':state['object_model_status'],
                   'objects':[{'name':o['label'],'confidence':round(o['conf'],2)} for o in current_objects()],
                   'cat_tracking':'YOLO ByteTrack'})

@app.post('/api/ai/object-detection')
def ai_toggle():
    d=request.get_json(silent=True) or {}
    enabled=bool(d.get('enabled'))
    with db() as conn:
        conn.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('object_detection',?)",('on' if enabled else 'off',))
    if not enabled:
        with state['objects_lock']:state['objects']=[]
        state['object_model_status']='Kapalı'
    return jsonify({'ok':True,'enabled':enabled,'message':'Deneysel nesne modeli '+('etkinleştirildi' if enabled else 'kapatıldı')})

def camera_loop():
    cap = None
    try:
        cap, first_frame, index, backend = open_camera(state["source"])
        if cap is None:
            state["error"] = ("Kamera goruntusu alinamadi. OBS'de Fujifilm goruntusunu ac, "
                "Sanal Kamerayi Baslat'a bas, VisionOps'ta Otomatik veya kamera indeksini sec. "
                "Ayrinti: " + str(backend))[:500]
            return
        state["active_camera"] = f"{index} / {backend}"
        state["camera_ready"] = True
        state["source"] = index
        state["error"] = None
        # Never publish an unredacted initial camera frame.
        with state["lock"]:
            state["frame"] = redact_faces(first_frame.copy(), [])
        load_detector()
        last = time.time()
        failed = 0
        while state["running"]:
            ok, frame = cap.read()
            if not ok or frame is None:
                failed += 1
                if failed >= 30:
                    state["error"] = "Kamera goruntusu kesildi. OBS Sanal Kamera'yi kontrol et."
                    break
                time.sleep(.1)
                continue
            failed = 0
            h,w=frame.shape[:2]
            state["frame_size"]=(w,h)
            state["frame_count"] += 1
            # Keep tracking on every processed frame (hardware-dependent detection cadence).
            if state["detector"] is not None:
                dets=assign_tracks(detect_cats(frame))
                state['last_detections']=dets
                state['last_detect_at']=time.monotonic()
                if not state['last_people'] and get_setting('object_detection','off')!='on':
                    # Manual zones are excluded while automatic object recognition is active.
                    process_zones(dets, load_zones())
            else:
                state['last_detections']=[];state['last_people']=[]
            now_mono=time.monotonic()
            # Privacy mask applied BEFORE any camera output is published.
            frame=redact_faces(frame,state['last_people'])
            if get_setting('object_detection','off')=='on':
                maybe_scan_objects(frame)
                mark_object_interactions(state['last_detections'],state['last_people'])
            for obj in current_objects():
                x,y,ww,hh=obj['box'];col=(220,200,60)
                cv2.rectangle(frame,(x,y),(x+ww,y+hh),col,2)
                cv2.putText(frame,f"{obj['label']} (tahmini {obj['conf']:.0%})",(x,max(20,y-8)),cv2.FONT_HERSHEY_SIMPLEX,.48,col,2)
            for d in state['last_detections']:
                x,y,ww,hh=d['x'],d['y'],d['w'],d['h']
                cv2.rectangle(frame,(x,y),(x+ww,y+hh),(80,230,150),2)
                cv2.putText(frame,f"Kedi #{d['track_id']} {d['conf']:.0%}",(x,max(20,y-8)),cv2.FONT_HERSHEY_SIMPLEX,.55,(80,230,150),2)
            state["fps"]=1/max(.001,time.time()-last); last=time.time()
            with state["lock"]:
                state["frame"]=frame.copy()
            time.sleep(.01)
    except Exception as e:
        state["error"] = "Kamera isleme hatasi: " + str(e)[:300]
    finally:
        if cap is not None: cap.release()
        state["running"] = False
        state["camera_ready"] = False

def mjpeg():
    while True:
        with state["lock"]:
            frame = None if state["frame"] is None else state["frame"].copy()
        if frame is None:
            # Placeholder frame
            img = __import__("numpy").zeros((360,640,3),dtype="uint8")
            cv2.putText(img,"VisionOps AI - Kamera bekleniyor",(30,180),cv2.FONT_HERSHEY_SIMPLEX,.8,(180,210,220),2)
        else: img=frame
        ok,buf=cv2.imencode(".jpg",img,[int(cv2.IMWRITE_JPEG_QUALITY),80])
        if ok:
            yield (b"--frame\r\nContent-Type: image/jpeg\r\n\r\n"+buf.tobytes()+b"\r\n")
        time.sleep(.08)

# v0.9: admin studio is restricted by the local account role.
BRAND_FIELDS={
 'site_hero_title','site_hero_accent','site_hero_subtitle','site_accent','site_bg',
 'pet_accent','cafe_accent','farm_accent'
}
COLOR_FIELDS={'site_accent','site_bg','pet_accent','cafe_accent','farm_accent'}

def _admin_role():
    return bool(getattr(g, 'current_user', None) and g.current_user.get('role')=='admin')

@app.get('/api/admin/cloud-accounts')
def admin_cloud_accounts():
    """Cloud admin account list requires BOTH local admin and Supabase admin token."""
    if not _admin_role():return jsonify({'error':'Yönetici yetkisi gerekiyor.'}),403
    try:
        session_data=_active_session(_local_key())
        profile=_ensure_profile(session_data)
        if profile.get('role')!='admin':
            return jsonify({'error':'Bulut yöneticisi yetkisi gerekiyor.'}),403
        rows=_http('/rest/v1/rpc/visionops_admin_account_overview', 'POST', {}, jwt=session_data['token']) or []
        return jsonify({'accounts':rows})
    except CloudError as exc:
        return jsonify({'error':str(exc)}),exc.status if 400<=exc.status<600 else 400

@app.get('/admin')
def admin_page():
    if not _admin_role():return redirect('/choose')
    return render_template('choose.html',admin=True,csrf=session.get('csrf',''),username=g.current_user['username'])

# Editable local visual components; never permit arbitrary HTML or scripts.
PANEL_COMPONENTS = {'heading', 'text', 'metric', 'button'}
PANEL_DEFAULTS = {'accent': '#52644b', 'background': '#f0ebdf', 'heading': 'VisionOps Pet'}
PANEL_EDIT_STYLES = {'color','backgroundColor','fontSize','padding','borderRadius','textAlign'}

def _panel_settings():
    source=DATA_DIR/'panel_design.json'
    try: content=json.loads(source.read_text(encoding='utf-8'))
    except (OSError,ValueError): content={}
    settings={k:v for k,v in (content.get('settings') or {}).items() if k in PANEL_DEFAULTS and isinstance(v,str)}
    for k,v in PANEL_DEFAULTS.items(): settings.setdefault(k,v)
    widgets=[]
    for w in (content.get('widgets') or [])[:18]:
        if not isinstance(w,dict):continue
        kind=w.get('kind')
        label=w.get('label')
        if kind in PANEL_COMPONENTS and isinstance(label,str) and len(label)<=150:
            widgets.append({'kind':kind,'label':label})
    edits=[]
    for item in (content.get('edits') or [])[:180]:
        if isinstance(item,dict) and __import__('re').fullmatch(r'app_\d+_\d+',str(item.get('target',''))):
            edits.append({'target':item['target'], 'text':item.get('text'),
               'styles':{k:v for k,v in (item.get('styles') or {}).items()
                       if k in PANEL_EDIT_STYLES and isinstance(v,str) and len(v)<=40}})
    return {'settings':settings,'widgets':widgets,'edits':edits}

@app.get('/api/admin/panel-layout')
def admin_panel_layout_get():
    if not _admin_role():return jsonify({'error':'Yönetici erişimi gerekiyor.'}),403
    return jsonify(_panel_settings())

@app.post('/api/admin/panel-layout')
def admin_panel_layout_set():
    if not _admin_role():return jsonify({'error':'Yönetici erişimi gerekiyor.'}),403
    data=request.get_json(silent=True) or {}
    st=data.get('settings') or {}
    widgets=data.get('widgets') or []
    edits=data.get('edits') or []
    if not isinstance(st,dict) or not isinstance(widgets,list) or len(widgets)>18:
        return jsonify({'error':'Geçersiz düzen.'}),400
    for k,v in st.items():
        if k not in PANEL_DEFAULTS or not isinstance(v,str):return jsonify({'error':'Geçersiz alan.'}),400
        if k!='heading' and not __import__('re').fullmatch(r'#[0-9a-fA-F]{6}',v):return jsonify({'error':'Geçersiz renk.'}),400
        if k=='heading' and not 1<=len(v)<=100:return jsonify({'error':'Başlık çok uzun.'}),400
    for w in widgets:
        if not isinstance(w,dict) or w.get('kind') not in PANEL_COMPONENTS or not isinstance(w.get('label'),str) or len(w['label'])>150:
            return jsonify({'error':'Geçersiz bileşen.'}),400
    if not isinstance(edits,list) or len(edits)>180:
        return jsonify({'error':'Çok fazla öğe düzenlemesi.'}),400
    clean_edits=[]
    for e in edits:
        if not isinstance(e,dict) or not __import__('re').fullmatch(r'app_\d+_\d+',str(e.get('target',''))):
            return jsonify({'error':'Geçersiz öğe kimliği.'}),400
        text=e.get('text')
        if text is not None and (not isinstance(text,str) or len(text)>400):
            return jsonify({'error':'Metin çok uzun.'}),400
        styles=e.get('styles') or {}
        if not isinstance(styles,dict) or len(styles)>len(PANEL_EDIT_STYLES):
            return jsonify({'error':'Geçersiz öğe biçimi.'}),400
        for k,v in styles.items():
            if k not in PANEL_EDIT_STYLES or not isinstance(v,str) or len(v)>40:
                return jsonify({'error':'Geçersiz biçimlendirme.'}),400
            if k in ('color','backgroundColor') and not __import__('re').fullmatch(r'#[0-9a-fA-F]{6}',v):
                return jsonify({'error':'Renk biçimi geçersiz.'}),400
            if k in ('fontSize','padding','borderRadius') and not __import__('re').fullmatch(r'\d{1,2}px',v):
                return jsonify({'error':'Ölçü biçimi geçersiz.'}),400
            if k=='textAlign' and v not in ('left','center','right'):
                return jsonify({'error':'Hizalama geçersiz.'}),400
        clean_edits.append({'target':e['target'],'text':text,'styles':styles})
    clean={'settings':{**PANEL_DEFAULTS,**st},'widgets':[{'kind':w['kind'],'label':w['label']} for w in widgets], 'edits':clean_edits}
    path=DATA_DIR/'panel_design.json';tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(clean,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(path)
    return jsonify({'ok':True})

def _render_pet_preview(preview=False):
    content=render_template('index.html', universal_wall=not preview and _admin_role())
    if preview:content=content.replace('<script src="/static/dashboard.js"></script>','')
    data=json.dumps(_panel_settings(),ensure_ascii=False).replace('<','\\u003c')
    script="""<script>(function(){
    const data=DATA_PLACEHOLDER, settings=data.settings;
    const style=document.createElement('style');
    style.textContent=':root{--visionops-custom-accent:'+settings.accent+'} .visionops-custom-title{color:'+settings.accent+'}';
    document.head.appendChild(style);
    const target=document.querySelector('.main-content')||document.querySelector('main')||document.body;
    const holder=document.createElement('section');holder.className='visionops-custom-widgets';
    holder.style.cssText='display:flex;flex-wrap:wrap;gap:12px;margin:15px 0 22px;';
    for(const w of data.widgets){const box=document.createElement('div');box.style.cssText='padding:16px;border-radius:12px;border:1px solid #28616a;background:'+settings.background+';color:#302b24;min-width:160px;flex:1';
    const el=document.createElement(w.kind==='heading'?'h2':w.kind==='button'?'strong':'p');el.textContent=w.label;el.style.margin='0';box.append(el);holder.append(box);}
    if(holder.childNodes.length)target.prepend(holder);
    const h=document.querySelector('h1');if(h)h.textContent=settings.heading;
    })();</script>""".replace('DATA_PLACEHOLDER',data)
    overlay_script = """<script>(function(){
      const selectors=[
       '.nav button','.page .eyebrow','.page h1','.page .page-title p',
       '.page .panel','.page .panel h2','.page .panel p',
       '.page .kpi','.page .kpi-label','.page .kpi-value',
       '.page .info-strip','.page .btn','.side-bottom .scenario',
       '.side-bottom .userbox','.page .badge',
       '.visionops-custom-widgets article','.visionops-custom-widgets p',
       '.visionops-custom-widgets h2'
      ];
      const targets=new Map();
      selectors.forEach((s,i)=>document.querySelectorAll(s).forEach((node,j)=>{
        const key='app_'+i+'_'+j;node.dataset.voTarget=key;targets.set(key,node);
      }));
      window.__visionopsPanelTargets=targets;
      for(const edit of SETTINGS.edits||[]){
        const node=targets.get(edit.target);if(!node)continue;
        if(typeof edit.text==='string'&&node.children.length===0)node.textContent=edit.text;
        for(const [prop,val] of Object.entries(edit.styles||{})){
          if(['color','backgroundColor','fontSize','padding','borderRadius','textAlign'].includes(prop))node.style[prop]=val;
        }
      }
      if(location.pathname==='/admin/preview'){
         document.querySelectorAll('.nav button[data-page]').forEach(button=>button.addEventListener('click',()=>{
           const page=button.dataset.page;
           document.querySelectorAll('.page').forEach(node=>node.classList.toggle('active',node.id==='page-'+page));
         }));
      }
    })();</script>""".replace('SETTINGS',data)
    if preview: script=script.replace('if(holder.childNodes.length)target.prepend(holder);','target.prepend(holder);')
    return content.replace('</body>',script+overlay_script+'</body>')

@app.get('/admin/preview')
def admin_preview():
    if not _admin_role():return 'Yönetici erişimi gerekiyor',403
    # Preview-only: strip scripts and never initialize camera or stream.
    from markupsafe import Markup
    return _render_pet_preview(preview=True)

@app.get('/api/admin/brand')
def admin_brand_read():
    if not _admin_role():return jsonify({'error':'Yönetici erişimi gerekiyor.'}),403
    try:
        data=_http('/rest/v1/visionops_brand_settings?select=setting_key,setting_value') or []
        return jsonify({'settings':{i['setting_key']:i['setting_value'] for i in data}})
    except CloudError as exc:return jsonify({'error':str(exc)}),exc.status

@app.post('/api/admin/brand')
def admin_brand_write():
    if not _admin_role():return jsonify({'error':'Yönetici erişimi gerekiyor.'}),403
    obj=request.get_json(silent=True) or {}
    values=obj.get('settings')
    if not isinstance(values,dict) or not values or len(values)>len(BRAND_FIELDS):
        return jsonify({'error':'Geçersiz ayar listesi.'}),400
    for key,value in values.items():
        if key not in BRAND_FIELDS or not isinstance(value,str) or not 1<=len(value)<=280:
            return jsonify({'error':'Geçersiz anahtar veya değer.'}),400
        if key in COLOR_FIELDS and not __import__('re').fullmatch(r'#[0-9a-fA-F]{6}',value):
            return jsonify({'error':'Renkler #RRGGBB biçiminde olmalı.'}),400
    try:
        cloud=_active_session(_local_key())
        role=_ensure_profile(cloud).get('role')
        if role!='admin':return jsonify({'error':'Supabase bulut hesabının yönetici yetkisi yok.'}),403
        for key,value in values.items():
            _http('/rest/v1/visionops_brand_settings?setting_key=eq.'+key,'PATCH',
                  {'setting_value':value},jwt=cloud['token'],prefer='return=minimal')
        return jsonify({'ok':True})
    except CloudError as exc:return jsonify({'error':str(exc)}),exc.status

MODULES = ('pet', 'cafe', 'farm')
_PET_OWNER = None


def _clear_desktop_session():
    if session.get('active_module') in ('cafe', 'farm'):
        _operations['stop'].set()
        _close_ip_cameras(session['active_module'])
    key = session.get('customer_key') or session.get('user_id')
    with _LOCK:
        _SESSIONS.pop(key, None)
    if session.get('active_module') == 'pet':
        state['running'] = False
        _close_ip_cameras('pet')


app.config['VISIONOPS_CLEAR_SESSION'] = _clear_desktop_session


def _bind_pet(owner):
    # The existing camera workers share one data store and in-memory camera state.
    global _PET_OWNER, DB_PATH
    with _LOCK:
        if _PET_OWNER is not None and _PET_OWNER != owner:
            raise CloudError('Pet hesabını değiştirmek için uygulamayı kapatıp yeniden aç.', 409)
        if _PET_OWNER is None:
            original = DB_PATH
            if owner != 'local-admin':
                DB_PATH = DATA_DIR / ('pet_' + str(uuid.UUID(owner)) + '.db')
            try:
                init_db()
            except sqlite3.Error:
                DB_PATH = original
                raise CloudError('Pet çalışma alanı veritabanı açılamadı.', 500)
            _PET_OWNER = owner


@app.get('/choose')
def choose_workspace():
    return render_template('choose.html', logged_in=session.get('role') == 'admin',
                           csrf=session.setdefault('csrf', secrets.token_hex(24)))


@app.get('/workspace/leave')
def leave_workspace():
    if session.get('active_module') in ('cafe', 'farm'):
        _operations['stop'].set()
        _close_ip_cameras(session['active_module'])
    if session.get('active_module') == 'pet':
        state['running'] = False
        _close_ip_cameras('pet')
    session.pop('active_module', None)
    return redirect('/choose')


@app.get('/activate/<module>')
def activate_workspace(module):
    if module not in MODULES:
        return redirect('/choose')
    return render_template('activate.html', module=module,
                           csrf=session.setdefault('csrf', secrets.token_hex(24)),
                           signed_in=bool(session.get('user_id') or session.get('customer_key')))


def _open_workspace(module, owner):
    if session.get('active_module') in ('cafe', 'farm') and session['active_module'] != module:
        _operations['stop'].set()
        _close_ip_cameras(session['active_module'])
    if module == 'pet':
        _bind_pet(owner)
    elif session.get('active_module') == 'pet':
        state['running'] = False
        _close_ip_cameras('pet')
    session['active_module'] = module
    return jsonify({'ok':True, 'url':'/' if module == 'pet' else '/workspace/' + module})


@app.post('/api/workspace/customer-login')
def customer_workspace_login():
    if session.get('user_id'):
        raise CloudError('Önce yönetici oturumunu kapat.', 403)
    form = request.get_json(silent=True) or {}
    module = form.get('module')
    email = str(form.get('email', '')).strip().lower()
    password = str(form.get('password', ''))
    if module not in MODULES or not email or not password:
        raise CloudError('Geçerli bir çalışma alanı, e-posta ve parola gerekli.', 400)
    if module != 'pet':
        raise CloudError('Bu çalışma alanı şu anda yönetici testine açık.', 403)
    token = _http('/auth/v1/token?grant_type=password', 'POST', {'email':email, 'password':password})
    cloud = {'cloud_id':str(token['user']['id']), 'token':token['access_token']}
    if not _workspace_allowed(module, cloud):
        raise CloudError('Bu panel için onaylı ve etkin paket bulunamadı. Yönetici hesabın varsa açılış ekranından Yönetici Girişi’ni kullan.', 403)
    _bind_pet(cloud['cloud_id'])
    _clear_desktop_session()
    key = 'customer-' + secrets.token_hex(24)
    _set_session(key, token)
    session.clear()
    session.update(customer_key=key, customer_email=email, role='viewer', csrf=secrets.token_hex(24),
                   license_verified_at=time.time())
    return _open_workspace(module, cloud['cloud_id'])


@app.post('/api/workspace/select')
def select_workspace():
    form = request.get_json(silent=True) or {}
    module = form.get('module')
    if module not in MODULES:
        raise CloudError('Bilinmeyen çalışma alanı.', 400)
    if _admin_role():
        return _open_workspace(module, 'local-admin')
    if not session.get('customer_key') or module != 'pet':
        raise CloudError('Bu çalışma alanına giriş yetkin yok.', 403)
    cloud = _active_session(_local_key())
    if not _workspace_allowed(module, cloud):
        raise CloudError('Bu panel için onaylı ve etkin paket bulunamadı.', 403)
    return _open_workspace(module, cloud['cloud_id'])


PACKAGE_MODULE = {'baslangic': 'pet', 'isletme': 'cafe', 'kurumsal': 'farm'}


def _workspace_allowed(module, cloud):
    profile = _http(
        '/rest/v1/visionops_profiles?select=role&user_id=eq.' + cloud['cloud_id'],
        jwt=cloud['token'],
    ) or []
    role = profile[0]['role'] if profile else None
    if role != 'viewer':
        return False
    return any(PACKAGE_MODULE.get(order['package_id']) == module for order in _approved_orders(cloud))


def _approved_orders(cloud):
    return _http(
        '/rest/v1/visionops_order_requests?select=package_id,starts_at,ends_at'
        '&status=eq.approved&starts_at=lte.now&or=(ends_at.is.null,ends_at.gt.now)'
        '&user_id=eq.' + cloud['cloud_id'],
        jwt=cloud['token'],
    ) or []


# COCO classes for person, horse, sheep and cow.
OPERATIONS_CLASSES = {'cafe': [0], 'farm': [17, 18, 19]}
OPERATIONS_LABELS = {0: 'Kişi', 17: 'At', 18: 'Koyun', 19: 'İnek'}
_operations = {'stop': threading.Event(), 'thread': None, 'module': None, 'counts': None, 'error': None}


def _operations_counts(results, module):
    totals = {OPERATIONS_LABELS[item]: 0 for item in OPERATIONS_CLASSES[module]}
    for result in results:
        if result.boxes is not None:
            for box in result.boxes:
                label = OPERATIONS_LABELS.get(int(box.cls[0]))
                if label in totals:
                    totals[label] += 1
    return totals


def _region_report(regions, results, shape, previous, now):
    height, width = shape[:2]
    points = []
    for result in results:
        if result.boxes is None:
            continue
        for box in result.boxes:
            x1, y1, x2, y2 = box.xyxy[0].tolist()
            points.append(((x1+x2)/2/width, (y1+y2)/2/height,
                           int(box.id[0]) if box.id is not None else None))
    rows, updated = [], {}
    for region in regions:
        x, y, w, h = region['bounds']
        inside = [point for point in points if x <= point[0] <= x+w and y <= point[1] <= y+h]
        past = previous.get(region['name'], {})
        tracks = {i:past.get('tracks',{}).get(i,now) for _,_,i in inside if i is not None}
        since = past.get('since',now) if inside else now
        occupied = bool(inside) and now-since >= 3
        row = {'name':region['name'], 'kind':region['kind'], 'count':len(inside),
               'occupied':occupied, 'seconds':int(now-since) if occupied else 0,
               'below':region['kind']=='farm' and len(inside)<region['minimum'],
               'wait':max((int(now-first) for first in tracks.values()),default=None)}
        rows.append(row)
        updated[region['name']] = {'tracks':tracks,'since':since}
    return rows, updated, [point[:2] for point in points]


def _operations_regions(module):
    path = DATA_DIR / ('regions_' + module + '.json')
    if path.exists():
        return json.loads(path.read_text(encoding='utf-8'))
    return []


def _save_operations_regions(module, regions):
    from math import isfinite
    kinds = ('table','queue') if module == 'cafe' else ('farm',)
    if not isinstance(regions,list) or len(regions)>40:
        raise CloudError('En fazla 40 bölge kaydedilebilir.',400)
    clean = []
    for region in regions:
        try:
            name = region['name'].strip()
            kind = region['kind']
            x,y,w,h = bounds = [float(value) for value in region['bounds']]
            minimum = int(region.get('minimum',0))
            if not name or len(name)>40 or kind not in kinds or not all(isfinite(v) for v in bounds):
                raise ValueError()
            if min(x,y)<0 or min(w,h)<.015 or x+w>1.000001 or y+h>1.000001 or not 0<=minimum<=100:
                raise ValueError()
            if any(item['name']==name for item in clean):
                raise ValueError()
        except (TypeError, AttributeError, ValueError, KeyError, OverflowError):
            raise CloudError('Bölge adı, sınırları veya minimum sayı geçersiz. İsimler benzersiz olmalı.',400)
        clean.append({'name':name,'kind':kind,'bounds':bounds,'minimum':minimum})
    path = DATA_DIR / ('regions_' + module + '.json')
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(clean,ensure_ascii=False),encoding='utf-8')
    temporary.replace(path)
    _operations.update(regions=clean, region_rows=[], points=[], hours={})


def _operations_camera(module, source):
    cap = None
    try:
        cap, _, _, detail = open_camera(source)
        if cap is None:
            raise RuntimeError('Kamera açılamadı. ' + str(detail)[:150])
        from ultralytics import YOLO
        model_path = APP_DIR / 'yolov8n.pt'
        model = YOLO(str(model_path) if model_path.exists() else 'yolov8n.pt')
        previous = {}
        while not _operations['stop'].is_set():
            ok, frame = cap.read()
            if not ok or frame is None:
                raise RuntimeError('Kamera görüntüsü kesildi.')
            results = model.track(frame, persist=True, classes=OPERATIONS_CLASSES[module], conf=0.35, verbose=False)
            with _LOCK:
                rows, previous, points = _region_report(_operations['regions'], results, frame.shape, previous, time.monotonic())
                _operations.update(region_rows=rows, points=points)
                hour = datetime.now().strftime('%H:00')
                bucket = _operations['hours'].setdefault(hour, {'samples':0, 'occupied':0})
                bucket['samples'] += 1
                bucket['occupied'] += sum(row['occupied'] and row['kind']=='table' for row in rows)
            _operations['counts'] = _operations_counts(results, module)
            _operations['stop'].wait(0.4)
    except Exception as exc:
        _operations['error'] = str(exc)[:220]
    finally:
        _operations['counts'] = None
        if cap is not None:
            cap.release()


@app.route('/api/workspace/operations', methods=['GET','POST'])
def operations_api():
    module = session.get('active_module')
    if module not in OPERATIONS_CLASSES or not _admin_role():
        raise CloudError('Yönetici çalışma alanı gerekli.', 403)
    with _LOCK:
        worker = _operations['thread']
        running = bool(worker and worker.is_alive())
        if request.method == 'POST':
            form = request.get_json(silent=True) or {}
            action = form.get('action')
            if action == 'regions':
                if running:
                    raise CloudError('Bölgeleri değiştirmeden önce kamerayı durdur.',409)
                _save_operations_regions(module, form.get('regions'))
            elif action == 'stop':
                _operations['stop'].set()
            elif action == 'start':
                pet_worker = state.get('thread')
                if running or (pet_worker and pet_worker.is_alive()):
                    raise CloudError('Kamera kullanımda. Önce açık taramayı durdur.', 409)
                wall_sources = [c for group in _ip_cameras.values() for c in group.values()] + _live_retiring()
                if len(wall_sources) >= _CAMERA_LIMIT:
                    raise CloudError('Sayım için bir kamera yuvası boşalt.',409)
                if any(c['protocol']=='usb' for c in wall_sources):
                    raise CloudError('Sayım başlatmadan önce kamera duvarındaki USB yayınlarını kaldır.',409)
                source = form.get('source', 'auto')
                if source not in ('auto','obs'):
                    try:
                        source = int(source)
                        if not 0 <= source <= 30:
                            raise ValueError()
                    except (TypeError, ValueError):
                        raise CloudError('Geçerli bir kamera seç.', 400)
                _operations.update(module=module, counts=None, error=None, regions=_operations_regions(module), region_rows=[], points=[], hours={})
                _operations['stop'].clear()
                worker = threading.Thread(target=_operations_camera, args=(module,source), daemon=True)
                _operations['thread'] = worker
                worker.start()
                running = True
            else:
                raise CloudError('Geçersiz kamera işlemi.', 400)
        current = _operations['module'] == module
        return jsonify(running=running and current, counts=_operations['counts'] if current else None,
                       error=_operations['error'] if current else None, regions=_operations_regions(module),
                       rows=_operations.get('region_rows',[]) if current and running else [],
                       points=_operations.get('points',[]) if current and running else [],
                       hours=_operations.get('hours',{}) if current else {})


# ---- Universal camera engine, stage 1 (local administrator pilot) ----
# Kept in app.py for compatibility with the existing signed updater allowlist.
_ip_cameras = {'pet': {}, 'cafe': {}, 'farm': {}}
_retiring_cameras = []
_CAMERA_LIMIT = 4


# ONVIF discovery and Media 1 (GetCapabilities/GetProfiles/GetStreamUri).
# No new dependency or updater allowlist changes; all operations are local.
def _private_ipv4(value):
    import ipaddress
    addr = ipaddress.IPv4Address(str(value))
    if not any(addr in ipaddress.IPv4Network(net) for net in ('10.0.0.0/8','172.16.0.0/12','192.168.0.0/16')):
        raise ValueError('local network required')
    return str(addr)


def _safe_xml(data):
    import xml.etree.ElementTree as ET
    if len(data) > 512*1024 or b'\x00' in data or b'<!' in data.upper():
        raise ValueError('invalid XML')
    return ET.fromstring(data)


def _local_endpoint(value, ip, schemes=('http','https')):
    from urllib.parse import urlsplit
    part = urlsplit(value)
    if (part.scheme not in schemes or part.hostname != ip or part.username is not None
            or part.password is not None or part.fragment or not part.path.startswith('/')
            or part.path.startswith('//') or any(c.isspace() or ord(c)<32 or c=='\\' for c in value)):
        raise ValueError('unsafe device endpoint')
    if part.port is not None and not 1 <= part.port <= 65535:
        raise ValueError('invalid device port')
    return part


_DISCOVERY_LOCK = threading.Lock()

def _discover_onvif(timeout=3.0):
    import socket
    packet = (f'<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" '
        'xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" '
        'xmlns:d="http://schemas.xmlsoap.org/ws/2005/04/discovery" '
        'xmlns:dn="http://www.onvif.org/ver10/network/wsdl"><s:Header>'
        f'<a:MessageID>urn:uuid:{uuid.uuid4()}</a:MessageID>'
        '<a:To>urn:schemas-xmlsoap-org:ws:2005:04:discovery</a:To>'
        '<a:Action>http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</a:Action>'
        '</s:Header><s:Body><d:Probe><d:Types>dn:NetworkVideoTransmitter</d:Types>'
        '</d:Probe></s:Body></s:Envelope>').encode()
    message_id = _safe_xml(packet).find('.//{*}MessageID').text
    found = {}
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP) as sock:
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 1)
        sock.bind(('',0))
        sock.sendto(packet, ('239.255.255.250',3702))
        deadline = time.monotonic() + timeout
        while len(found) < 64 and time.monotonic() < deadline:
            sock.settimeout(max(.01, deadline-time.monotonic()))
            try: body, peer = sock.recvfrom(65535)
            except socket.timeout: break
            try:
                ip = _private_ipv4(peer[0]); root = _safe_xml(body)
                if root.findtext('.//{*}RelatesTo') != message_id: continue
                for match in root.findall('.//{*}ProbeMatch'):
                    for url in (match.findtext('{*}XAddrs') or '').split():
                        try: part = _local_endpoint(url, ip)
                        except ValueError: continue
                        port = part.port or (443 if part.scheme=='https' else 80)
                        path = part.path + ('?'+part.query if part.query else '')
                        found[(ip,port,path,part.scheme)] = {'ip':ip,'port':port,'path':path,'scheme':part.scheme}
                        if len(found)>=64: break
                    if len(found)>=64: break
            except Exception:
                # Malformed or unrelated datagrams are ignored, never displayed.
                continue
    return sorted(found.values(), key=lambda d:(d['ip'],d['port'],d['path']))


def _onvif_soap(url, ip, operation, body, user, password):
    import base64, hashlib
    from xml.sax.saxutils import escape
    import urllib.request as ur
    _local_endpoint(url, ip)
    class NoRedirect(ur.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs): return None
    nonce = os.urandom(16)
    created = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    digest = base64.b64encode(hashlib.sha1(nonce+created.encode()+password.encode()).digest()).decode()
    ws = 'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-'
    header = (f'<wsse:Security xmlns:wsse="{ws}wssecurity-secext-1.0.xsd" '
        f'xmlns:wsu="{ws}wssecurity-utility-1.0.xsd"><wsse:UsernameToken>'
        f'<wsse:Username>{escape(user)}</wsse:Username>'
        f'<wsse:Password Type="{ws}username-token-profile-1.0#PasswordDigest">{digest}</wsse:Password>'
        f'<wsse:Nonce EncodingType="{ws}soap-message-security-1.0#Base64Binary">{base64.b64encode(nonce).decode()}</wsse:Nonce>'
        f'<wsu:Created>{created}</wsu:Created></wsse:UsernameToken></wsse:Security>') if user else ''
    xml = (f'<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" '
        'xmlns:tds="http://www.onvif.org/ver10/device/wsdl" '
        'xmlns:trt="http://www.onvif.org/ver10/media/wsdl" '
        'xmlns:tt="http://www.onvif.org/ver10/schema">'
        f'<s:Header>{header}</s:Header><s:Body>{body}</s:Body></s:Envelope>').encode()
    mgr = ur.HTTPPasswordMgrWithDefaultRealm()
    mgr.add_password(None,url,user,password)
    opener = ur.build_opener(ur.ProxyHandler({}), NoRedirect(), ur.HTTPDigestAuthHandler(mgr))
    req = ur.Request(url, data=xml, headers={'Content-Type':f'application/soap+xml; charset=utf-8; action="{operation}"'},method='POST')
    with opener.open(req,timeout=4) as response:
        root = _safe_xml(response.read(512*1024+1))
    envelope_body = root.find('{*}Body')
    if envelope_body is None or envelope_body.find('{*}Fault') is not None:
        raise ValueError('ONVIF fault')
    return envelope_body


def _onvif_profiles(form):
    ip = _private_ipv4(str(form.get('ip','')).strip())
    user, password = str(form.get('username','')), str(form.get('password',''))
    if len(user)>128 or len(password)>256 or (password and not user): raise ValueError('invalid credentials')
    scheme = str(form.get('onvif_scheme','http'))
    if scheme not in ('http','https'): raise ValueError('invalid scheme')
    port = int(form.get('port') or (443 if scheme=='https' else 80))
    path = str(form.get('path','')).strip() or '/onvif/device_service'
    endpoint = f'{scheme}://{ip}:{port}{path}'
    if len(path)>512 or not path.startswith('/'): raise ValueError('invalid path')
    _local_endpoint(endpoint,ip)
    dev = 'http://www.onvif.org/ver10/device/wsdl/'
    media_ns = 'http://www.onvif.org/ver10/media/wsdl/'
    caps = _onvif_soap(endpoint,ip,dev+'GetCapabilities','<tds:GetCapabilities><tds:Category>Media</tds:Category></tds:GetCapabilities>',user,password)
    media = caps.findtext('.//{*}Media/{*}XAddr')
    if not media: raise ValueError('no Media1 service')
    _local_endpoint(media,ip)
    profiles = _onvif_soap(media,ip,media_ns+'GetProfiles','<trt:GetProfiles/>',user,password)
    items=[]
    for item in profiles.findall('.//{*}Profiles')[:64]:
        token = item.get('token','')
        if token and len(token)<=256:
            items.append({'token':token,'name':(item.findtext('{*}Name') or token)[:100]})
    if not items: raise ValueError('no profiles')
    return ip, media, user, password, items


def _onvif_source(form):
    from xml.sax.saxutils import escape
    try:
        ip, media, user, password, items = _onvif_profiles(form)
        token = str(form.get('profile','')) or items[0]['token']
        if token not in {item['token'] for item in items}: raise ValueError('unknown profile')
        body = ('<trt:GetStreamUri><trt:StreamSetup><tt:Stream>RTP-Unicast</tt:Stream>'
                '<tt:Transport><tt:Protocol>RTSP</tt:Protocol></tt:Transport></trt:StreamSetup>'
                f'<trt:ProfileToken>{escape(token)}</trt:ProfileToken></trt:GetStreamUri>')
        reply = _onvif_soap(media,ip,'http://www.onvif.org/ver10/media/wsdl/GetStreamUri',body,user,password)
        uri = reply.findtext('.//{*}Uri') or ''
        part = _local_endpoint(uri,ip,('rtsp',))
        path = part.path+('?' + part.query if part.query else '')
        _,source = _camera_source({'protocol':'rtsp','ip':ip,'port':part.port or 554,'path':path,'username':user,'password':password})
        return 'onvif',source
    except Exception:
        raise CloudError('ONVIF yayın adresi alınamadı. IP, port, saat, yetki ve Media1 desteğini kontrol et; gerekirse RTSP kullan.',400) from None


def _camera_store_path(module, owner):
    # Local account scope + module scope; no camera secrets in browser/SQLite/cloud.
    import hashlib
    key = hashlib.sha256(str(owner).encode()).hexdigest()
    return DATA_DIR / f'camera_vault_{module}_{key}.bin'


def _load_saved_cameras(module, owner):
    path = _camera_store_path(module,owner)
    if not path.exists(): return {}
    try:
        data = json.loads(dpapi_read(path))
        if not isinstance(data,dict) or len(data)>_CAMERA_LIMIT: raise ValueError()
        for key, item in data.items():
            if uuid.UUID(key).hex != key or not isinstance(item,dict) or item['protocol'] not in ('rtsp','onvif','nvr','http','https','usb') or not 1<=len(item['name'])<=40:
                raise ValueError()
            if item['protocol']=='usb':
                if type(item['source']) is not int or not 0<=item['source']<=30: raise ValueError()
            elif not isinstance(item['source'],str) or len(item['source'])>2048: raise ValueError()
        return data
    except Exception:
        raise CloudError('Şifreli kamera kaydı açılamadı. Aynı Windows hesabını kullan; kayıtlar silinmedi.',409) from None


def _save_cameras(module, owner, data):
    try:
        dpapi_save(_camera_store_path(module,owner),json.dumps(data,ensure_ascii=False).encode())
    except Exception:
        raise CloudError('Windows güvenli kamera kaydı yapılamadı. İstersen kaydetmeden bağlan.',503) from None


def _camera_source(form):
    """Resolve explicit local-network streams and Windows device sources."""
    import ipaddress
    from urllib.parse import quote, urlsplit
    protocol = str(form.get('protocol', 'rtsp')).lower()
    if protocol == 'onvif':
        return _onvif_source(form)
    if protocol == 'usb':
        device = str(form.get('device', 'obs'))
        if device == 'obs':
            matches = [d['id'] for d in list_cameras() if d.get('preferred')]
            if not matches:
                raise CloudError('OBS Sanal Kamera bulunamadı.', 400)
            return protocol, matches[0]
        try:
            index = int(device)
            if not 0 <= index <= 30:
                raise ValueError()
            return protocol, index
        except (ValueError, TypeError):
            raise CloudError('Geçerli bir USB kamera seç.', 400)
    if protocol not in ('rtsp', 'http', 'https', 'nvr'):
        raise CloudError('Desteklenmeyen bağlantı türü.', 400)
    scheme = 'rtsp' if protocol == 'nvr' else protocol
    try:
        address = ipaddress.IPv4Address(str(form.get('ip', '')).strip())
        allowed = ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16')
        if not any(address in ipaddress.IPv4Network(net) for net in allowed):
            raise ValueError()
        raw_port = form.get('port')
        port = int({'rtsp':554,'http':80,'https':443}[scheme] if raw_port in (None,'') else raw_port)
        path = str(form.get('path', '')).strip() or '/'
        if not 1 <= port <= 65535 or not path.startswith('/') or path.startswith('//'):
            raise ValueError()
        if len(path) > 512 or any(ch.isspace() or ord(ch)<32 or ch in '#\\' for ch in path):
            raise ValueError()
        username = str(form.get('username', ''))
        password = str(form.get('password', ''))
        if len(username)>128 or len(password)>256 or (password and not username):
            raise ValueError()
        auth = quote(username, safe='') + ':' + quote(password, safe='') + '@' if username else ''
        url = f'{scheme}://{auth}{address}:{port}{path}'
        if urlsplit(url).hostname != str(address):
            raise ValueError()
        return protocol, url
    except (ValueError, TypeError, OverflowError):
        raise CloudError('Yerel IPv4 adresi, port veya yayın yolu geçersiz.', 400)


def _open_universal_camera(protocol, source):
    if protocol == 'usb':
        cap, initial, _, _ = open_camera(source)
        return cap, initial
    cap = cv2.VideoCapture(source, cv2.CAP_FFMPEG, [
        cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 5000,
        cv2.CAP_PROP_READ_TIMEOUT_MSEC, 5000,
    ])
    return cap, None


# ---- Shared live camera inference (single bounded scheduler; no per-stream model clones) ----
_WALL_AI_CLASSES = {'pet': {15:'Kedi',16:'Köpek'}, 'cafe': {0:'Kişi'}, 'farm': {17:'At',18:'Koyun',19:'İnek'}}
_WALL_AI_LOCK = threading.Lock()
_wall_ai_thread = None

def _ensure_wall_ai():
    global _wall_ai_thread
    with _WALL_AI_LOCK:
        if _wall_ai_thread is None or not _wall_ai_thread.is_alive():
            _wall_ai_thread = threading.Thread(target=_wall_ai_loop,daemon=True,name='visionops-wall-ai')
            _wall_ai_thread.start()

# ---- Per-camera local analytics (v0.10.8) ----
_WALL_PROFILES = {'eco': (2.0,320), 'balanced': (1.0,416), 'detail': (.5,640)}
_WALL_KINDS = {'pet': ('area','food','water','litter','door'), 'cafe': ('area','table','queue','door'), 'farm': ('area','feed','water','pen','door')}

def _wall_db(module, owner):
    import hashlib
    key=hashlib.sha256(str(owner).encode()).hexdigest()
    conn=sqlite3.connect(DATA_DIR/f'wall_analytics_{module}_{key}.db',timeout=3)
    conn.row_factory=sqlite3.Row
    conn.execute('CREATE TABLE IF NOT EXISTS config(camera TEXT PRIMARY KEY, payload TEXT NOT NULL)')
    conn.execute('CREATE TABLE IF NOT EXISTS observations(id INTEGER PRIMARY KEY, camera TEXT, ts TEXT, region TEXT, event TEXT, track TEXT, label TEXT, seconds REAL)')
    conn.execute('CREATE INDEX IF NOT EXISTS wall_obs_camera ON observations(camera,ts)')
    conn.execute('CREATE TABLE IF NOT EXISTS samples(camera TEXT, day TEXT, hour INTEGER, n INTEGER, total INTEGER, heat TEXT, PRIMARY KEY(camera,day,hour))')
    conn.execute('CREATE TABLE IF NOT EXISTS alerts(id INTEGER PRIMARY KEY AUTOINCREMENT, camera TEXT NOT NULL, name TEXT NOT NULL, ts TEXT NOT NULL, kind TEXT NOT NULL, message TEXT NOT NULL, seen INTEGER NOT NULL DEFAULT 0)')
    conn.execute('CREATE INDEX IF NOT EXISTS wall_alert_ts ON alerts(ts,seen)')
    conn.commit()
    return conn

def _wall_config(module,owner,key):
    from contextlib import closing
    with closing(_wall_db(module,owner)) as conn:
        row=conn.execute('SELECT payload FROM config WHERE camera=?',(key,)).fetchone()
    return {**{'profile':'balanced','regions':[],'rules':_wall_rule_defaults()}, **(json.loads(row['payload']) if row else {})}

def _wall_validate(module, form):
    from math import isfinite
    if not isinstance(form,dict):raise CloudError('Geçersiz analiz ayarı.',400)
    profile=form.get('profile','balanced'); regions=form.get('regions',[])
    if not isinstance(profile,str) or profile not in _WALL_PROFILES or not isinstance(regions,list) or len(regions)>12:
        raise CloudError('Geçersiz profil veya en fazla 12 analiz alanı.',400)
    clean=[]
    for r in regions:
        try:
            name=r['name'].strip(); kind=r['kind']; bounds=[float(v) for v in r['bounds']]; x,y,w,h=bounds
            if not 1<=len(name)<=40 or kind not in _WALL_KINDS[module] or not all(isfinite(v) for v in bounds) or min(x,y)<0 or min(w,h)<.02 or x+w>1.000001 or y+h>1.000001 or any(v['name'].casefold()==name.casefold() for v in clean): raise ValueError()
        except (ValueError,TypeError,AttributeError,KeyError,OverflowError):
            raise CloudError('Alan adı, türü veya sınırları geçersiz. Alan adları benzersiz olmalı.',400) from None
        clean.append({'name':name,'kind':kind,'bounds':bounds})
    rules=_wall_rules(form.get('rules',{}),clean)
    return {'profile':profile,'regions':clean,'rules':rules}

# ---- Local notification and export services (v0.10.9) ----
def _wall_rule_defaults():
    return {'connection':True,'count':0,'change':0,'zone':'','dwell':0}

def _wall_rules(values,regions):
    if not isinstance(values,dict):raise CloudError('Geçersiz uyarı ayarı.',400)
    rules={**_wall_rule_defaults(),**{k:v for k,v in values.items() if k in _wall_rule_defaults()}}
    if type(rules['connection']) is not bool or any(type(rules[k]) is not int or not 0<=rules[k]<=100 for k in ('count','change')) or type(rules['dwell']) is not int or not 0<=rules['dwell']<=3600 or not isinstance(rules['zone'],str) or rules['zone'] not in ['']+[r['name'] for r in regions]:
        raise CloudError('Uyarı eşikleri veya seçilen alan geçersiz.',400)
    return rules

def _wall_alert(camera,kind,message):
    from contextlib import closing
    from datetime import timedelta
    now=datetime.now().astimezone();ts=now.isoformat(timespec='seconds');cutoff=(now.date()-timedelta(days=29)).isoformat()
    with closing(_wall_db(camera['module'],camera['owner'])) as conn,conn:
        conn.execute('INSERT INTO alerts(camera,name,ts,kind,message) VALUES(?,?,?,?,?)',(camera['id'],camera['name'],ts,kind,message))
        conn.execute('DELETE FROM alerts WHERE ts<?',(cutoff,))

def _wall_connection_alert(camera,live):
    # One warning per failed connection episode, one recovery; manual stop is not a failure.
    if camera['stop'].is_set():return
    failed=camera.get('alert_outage',False)
    if live== (not failed):return
    camera['alert_outage']=not live
    enabled=camera['config'].get('rules',_wall_rule_defaults())['connection']
    if enabled:
        try:_wall_alert(camera,'recovery' if live else 'connection','Görüntü bağlantısı yeniden kuruldu.' if live else 'Kamera bağlantısı kurulamadı veya kesildi; yeniden deneniyor.')
        except (sqlite3.Error,OSError,ValueError):camera['alert_error']=True

def _wall_ai_alerts(camera,rows,events,detections,stamp,token):
    rules=camera['config'].get('rules',_wall_rule_defaults())
    if camera.get('alert_token')!=token:
        camera.update(alert_token=token,alert_state={},alert_previous=None)
    state=camera['alert_state'];count=len(detections);prev=camera.get('alert_previous')
    def condition(key,active,message,confirm=2):
        item=state.setdefault(key,{'streak':0,'latched':False,'sent':-1e9})
        if not active:item.update(streak=0,latched=False);return
        item['streak']+=1
        if item['streak']>=confirm and not item['latched']:
            item['latched']=True
            if stamp-item['sent']>=60:
                _wall_alert(camera,key,message);item['sent']=stamp
    condition('count',bool(rules['count'] and count>=rules['count']),f'Algılama sayısı eşiğine ulaşıldı: {count}.')
    condition('change',bool(rules['change'] and prev is not None and 0<stamp-prev[0]<=5 and abs(count-prev[1])>=rules['change']),f'Kısa sürede algılama sayısı değişti: {prev[1] if prev else 0} → {count}.',1)
    camera['alert_previous']=(stamp,count)
    zone=rules['zone']; entry=any(e[0]==zone and e[1]=='Giriş' for e in events)
    if zone and entry:condition('zone',True,f'{zone} alanına giriş gözlendi.',1)
    else:condition('zone',False,'',1)
    row=next((r for r in rows if r['name']==zone),None)
    condition('dwell',bool(zone and rules['dwell'] and row and row['count'] and row['seconds']>=rules['dwell']),f'{zone} alanında kalış süresi eşiği aşıldı.',1)

def _wall_alert_scope():
    module=session.get('active_module')
    if module not in _ip_cameras or not _admin_role():raise CloudError('Yetkili çalışma alanı gerekli.',403)
    return module,str(g.current_user['id'])

@app.route('/api/workspace/wall-alerts',methods=['GET','POST'])
def wall_alerts_api():
    from contextlib import closing
    from datetime import timedelta
    module,owner=_wall_alert_scope();cutoff=(datetime.now().astimezone().date()-timedelta(days=29)).isoformat()
    with closing(_wall_db(module,owner)) as conn,conn:
        if request.method=='POST':
            form=request.get_json(silent=True) or {}
            if not isinstance(form,dict):raise CloudError('Geçersiz bildirim işlemi.',400)
            if form.get('action')=='all':
                # Mark existing alerts through the newest displayed ID; avoid reading concurrent arrivals.
                until=form.get('until')
                if type(until) is not int or until<0 or until>2**63-1:raise CloudError('Geçersiz bildirim seçimi.',400)
                conn.execute('UPDATE alerts SET seen=1 WHERE id<=?',(until,))
            elif form.get('action')=='read' and type(form.get('id')) is int and 0<form['id']<=2**63-1:
                conn.execute('UPDATE alerts SET seen=1 WHERE id=?',(form['id'],))
            else:raise CloudError('Geçersiz bildirim işlemi.',400)
        conn.execute('DELETE FROM alerts WHERE ts<?',(cutoff,))
        rows=[dict(r) for r in conn.execute('SELECT id,camera,name,ts,kind,message,seen FROM alerts ORDER BY id DESC LIMIT 100')]
        unread=conn.execute('SELECT COUNT(*) FROM alerts WHERE seen=0').fetchone()[0]
    response=jsonify(alerts=rows,unread=unread);response.headers['Cache-Control']='no-store';return response

@app.get('/api/workspace/wall-analytics/<camera_id>/export')
def wall_export(camera_id):
    import csv
    from io import StringIO
    from contextlib import closing
    from datetime import timedelta
    module,owner=_wall_alert_scope();kind=request.args.get('kind','events');days=request.args.get('days','7')
    if days not in ('7','30') or kind not in ('events','hourly','alerts'):raise CloudError('Geçersiz rapor seçimi.',400)
    with _LOCK:
        live=_ip_cameras[module].get(camera_id)
        if not (live and live['owner']==owner) and camera_id not in _load_saved_cameras(module,owner):raise CloudError('Kamera bulunamadı.',404)
    cutoff=(datetime.now().astimezone().date()-timedelta(days=int(days)-1)).isoformat()
    output=StringIO(newline='');writer=csv.writer(output,delimiter=';',lineterminator='\r\n')
    def safe(value):
        if value is None:return ''
        if isinstance(value,str) and (value[:1] in ('\t','\r','\n') or value.lstrip().startswith(('=','+','-','@'))):return "'"+value
        return value
    def emit(row):writer.writerow([safe(v) for v in row])
    with closing(_wall_db(module,owner)) as conn:
        if kind=='events':
            emit(['Zaman','Alan','Olay','Geçici iz','Tür','Süre (sn)'])
            for row in conn.execute('SELECT ts,region,event,track,label,seconds FROM observations WHERE camera=? AND ts>=? ORDER BY id',(camera_id,cutoff)):emit(row)
        elif kind=='hourly':
            emit(['Gün','Saat','Örnek','Algılama toplamı','Örnek başına ortalama'])
            for row in conn.execute('SELECT day,hour,n,total FROM samples WHERE camera=? AND day>=? ORDER BY day,hour',(camera_id,cutoff)):emit([*row,round(row['total']/row['n'],2) if row['n'] else 0])
        else:
            emit(['Zaman','Kamera','Tür','Uyarı','Okundu'])
            for row in conn.execute('SELECT ts,name,kind,message,seen FROM alerts WHERE camera=? AND ts>=? ORDER BY id',(camera_id,cutoff)):emit(row)
    return send_file(BytesIO(output.getvalue().encode('utf-8-sig')),as_attachment=True,mimetype='text/csv; charset=utf-8',download_name=f'VisionOps_{module}_{kind}_{days}gun.csv',max_age=0)

def _wall_track(previous, detections, regions, stamp):
    # Short-lived, same-camera centroid association; no face or cross-camera identity.
    from math import hypot
    tracks={k:v for k,v in previous.items() if 0 <= stamp-v['last']<=5}
    available=set(tracks); assigned=[]; events=[]
    pairs=sorted((hypot(x-t['x'],y-t['y']),i,k) for i,(label,x,y) in enumerate(detections) for k,t in tracks.items() if t['label']==label)
    matches={}
    for distance,i,k in pairs:
        if distance>.16: break
        if i not in matches and k in available: matches[i]=k;available.remove(k)
    for i,(label,x,y) in enumerate(detections):
        k=matches.get(i,uuid.uuid4().hex[:16]); t=tracks.get(k,{'label':label,'inside':{},'candidate':{}})
        inside=dict(t['inside']); candidate=dict(t['candidate'])
        for r in regions:
            name=r['name']; a,b,w,h=r['bounds']; present=a<=x<=a+w and b<=y<=b+h
            if present == (name in inside): candidate.pop(name,None);continue
            prior=candidate.get(name)
            if prior is None or prior[0]!=present: candidate[name]=(present,stamp);continue
            candidate.pop(name,None)
            if present:
                inside[name]=prior[1]; events.append((name,'Giriş',k,label,None))
            else:
                seconds=round(max(0,prior[1]-inside.pop(name)),1);events.append((name,'Çıkış',k,label,seconds))
        tracks[k]={'label':label,'x':x,'y':y,'last':stamp,'inside':inside,'candidate':candidate}
        assigned.append(tracks[k])
    rows=[{'name':r['name'],'kind':r['kind'],'count':sum(r['name'] in t['inside'] for t in assigned),'seconds':round(max((stamp-t['inside'][r['name']] for t in assigned if r['name'] in t['inside']),default=0),1)} for r in regions]
    return tracks,rows,events

def _wall_record(camera,events,detections,stamp):
    from contextlib import closing
    from datetime import timedelta
    sample=stamp-camera.get('last_persist',-1e9)>=5
    if not sample and not events:return
    now=datetime.now().astimezone(); ts=now.isoformat(timespec='seconds'); day=now.date().isoformat(); hour=now.hour; key=camera['id']
    with closing(_wall_db(camera['module'],camera['owner'])) as c, c:
        if events:c.executemany('INSERT INTO observations(camera,ts,region,event,track,label,seconds) VALUES(?,?,?,?,?,?,?)',[(key,ts,*e) for e in events])
        if sample:
            old=c.execute('SELECT heat FROM samples WHERE camera=? AND day=? AND hour=?',(key,day,hour)).fetchone()
            heat=json.loads(old['heat']) if old else [0]*96
            for _,x,y in detections:heat[min(7,max(0,int(y*8)))*12+min(11,max(0,int(x*12)))]+=1
            c.execute('INSERT INTO samples VALUES(?,?,?,?,?,?) ON CONFLICT(camera,day,hour) DO UPDATE SET n=n+1,total=total+excluded.total,heat=excluded.heat',(key,day,hour,1,len(detections),json.dumps(heat)))
        if camera.get('last_prune')!=day:
            cutoff=(now.date()-timedelta(days=29)).isoformat();c.execute('DELETE FROM samples WHERE day<?',(cutoff,));c.execute('DELETE FROM observations WHERE ts<?',(cutoff,))
    if sample:camera['last_persist']=stamp
    camera['last_prune']=day

def _wall_report(module,owner,key):
    from contextlib import closing
    from datetime import timedelta
    today=datetime.now().astimezone().date(); cutoff=(today-timedelta(days=6)).isoformat()
    with closing(_wall_db(module,owner)) as c:
        samples=c.execute('SELECT * FROM samples WHERE camera=? AND day>=? ORDER BY day,hour',(key,cutoff)).fetchall()
        events=[dict(r) for r in c.execute('SELECT ts,region,event,track,label,seconds FROM observations WHERE camera=? AND ts>=? ORDER BY id DESC LIMIT 100',(key,cutoff))]
    heat=[0]*96; days={};hours={}
    for s in samples:
        d=days.setdefault(s['day'],[0,0]);d[0]+=s['n'];d[1]+=s['total']
        if s['day']==today.isoformat():
            h=hours.setdefault(s['hour'],[0,0]);h[0]+=s['n'];h[1]+=s['total']
        for i,v in enumerate(json.loads(s['heat'])):heat[i]+=v
    return {'events':events,'heat':heat,'days':[{'day':k,'samples':v[0],'average':round(v[1]/v[0],2)} for k,v in days.items()], 'hours':[{'hour':k,'samples':v[0],'average':round(v[1]/v[0],2)} for k,v in hours.items()]}

@app.route('/api/workspace/wall-analytics/<camera_id>',methods=['GET','POST'])
def wall_analytics_api(camera_id):
    module=session.get('active_module')
    if module not in _ip_cameras or not _admin_role():raise CloudError('Yetkili çalışma alanı gerekli.',403)
    owner=str(g.current_user['id'])
    with _LOCK:
        live=_ip_cameras[module].get(camera_id)
        if live is not None and live['owner']!=owner: live=None
        if live is None and camera_id not in _load_saved_cameras(module,owner):raise CloudError('Kamera bulunamadı.',404)
        if request.method=='POST':
            from contextlib import closing
            form=request.get_json(silent=True) or {}
            if isinstance(form,dict) and 'rules' not in form:
                prior=_wall_config(module,owner,camera_id)['rules'];form={**form,'rules':{**prior,'zone':prior['zone'] if prior['zone'] in [r.get('name') for r in form.get('regions',[]) if isinstance(r,dict)] else ''}} if isinstance(form.get('regions',[]),list) else form
            config=_wall_validate(module,form)
            with closing(_wall_db(module,owner)) as c, c:
                c.execute('INSERT OR REPLACE INTO config VALUES(?,?)',(camera_id,json.dumps(config,ensure_ascii=False)))
            if live is not None:live.update(config=config,analysis_epoch=live['analysis_epoch']+1,counts=None,region_rows=[],ai_sample=None,ai_last=None)
        config=_wall_config(module,owner,camera_id)
        response=jsonify(config=config,rows=live.get('region_rows',[]) if live and live.get('analysis') and live['status']=='Canlı' else [],device=live.get('ai_device') if live else None,**_wall_report(module,owner,camera_id))
        response.headers['Cache-Control']='no-store'
        return response

@app.get('/api/workspace/wall-analytics/<camera_id>/snapshot')
def wall_snapshot(camera_id):
    module=session.get('active_module')
    if module not in _ip_cameras or not _admin_role():raise CloudError('Yetkili çalışma alanı gerekli.',403)
    with _LOCK:
        camera=_ip_cameras[module].get(camera_id)
        if not camera or camera['owner']!=str(g.current_user['id']):raise CloudError('Kamera bulunamadı.',404)
        frame=camera.get('frame') if camera['status']=='Canlı' else None
    if not frame:raise CloudError('Canlı görüntü bekleniyor.',409)
    return Response(frame,mimetype='image/jpeg',headers={'Cache-Control':'no-store'})


def _wall_ai_loop():
    model = None
    retry_at = 0
    device = "cpu"
    force_cpu = False
    while True:
        with _LOCK:
            cameras = [c for group in _ip_cameras.values() for c in group.values() if c.get('analysis') and not c['stop'].is_set()]
        if not cameras:
            time.sleep(.25)
            continue
        if model is None:
            if time.monotonic() < retry_at:
                time.sleep(.5); continue
            try:
                for camera in cameras: camera['ai_status']='Model hazırlanıyor'
                from ultralytics import YOLO
                path=APP_DIR/'yolov8n.pt'
                model=YOLO(str(path) if path.exists() else 'yolov8n.pt')
                import torch
                device=0 if not force_cpu and torch.cuda.is_available() else 'cpu'
            except Exception:
                retry_at=time.monotonic()+30
                for camera in cameras: camera.update(ai_status='Model yüklenemedi',counts=None)
                continue
        for camera in cameras:
            if camera['stop'].is_set() or not camera.get('analysis'): continue
            sample=camera.get('ai_sample')
            if sample is None or sample[0]==camera.get('ai_last'): continue
            stamp,frame=sample
            if time.monotonic()-stamp>3: continue
            camera['ai_last']=stamp
            epoch=camera['analysis_epoch']
            generation=camera.get('generation',0)
            labels=_WALL_AI_CLASSES[camera['module']]
            try:
                config=camera['config']; cadence,size=_WALL_PROFILES[config['profile']]
                counts={label:0 for label in labels.values()}; detections=[]
                results=model.predict(frame,classes=list(labels),imgsz=size,conf=.4,device=device,verbose=False,max_det=100)
                height,width=frame.shape[:2]
                for result in results:
                    if result.boxes is None: continue
                    for box in result.boxes:
                        label=labels.get(int(box.cls[0]))
                        if label:
                            counts[label]+=1;x1,y1,x2,y2=box.xyxy[0].tolist()
                            detections.append((label,max(0,min(1,(x1+x2)/2/width)),max(0,min(1,(y1+y2)/2/height))))
                with _LOCK:
                    if camera.get('analysis') and camera['analysis_epoch']==epoch and camera.get('generation')==generation and not camera['stop'].is_set() and camera['status']=='Canlı':
                        token=(epoch,generation); previous=camera.get('track_state',{}) if camera.get('track_token')==token else {}
                        tracks,rows,events=_wall_track(previous,detections,config['regions'],stamp)
                        camera.update(counts=counts,ai_status='Analiz açık',ai_device='CUDA GPU' if device==0 else 'CPU',track_state=tracks,track_token=token,region_rows=rows)
                        try:
                            _wall_record(camera,events,detections,stamp)
                            _wall_ai_alerts(camera,rows,events,detections,stamp,token)
                        except (sqlite3.Error,OSError,ValueError):camera['ai_status']='Analiz açık · kayıt hatası'
            except Exception:
                if device==0:
                    force_cpu=True;model=None;device='cpu'
                if camera.get('analysis') and camera['analysis_epoch']==epoch:
                    camera.update(counts=None,region_rows=[],ai_status='CPU ile yeniden deneniyor' if force_cpu and model is None else 'Analiz hatası')
                if model is None:break
            time.sleep(.12)
        time.sleep(.15)

def _ip_camera_worker(camera):
    stop = camera['stop']
    delay = 2
    interval = 1 / 8
    try:
        while not stop.is_set():
            cap = None
            try:
                camera.update(status='Bağlanıyor', frame=None, ai_sample=None, counts=None, region_rows=[], ai_device=None, generation=camera.get('generation',0)+1)
                cap, initial = _open_universal_camera(camera['protocol'], camera['source'])
                if cap is None or not cap.isOpened():
                    raise RuntimeError('open failed')
                failures = 0
                next_publish = 0.0
                while not stop.is_set():
                    if initial is not None:
                        ok, frame = True, initial
                        initial = None
                    else:
                        ok, frame = cap.read()
                    if not ok or frame is None or not frame.size:
                        failures += 1
                        if failures >= 3:
                            raise RuntimeError('read failed')
                        stop.wait(.12)
                        continue
                    failures = 0
                    now = time.monotonic()
                    if now < next_publish:
                        continue  # drain decoder instead of building up old frames
                    next_publish = now + interval
                    height, width = frame.shape[:2]
                    if width > 960:
                        frame = cv2.resize(frame, (960, max(1, round(height*960/width))), interpolation=cv2.INTER_AREA)
                    # Keep a single recent frame in RAM for opt-in inference, at most 2 fps per source.
                    if camera.get('analysis') and now-camera.get('ai_sample_at',0)>=_WALL_PROFILES[camera['config']['profile']][0]:
                        camera.update(ai_sample=(now,frame.copy()),ai_sample_at=now)
                    elif not camera.get('analysis'):
                        camera['ai_sample']=None
                    # Reuse the existing best-effort face filter before publishing.
                    with _CAM_PRIVACY_LOCK:
                        frame = redact_faces(frame, [])
                    encoded, jpeg = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 70])
                    if encoded and not stop.is_set():
                        camera.update(frame=jpeg.tobytes(), status='Canlı')
                        if camera.get('alert_outage'):_wall_connection_alert(camera,True)
                        delay = 2
            except Exception:
                # Do not propagate URL/credentials to status or browser logs.
                camera.update(status='Yeniden bağlanıyor', frame=None, ai_sample=None, counts=None, region_rows=[], ai_device=None, generation=camera.get('generation',0)+1)
                if camera.get('analysis'): camera['ai_status']='Görüntü bekleniyor'
                _wall_connection_alert(camera,False)
            finally:
                if cap is not None:
                    cap.release()
            if stop.wait(delay):
                break
            delay = min(delay * 2, 30)
    finally:
        camera.update(status='Durduruldu', frame=None, ai_sample=None, counts=None, region_rows=[], ai_device=None)


_CAM_PRIVACY_LOCK = threading.Lock()


def _live_retiring():
    _retiring_cameras[:] = [c for c in _retiring_cameras if c['worker'].is_alive()]
    return _retiring_cameras


def _retire_camera(camera):
    camera['stop'].set()
    camera['frame'] = None
    if camera['worker'].is_alive():
        _retiring_cameras.append(camera)


def _close_ip_cameras(module):
    with _LOCK:
        for camera in _ip_cameras[module].values():
            _retire_camera(camera)
        _ip_cameras[module].clear()
        _live_retiring()


def _start_wall_camera(cameras, key, record, owner):
    existing = [c for group in _ip_cameras.values() for c in group.values()] + _live_retiring()
    worker, pet = _operations.get('thread'), state.get('thread')
    legacy_running = bool((worker and worker.is_alive()) or (pet and pet.is_alive()))
    if len(existing)+int(legacy_running)>=_CAMERA_LIMIT:
        raise CloudError('En fazla dört eş zamanlı kaynak. Açık sayımı veya bir kamerayı kapat.',409)
    if any(c['source']==record['source'] for c in existing):
        raise CloudError('Bu kaynak zaten açık veya kapanıyor.',409)
    if session.get('active_module')=='pet' and legacy_running:
        raise CloudError('Önce klasik Pet izlemesini durdur.',409)
    if record['protocol']=='usb' and legacy_running:
        raise CloudError('USB kamera eklemeden önce canlı sayımı durdur.',409)
    config=_wall_config(session.get('active_module'),owner,key)
    camera = dict(record,id=key,config=config,owner=owner,module=session.get('active_module'),status='Bağlanıyor',stop=threading.Event(),frame=None,analysis=False,counts=None,ai_status='Kapalı',analysis_epoch=0)
    camera['worker'] = threading.Thread(target=_ip_camera_worker,args=(camera,),daemon=True)
    cameras[key]=camera
    try: camera['worker'].start()
    except Exception:
        cameras.pop(key,None)
        raise CloudError('Kamera başlatılamadı.',503) from None


@app.route('/api/workspace/ip-cameras', methods=['GET','POST'])
def ip_cameras_api():
    module = session.get('active_module')
    if module not in _ip_cameras or not _admin_role():
        raise CloudError('Kamera yönetimi için yetkili çalışma alanı gerekli.',403)
    owner = str(g.current_user['id'])
    form = request.get_json(silent=True) or {} if request.method=='POST' else {}
    action = form.get('action')
    record = None
    if action=='add':
        label = str(form.get('label','')).strip()
        if not 1<=len(label)<=40: raise CloudError('Kamera adı 1–40 karakter olmalı.',400)
        protocol,source = _camera_source(form)
        record = {'name':label,'protocol':protocol,'source':source}
    with _LOCK:
        cameras = _ip_cameras[module]
        saved = _load_saved_cameras(module,owner)
        own = {k:v for k,v in cameras.items() if v['owner']==owner}
        if request.method=='POST':
            key=str(form.get('id',''))
            if action=='add':
                if len(set(saved)|set(own))>=_CAMERA_LIMIT:
                    raise CloudError('En fazla dört kamera kaydı eklenebilir.',409)
                if any(c['source']==record['source'] for c in (list(saved.values())+list(own.values()))):
                    raise CloudError('Bu kamera zaten ekli.',409)
                key=uuid.uuid4().hex
                _start_wall_camera(cameras,key,record,owner)
                if form.get('remember') in (True,'on','true'):
                    try:
                        saved[key]=record; _save_cameras(module,owner,saved)
                    except CloudError:
                        saved.pop(key,None); _retire_camera(cameras.pop(key)); raise
            elif action in ('remove','rename','connect','disconnect','analysis'):
                camera = own.get(key)
                if camera is None and key not in saved: raise CloudError('Kamera bulunamadı.',404)
                if action=='analysis':
                    if camera is None: raise CloudError('Önce kamerayı bağla.',409)
                    if type(form.get('enabled')) is not bool: raise CloudError('Geçersiz analiz ayarı.',400)
                    camera.update(analysis=form['enabled'], counts=None, region_rows=[], ai_device=None, ai_sample=None, ai_last=None, ai_status='Bekliyor' if form['enabled'] else 'Kapalı', analysis_epoch=camera['analysis_epoch']+1)
                    if form['enabled']: _ensure_wall_ai()
                elif action=='remove':
                    if key in saved:
                        del saved[key]; _save_cameras(module,owner,saved)
                    if camera is not None: _retire_camera(cameras.pop(key))
                elif action=='rename':
                    label=str(form.get('label','')).strip()
                    if not 1<=len(label)<=40: raise CloudError('Kamera adı 1–40 karakter olmalı.',400)
                    if key in saved:
                        saved[key]['name']=label; _save_cameras(module,owner,saved)
                    if camera is not None: camera['name']=label
                elif action=='connect':
                    if camera is None: _start_wall_camera(cameras,key,saved[key],owner)
                elif action=='disconnect':
                    if key not in saved: raise CloudError('Geçici kamerayı kaldır veya kaydederek ekle.',400)
                    if camera is not None: _retire_camera(cameras.pop(key))
            else: raise CloudError('Geçersiz kamera işlemi.',400)
        own = {k:v for k,v in cameras.items() if v['owner']==owner}
        rows = dict(saved); rows.update(own)
        return jsonify(cameras=[{'id':key,'name':item['name'],'status':item.get('status','Kapalı'),
                    'protocol':item['protocol'],'saved':key in saved,'analysis':item.get('analysis',False),'counts':item.get('counts'),'ai_status':item.get('ai_status','Kapalı')} for key,item in rows.items()],limit=_CAMERA_LIMIT)


@app.post('/api/workspace/onvif/discover')
def workspace_onvif_discover():
    if session.get('active_module') not in _ip_cameras or not _admin_role():
        raise CloudError('Yetkili çalışma alanı gerekli.',403)
    if not _DISCOVERY_LOCK.acquire(blocking=False): raise CloudError('Tarama zaten sürüyor.',409)
    try:
        return jsonify(devices=_discover_onvif())
    except Exception:
        raise CloudError('Yerel ağ taranamadı. Windows güvenlik duvarını ve ağ bağlantısını kontrol et.',503) from None
    finally: _DISCOVERY_LOCK.release()


@app.post('/api/workspace/onvif/profiles')
def workspace_onvif_profiles():
    if session.get('active_module') not in _ip_cameras or not _admin_role():
        raise CloudError('Yetkili çalışma alanı gerekli.',403)
    try:
        _,_,_,_,items = _onvif_profiles(request.get_json(silent=True) or {})
        return jsonify(profiles=items)
    except Exception:
        raise CloudError('ONVIF profilleri alınamadı. IP, port, saat, kullanıcı ve Media1 desteğini kontrol et.',400) from None


@app.get('/api/workspace/camera-devices')
def workspace_camera_devices():
    if session.get('active_module') not in _ip_cameras or not _admin_role():
        raise CloudError('Yetkili çalışma alanı gerekli.',403)
    return jsonify(devices=list_cameras())


@app.get('/api/workspace/ip-cameras/<camera_id>/stream')
def ip_camera_stream(camera_id):
    module = session.get('active_module')
    if module not in _ip_cameras or not _admin_role():
        raise CloudError('Kamera erişimi için yönetici oturumu gerekli.',403)
    with _LOCK:
        camera = _ip_cameras[module].get(camera_id)
    if camera is None or camera['owner'] != str(g.current_user['id']):
        raise CloudError('Kamera bulunamadı.',404)

    def frames():
        last = None
        while not camera['stop'].wait(.12) and camera['status'] == 'Canlı':
            frame = camera['frame']
            if frame is not None and frame is not last:
                last = frame
                yield b'--frame\r\nContent-Type: image/jpeg\r\n\r\n'+frame+b'\r\n'
    return Response(frames(), mimetype='multipart/x-mixed-replace; boundary=frame',
                    headers={'Cache-Control':'no-store','X-Accel-Buffering':'no'})


@app.get('/workspace/<module>')
def private_workspace(module):
    if module not in ('cafe', 'farm') or session.get('active_module') != module or not _admin_role():
        return redirect('/choose')
    return render_template('activate.html', module=module, workspace_open=True, csrf=session['csrf'], version=json.loads((APP_DIR/'version.json').read_text())['version'], username=g.current_user.get('username','Yönetici'))


@app.before_request
def enforce_workspace():
    path = request.path
    if path not in ('/', '/video') and (not path.startswith('/api/') or
       path.startswith(('/api/auth/', '/api/cloud/', '/api/admin/', '/api/updates/', '/api/workspace/'))):
        return None
    try:
        if session.get('active_module') != 'pet':
            raise CloudError('Pet çalışma alanına giriş yapılmalı.', 403)
        if _admin_role() and _PET_OWNER == 'local-admin':
            return None
        cloud = _active_session(_local_key())
        if not session.get('customer_key') or _PET_OWNER != cloud['cloud_id']:
            raise CloudError('Çalışma alanına giriş yetkin yok.', 403)
        # Recheck periodically for UI calls without querying the service for each frame.
        if time.time() - session.get('license_verified_at', 0) > 30:
            if not _workspace_allowed('pet', cloud):
                state['running'] = False
                session.pop('active_module', None)
                raise CloudError('Etkin Pet erişimi bulunamadı.', 403)
            session['license_verified_at'] = time.time()
    except CloudError as exc:
        if path.startswith('/api/') or path == '/video':
            return jsonify({'error':str(exc)}), exc.status
        return redirect('/activate/pet')
    return None


@app.route("/")
def index(): return _render_pet_preview()

@app.route("/video")
def video(): return Response(mjpeg(),mimetype="multipart/x-mixed-replace; boundary=frame")

@app.route("/api/cameras")
def cameras():
    devices = list_cameras()
    return jsonify({"devices": devices, "error": state.get("device_error"), "obs_found": any(d["preferred"] for d in devices)})

@app.route("/api/status")
def status():
    with db() as c:
        total=c.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        today=datetime.now().astimezone().date().isoformat()
        today_events=c.execute("SELECT COUNT(*) FROM events WHERE ts LIKE ?",(today+"%",)).fetchone()[0]
        cats=c.execute("SELECT COUNT(*) FROM events WHERE event_type='cat_detected' AND ts LIKE ?",(today+"%",)).fetchone()[0]
    return jsonify({"running":state["running"],"streaming":state["camera_ready"],"error":state["error"],"model":state["model_status"],
        "fps":round(state["fps"],1),"active_camera":state.get("active_camera"),"events":total,"today_events":today_events,"cat_detections_today":cats,
        "zones":len(load_zones()),"source":state["source"],"object_status":state["object_model_status"],"people":len(state['last_people']),"cat_active":len(state['last_detections'])})

@app.route("/api/start",methods=["POST"])
def start_camera():
    with _LOCK:
        worker = _operations['thread']
        if worker and worker.is_alive():
            raise CloudError('Diğer çalışma alanı kamerayı bırakıyor. Tekrar deneyin.', 409)
        if any(_ip_cameras.values()) or _live_retiring():
            raise CloudError('Diğer çalışma alanının kameraları kapanıyor. Tekrar deneyin.', 409)
        return _start_pet_camera()

def _start_pet_camera():
    if state["running"]: return jsonify({"ok":True,"message":"Kamera zaten çalışıyor."})
    if state.get("thread") and state["thread"].is_alive():
        return jsonify({"ok":False,"error":"Önceki kamera kapatılıyor; birkaç saniye sonra tekrar deneyin."}),409
    data=request.get_json(silent=True) or {}
    source=data.get("source",get_setting("camera_source","0"))
    try:
        source = str(source).lower() if str(source).lower() in ("auto", "obs") else int(source)
        if isinstance(source, int) and not 0 <= source <= 30: raise ValueError()
    except (ValueError, TypeError): return jsonify({"ok":False,"error":"Geçersiz kamera kaynağı."}),400
    state["source"]=source; state["error"]=None; state["running"]=True; state["camera_ready"]=False
    with state["lock"]: state["frame"] = None
    state["thread"]=threading.Thread(target=camera_loop,daemon=True); state["thread"].start()
    return jsonify({"ok":True,"message":"Kamera başlatılıyor."})

@app.route("/api/stop",methods=["POST"])
def stop_camera():
    state["running"]=False
    state["camera_ready"]=False
    thread = state.get("thread")
    if thread and thread.is_alive(): thread.join(timeout=2)
    return jsonify({"ok":True})

@app.route("/api/zones")
def zones(): return jsonify(load_zones())

@app.route("/api/zones",methods=["POST"])
def save_zone():
    d=request.get_json()
    name=str(d.get("name","Yeni alan")).strip()[:50]
    ztype=str(d.get("zone_type","custom"))
    allowed={"entry","food","water","litter","custom"}
    if ztype not in allowed: ztype="custom"
    x=max(0,min(1,float(d.get("x",0)))); y=max(0,min(1,float(d.get("y",0))))
    w=max(.01,min(1-x,float(d.get("w",.2)))); h=max(.01,min(1-y,float(d.get("h",.2))))
    with db() as c:
        cur=c.execute("INSERT INTO zones(name,zone_type,x,y,w,h) VALUES(?,?,?,?,?,?)",(name,ztype,x,y,w,h))
        zid=cur.lastrowid
    return jsonify({"ok":True,"id":zid})

@app.route("/api/zones/<int:zid>",methods=["DELETE"])
def delete_zone(zid):
    with db() as c: c.execute("DELETE FROM zones WHERE id=?",(zid,))
    return jsonify({"ok":True})

@app.route("/api/events")
def events():
    limit=min(200,max(1,int(request.args.get("limit",100))))
    with db() as c:
        rows=[dict(r) for r in c.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?",(limit,)).fetchall()]
    return jsonify(rows)

@app.route("/api/summary")
def summary():
    today=datetime.now().astimezone().date().isoformat()
    with db() as c:
        rows=c.execute("SELECT event_type,zone_name,COUNT(*) n FROM events WHERE ts LIKE ? GROUP BY event_type,zone_name",(today+"%",)).fetchall()
    counts={"cat_detected":0,"cat_lost_view":0,"zone_enter":0,"zone_exit":0}
    zone_counts={}
    for r in rows:
        counts[r["event_type"]]=counts.get(r["event_type"],0)+r["n"]
        if r["event_type"]=="zone_enter" and r["zone_name"]:
            zone_counts[r["zone_name"]]=zone_counts.get(r["zone_name"],0)+r["n"]
    return jsonify({"counts":counts,"zones":zone_counts})

@app.route("/api/reports/ten-minute")
def ten_minute_report():
    """Aggregated event observations in ten-minute time buckets, local time."""
    today = datetime.now().astimezone().date().isoformat()
    with db() as c:
        rows = c.execute("SELECT ts,event_type,zone_name FROM events WHERE ts LIKE ? ORDER BY ts", (today+"%",)).fetchall()
    buckets = {}
    for r in rows:
        try:
            stamp = datetime.fromisoformat(r["ts"])
            minute = (stamp.minute // 10) * 10
            key = stamp.strftime("%H:") + f"{minute:02d}"
        except (ValueError, TypeError):
            continue
        bucket = buckets.setdefault(key, {"time":key,"detections":0,"visits":0,"lost":0,"areas":{}})
        if r["event_type"] == "cat_detected": bucket["detections"] += 1
        elif r["event_type"] == "zone_enter":
            bucket["visits"] += 1
            area = r["zone_name"] or "İsimsiz bölge"
            bucket["areas"][area] = bucket["areas"].get(area,0)+1
        elif r["event_type"] == "cat_lost_view": bucket["lost"] += 1
    return jsonify({"date":today,"interval_minutes":10,"buckets":list(buckets.values()),
        "note":"Bu sayılar gözlem olaylarıdır; yemek/su tüketimi veya gerçek oda çıkışı kanıtı değildir."})

@app.route("/api/events/clear",methods=["POST"])
def clear_events():
    with db() as c: c.execute("DELETE FROM events")
    state["tracks"]={}; state["next_track"]=1
    return jsonify({"ok":True})

@app.route("/api/info")
def info():
    from flask import session
    version = json.loads((APP_DIR / "version.json").read_text(encoding="utf-8"))["version"]
    return jsonify({"version": version, "user": session.get("username"), "role": session.get("role"), "local": True})

if __name__ == "__main__":
    init_db()
    print("VisionOps AI yerel sunucu: http://127.0.0.1:5000", flush=True)
    app.run(host="127.0.0.1",port=5000,debug=False,threaded=True)
