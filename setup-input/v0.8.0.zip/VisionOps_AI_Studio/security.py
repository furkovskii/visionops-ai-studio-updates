"""Local-only authentication. No password or private event data is uploaded to GitHub."""
import os
import re
import secrets
import sqlite3
import time
from datetime import timedelta
import threading
from pathlib import Path
from functools import wraps
from flask import abort, g, jsonify, redirect, render_template, request, session, url_for
from werkzeug.security import generate_password_hash, check_password_hash

LOCK = threading.Lock()
FAILURES = {}
USERNAME = re.compile(r'^[a-zA-Z0-9_.-]{3,32}$')


def init_security(app, data_dir):
    users_db = Path(data_dir) / 'users.db'
    secret_file = Path(data_dir) / '.session_secret'
    if not secret_file.exists():
        try:
            with secret_file.open('x', encoding='ascii') as f:
                f.write(secrets.token_hex(32))
            if os.name != 'nt': os.chmod(secret_file, 0o600)
        except FileExistsError:
            pass
    app.secret_key = secret_file.read_text(encoding='ascii').strip()
    app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Strict',
                      SESSION_COOKIE_SECURE=False, PERMANENT_SESSION_LIFETIME=timedelta(days=30),
                      MAX_CONTENT_LENGTH=32*1024*1024)

    def database():
        connection = sqlite3.connect(users_db, timeout=20)
        connection.row_factory = sqlite3.Row
        return connection

    with database() as conn:
        conn.execute('''CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE COLLATE NOCASE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('admin','viewer')),
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            is_active INTEGER DEFAULT 1)''')

    def any_users():
        with database() as conn:
            return conn.execute('SELECT 1 FROM users LIMIT 1').fetchone() is not None

    def form_session():
        if 'csrf' not in session: session['csrf'] = secrets.token_hex(24)
        return session['csrf']

    @app.before_request
    def authentication_gate():
        # The local HTTP server is bound only to 127.0.0.1 by studio.py.
        path = request.path
        if path in ('/login', '/setup', '/choose') or path.startswith('/api/auth/'):
            if request.method not in ('GET','HEAD','OPTIONS'):
                origin = request.headers.get('Origin')
                if origin and origin != request.host_url.rstrip('/'):
                    return jsonify({'error':'Geçersiz kaynak.'}),403
                if not secrets.compare_digest(request.headers.get('X-CSRF-Token',''), session.get('csrf','')):
                    return jsonify({'error':'İstek doğrulama hatası.'}),403
            return None
        if request.host.split(':')[0].lower() not in ('127.0.0.1','localhost'):
            return jsonify({'error':'Geçersiz sunucu adı.'}),403
        uid = session.get('user_id')
        if not uid:
            if path.startswith('/api/') or path == '/video': return jsonify({'error':'Oturum açılmalı.'}),401
            return redirect('/setup' if not any_users() else '/login')
        with database() as conn:
            user = conn.execute('SELECT id,username,role,is_active FROM users WHERE id=?',(uid,)).fetchone()
        if not user or not user['is_active']:
            session.clear()
            if path.startswith('/api/') or path == '/video':
                return jsonify({'error':'Oturum geçersiz.'}),401
            return redirect('/login')
        g.current_user = dict(user)
        session['username'] = user['username']
        session['role'] = user['role']
        if request.method not in ('GET','HEAD','OPTIONS'):
            if path.startswith('/api/') and session.get('role')!='admin':
                return jsonify({'error':'Bu işlem için yönetici yetkisi gerekiyor.'}),403
            origin = request.headers.get('Origin')
            if origin and origin != request.host_url.rstrip('/'):
                return jsonify({'error':'Geçersiz kaynak.'}),403
            if not secrets.compare_digest(request.headers.get('X-CSRF-Token',''), session.get('csrf','')):
                return jsonify({'error':'Güvenlik doğrulaması başarısız; sayfayı yenileyin.'}),403
        return None

    @app.after_request
    def security_headers(resp):
        resp.headers['X-Content-Type-Options'] = 'nosniff'
        resp.headers['X-Frame-Options'] = 'DENY'
        resp.headers['Referrer-Policy'] = 'no-referrer'
        if request.path in ('/login', '/setup','/choose','/activate/pet','/activate/cafe','/activate/farm') or request.path.startswith('/api/auth/'):
            resp.headers['Cache-Control'] = 'no-store'
        return resp

    @app.route('/login')
    def login_page():
        if not any_users(): return redirect('/setup')
        if session.get('user_id'): return redirect('/choose')
        return render_template('login.html', mode='login', csrf=form_session())

    @app.route('/setup')
    def setup_page():
        if any_users(): return redirect('/login')
        return render_template('login.html', mode='setup', csrf=form_session())

    @app.route('/api/auth/setup',methods=['POST'])
    def setup():
        data = request.get_json(silent=True) or {}
        username = str(data.get('username','')).strip()
        password = str(data.get('password',''))
        if not USERNAME.fullmatch(username) or len(password)<10 or len(password)>256:
            return jsonify({'error':'Kullanıcı adı 3–32 karakter; parola en az 10 karakter olmalı.'}),400
        with LOCK:
            if any_users(): return jsonify({'error':'Yönetici kurulumu zaten tamamlanmış.'}),409
            with database() as conn:
                cur=conn.execute('INSERT INTO users(username,password_hash,role) VALUES(?,?,?)',
                                (username,generate_password_hash(password,method='scrypt'),'admin'))
                uid=cur.lastrowid
        session.clear(); session.update(user_id=uid,username=username,role='admin',csrf=secrets.token_hex(24))
        session.permanent=bool(data.get('remember'))
        return jsonify({'ok':True})

    @app.route('/api/auth/login',methods=['POST'])
    def login():
        data=request.get_json(silent=True) or {}
        username=str(data.get('username','')).strip()[:64]
        password=str(data.get('password',''))
        key=username.lower()
        now=time.monotonic()
        with LOCK:
            failures=[t for t in FAILURES.get(key,[]) if now-t<600]
            FAILURES[key]=failures
            if len(failures)>=6: return jsonify({'error':'Çok fazla hatalı deneme. 10 dakika sonra tekrar deneyin.'}),429
        with database() as conn:
            user=conn.execute('SELECT * FROM users WHERE username=? AND is_active=1',(username,)).fetchone()
        if not user or not check_password_hash(user['password_hash'], password):
            with LOCK: FAILURES.setdefault(key,[]).append(now)
            return jsonify({'error':'Kullanıcı adı veya parola hatalı.'}),401
        with LOCK: FAILURES.pop(key,None)
        session.clear();session.update(user_id=user['id'],username=user['username'],role=user['role'],csrf=secrets.token_hex(24))
        session.permanent=bool(data.get('remember'))
        return jsonify({'ok':True})

    @app.route('/api/auth/session')
    def current_session():
        if not session.get('user_id'): return jsonify({'authenticated':False}),401
        return jsonify({'authenticated':True,'username':session['username'],
                        'role':session['role'],'csrf':form_session()})

    @app.route('/api/auth/logout',methods=['POST'])
    def logout():
        session.clear()
        return jsonify({'ok':True})

    @app.route('/api/users')
    def users():
        if session.get('role')!='admin': return jsonify({'error':'Yönetici yetkisi gerekiyor.'}),403
        with database() as conn:
            records=[dict(row) for row in conn.execute('SELECT id,username,role,created_at,is_active FROM users ORDER BY id')]
        return jsonify(records)

    @app.route('/api/users',methods=['POST'])
    def add_user():
        if session.get('role')!='admin': return jsonify({'error':'Yönetici yetkisi gerekiyor.'}),403
        data=request.get_json(silent=True) or {}
        username=str(data.get('username','')).strip()
        password=str(data.get('password',''))
        role=data.get('role','viewer')
        if not USERNAME.fullmatch(username) or not 10<=len(password)<=256 or role not in ('admin','viewer'):
            return jsonify({'error':'Geçersiz kullanıcı adı, parola veya rol.'}),400
        try:
            with database() as conn:
                conn.execute('INSERT INTO users(username,password_hash,role) VALUES(?,?,?)',
                             (username,generate_password_hash(password,method='scrypt'),role))
        except sqlite3.IntegrityError:
            return jsonify({'error':'Bu kullanıcı adı kullanılıyor.'}),409
        return jsonify({'ok':True}),201

    @app.route('/api/users/<int:uid>/password',methods=['POST'])
    def reset_password(uid):
        if session.get('role')!='admin': return jsonify({'error':'Yönetici yetkisi gerekiyor.'}),403
        password=str((request.get_json(silent=True) or {}).get('password',''))
        if not 10<=len(password)<=256: return jsonify({'error':'En az 10 karakterli parola gerekli.'}),400
        with database() as conn:
            changed=conn.execute('UPDATE users SET password_hash=? WHERE id=?',(generate_password_hash(password,method='scrypt'),uid)).rowcount
        return jsonify({'ok':bool(changed)}),200 if changed else 404

    @app.route('/api/users/<int:uid>',methods=['DELETE'])
    def remove_user(uid):
        if session.get('role')!='admin': return jsonify({'error':'Yönetici yetkisi gerekiyor.'}),403
        if uid==session.get('user_id'): return jsonify({'error':'Kendi hesabınızı silemezsiniz.'}),400
        with database() as conn:
            target=conn.execute('SELECT role FROM users WHERE id=?',(uid,)).fetchone()
            if not target: return jsonify({'error':'Kullanıcı bulunamadı.'}),404
            if target['role']=='admin':
                count=conn.execute("SELECT COUNT(*) FROM users WHERE role='admin'").fetchone()[0]
                if count<=1: return jsonify({'error':'Son yönetici silinemez.'}),400
            conn.execute('DELETE FROM users WHERE id=?',(uid,))
        return jsonify({'ok':True})

    # Provide token through template, not public API.
    app.context_processor(lambda: {'csrf_token': lambda:form_session()})
